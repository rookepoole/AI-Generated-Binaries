#!/usr/bin/env python3
from pathlib import Path
import socket,struct,hashlib,hmac,time,re
from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes
W=Path(__file__).resolve().parent
CERT=(W/'tls20_cert.der').read_bytes(); nums=(W/'tls20_key_numbers.txt').read_text()
N=int(re.search(r'n=([0-9a-f]+)',nums).group(1),16);D=int(re.search(r'd=([0-9a-f]+)',nums).group(1),16)
HOST='127.0.0.1';PORT=18444; SR=bytes.fromhex('202008110102030405060708090a0b0c0d0e0f101112131415161718191a1b1c')
LOG=(W/'vm20_tls_peer.log').open('a',buffering=1)
PAGES={
 '/vm20.html':b'<html><h1>PARS CERT HTTPS</h1><p>TLS 1.2 RSA CERT VERIFIED INSIDE TINY32</p><a href="/about.html">ABOUT</a></html>',
 '/about.html':b'<html><h1>VM20 ABOUT</h1><p>PINNED X509 + RSA KEY EXCHANGE + GUEST AES/HMAC</p><a href="/vm20.html">HOME</a></html>'}
def recv_exact(c,n):
 b=b''
 while len(b)<n:
  x=c.recv(n-len(b))
  if not x: raise EOFError
  b+=x
 return b
def recv_rec(c):
 h=recv_exact(c,5); ln=int.from_bytes(h[3:5],'big'); return h[0],recv_exact(c,ln)
def send_rec(c,t,p): c.sendall(bytes([t])+b'\x03\x03'+len(p).to_bytes(2,'big')+p)
def P_hash(sec,seed,n):
 a=hmac.new(sec,seed,hashlib.sha256).digest();out=b''
 while len(out)<n:
  out+=hmac.new(sec,a+seed,hashlib.sha256).digest();a=hmac.new(sec,a,hashlib.sha256).digest()
 return out[:n]
def prf(sec,label,seed,n): return P_hash(sec,label+seed,n)
def keys(prem,cr,sr):
 master=prf(prem,b'master secret',cr+sr,48);kb=prf(master,b'key expansion',sr+cr,96)
 return master,kb[:32],kb[32:64],kb[64:80],kb[80:96]
def mac(key,seq,t,p):return hmac.new(key,seq.to_bytes(8,'big')+bytes([t])+b'\x03\x03'+len(p).to_bytes(2,'big')+p,hashlib.sha256).digest()
def protect(key,akey,seq,t,p):
 q=p+mac(key,seq,t,p); pad=(-len(q)-1)%16;q+=bytes([pad])*(pad+1);iv=bytes(((seq*16+i)&255) for i in range(16));enc=Cipher(algorithms.AES(akey),modes.CBC(iv)).encryptor().update(q);return iv+enc
def unprotect(key,akey,seq,t,p):
 if len(p)<32 or (len(p)-16)%16:raise ValueError('len')
 iv,ct=p[:16],p[16:];q=Cipher(algorithms.AES(akey),modes.CBC(iv)).decryptor().update(ct);pad=q[-1]
 if q[-pad-1:]!=bytes([pad])*(pad+1):raise ValueError('pad')
 z=q[:-pad-1];plain,got=z[:-32],z[-32:]
 if not hmac.compare_digest(got,mac(key,seq,t,plain)):raise ValueError('mac')
 return plain
def hs(t,body):return bytes([t])+len(body).to_bytes(3,'big')+body
def handle(c,addr):
 transcript=b''
 t,ch=recv_rec(c);assert t==22 and ch[0]==1;transcript+=ch
 cr=ch[6:38]
 # verify SNI bytes are actually in ClientHello
 assert b'tls20.test' in ch
 sh=hs(2,b'\x03\x03'+SR+b'\x00'+b'\x00\x3c'+b'\x00');send_rec(c,22,sh);transcript+=sh
 certbody=(3+len(CERT)).to_bytes(3,'big')+len(CERT).to_bytes(3,'big')+CERT;cm=hs(11,certbody);send_rec(c,22,cm);transcript+=cm
 done=hs(14,b'');send_rec(c,22,done);transcript+=done
 t,cke=recv_rec(c);assert t==22 and kce_type(cke)==16;transcript+=cke
 clen=int.from_bytes(cke[4:6],'big');ct=cke[6:6+clen];m=pow(int.from_bytes(ct,'big'),D,N).to_bytes(128,'big')
 assert m[:2]==b'\x00\x02';sep=m.index(b'\x00',2);prem=m[sep+1:];assert len(prem)==48 and prem[:2]==b'\x03\x03'
 master,cmac,smac,ckey,skey=keys(prem,cr,SR)
 t,ccs=recv_rec(c);assert t==20 and ccs==b'\x01'
 t,finrec=recv_rec(c);assert t==22;fin=unprotect(cmac,ckey,0,22,finrec);assert fin[:4]==b'\x14\x00\x00\x0c'
 exp=prf(master,b'client finished',hashlib.sha256(transcript).digest(),12);assert fin[4:]==exp;transcript+=fin
 send_rec(c,20,b'\x01');sfin=hs(20,prf(master,b'server finished',hashlib.sha256(transcript).digest(),12));send_rec(c,22,protect(smac,skey,0,22,sfin))
 t,app=recv_rec(c);assert t==23;req=unprotect(cmac,ckey,1,23,app);line=req.split(b'\r\n',1)[0];path=line.split()[1].decode();body=PAGES.get(path,b'<html><h1>404</h1></html>');resp=b'HTTP/1.0 200 OK\r\nContent-Type: text/html\r\nContent-Length: '+str(len(body)).encode()+b'\r\nConnection: close\r\n\r\n'+body
 send_rec(c,23,protect(smac,skey,1,23,resp));LOG.write(f'OK {addr} SNI=tls20.test CERTSHA={hashlib.sha256(CERT).hexdigest()} PREM={prem.hex()} REQ={line.decode(errors="replace")}\n')
def kce_type(x):return x[0] if x else -1
s=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind((HOST,PORT));s.listen(8);LOG.write(f'START {time.time()} port={PORT} certsha={hashlib.sha256(CERT).hexdigest()}\n')
while True:
 c,a=s.accept()
 try:handle(c,a)
 except Exception as e:LOG.write(f'ERR {a} {type(e).__name__}:{e}\n')
 finally:c.close()
