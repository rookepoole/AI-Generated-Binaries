from pathlib import Path
import subprocess,time,os,struct,hashlib,json
from PIL import Image
os.environ['DISPLAY']=':99';os.environ['XAUTHORITY']='/tmp/empty.Xauthority';Path('/tmp/empty.Xauthority').touch()
from Xlib import display,X
from Xlib.ext import xtest
W=Path('/mnt/data/PARS_VM20_WORK');ELF=W/'PARS_VM20_EXACT_BYTE_STREAM.elf';DISK=W/'.pars_vm20_pfs2.img';DISK.unlink(missing_ok=True)
G=0x420000;S=0x5040;P=0x5300;SH=0x50c0;IRQ=0x501000;PCB=0x502000;SL=0x503000;PFS2=0x500000
RS=0x100000;SS=0x200000;SURFSZ=640*360*4;P2_TERMLEN=12;P2_TERMSTATUS=16
D=display.Display(':99');log={}
rows={}
for kc,ch in zip(range(24,34),'qwertyuiop'):rows[ch]=kc
for kc,ch in zip(range(38,47),'asdfghjkl'):rows[ch]=kc
for kc,ch in zip(range(52,59),'zxcvbnm'):rows[ch]=kc
for kc,ch in zip(range(10,20),'1234567890'):rows[ch]=kc
rows.update({':':47,'.':60,'/':61,'-':20,' ':65})
p=subprocess.Popen([str(ELF)],cwd=W,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,env=os.environ.copy());time.sleep(.9)
def mem(a,n):
 with open(f'/proc/{p.pid}/mem','rb',0) as f:f.seek(G+a);return f.read(n)
def u(a):return struct.unpack('<I',mem(a,4))[0]
def wait(fn,t=12,msg='wait'):
 e=time.time()+t
 while time.time()<e:
  if p.poll()!=None:raise RuntimeError((p.returncode,msg))
  if fn():return
  time.sleep(.005)
 raise RuntimeError(('timeout',msg))
def click(x,y,w=.08):xtest.fake_input(D,X.MotionNotify,x=x,y=y);D.sync();time.sleep(.03);xtest.fake_input(D,X.ButtonPress,1);xtest.fake_input(D,X.ButtonRelease,1);D.sync();time.sleep(w)
def key(k):xtest.fake_input(D,X.KeyPress,k);xtest.fake_input(D,X.KeyRelease,k);D.sync()
def cap(name):
 im=D.screen().root.get_image(0,0,640,360,X.ZPixmap,0xffffffff);d=im.data.encode('latin1') if isinstance(im.data,str) else im.data;Image.frombytes('RGB',(640,360),d,'raw','BGRX').save(W/name)
def slices():return [u(SL+i*4) for i in range(6)]
def runs():return [u(P+40+i*4) for i in range(6)]
def cmd(s,status):
 wait(lambda:u(PFS2+P2_TERMLEN)==0,msg='empty');n=0
 for ch in s.lower():key(rows[ch]);n+=1;wait(lambda n=n:u(PFS2+P2_TERMLEN)==n,3,'char')
 key(36);wait(lambda:u(PFS2+P2_TERMLEN)==0,3,'enter');wait(lambda:u(PFS2+P2_TERMSTATUS)==status,3,'status')
try:
 cap('vm20_proof_00_process_desktop.png')
 click(250,331);wait(lambda:u(S+16)==1,8,'raster')
 click(372,331);wait(lambda:u(S+24)==1,8,'system');time.sleep(.7);cap('vm20_proof_01_preemptive_raster_system.png')
 click(85,98);wait(lambda:u(S+64)==1 and u(P+52)==1,12,'browser');click(592,49);wait(lambda:u(S+68)==0,4,'bmin')
 click(30,12);wait(lambda:u(SH)==1,3,'menuT');click(88,265);wait(lambda:u(P)==1 and u(P+56)==1,12,'term')
 click(30,12);wait(lambda:u(SH)==1,3,'menuE');click(230,265);wait(lambda:u(P+8)==1 and u(P+60)==1,12,'edit')
 r0=runs();s0=slices();pids=[];pcs=[]
 for _ in range(120):pids.append(u(IRQ));pcs.append([u(PCB+i*0x100+128) for i in range(6)]);time.sleep(.01)
 s1=slices();assert r0==[1]*6 and all(b>a for a,b in zip(s0,s1)) and set(range(6)).issubset(set(pids))
 log['all_six']={'run_flags':r0,'slice_before':s0,'slice_after':s1,'slice_delta':[b-a for a,b in zip(s0,s1)],'pid_samples':sorted(set(pids)),'pcb_pc_samples':pcs[::24]}
 # put SYSTEM on top so six live PID bars are visible while all processes stay runnable
 click(575,96,.3);cap('vm20_proof_02_six_pid_system_monitor.png')
 # focus terminal outside editor area
 click(80,120);wait(lambda:u(S+12)==4,3,'tfocus');cmd('ps',8);time.sleep(.25);cap('vm20_proof_03_terminal_ps.png')
 cmd('hang1',6);wait(lambda:u(P+32)==1,3,'hang');time.sleep(.3);rh0=hashlib.sha256(mem(RS,SURFSZ)).hexdigest();sh0=hashlib.sha256(mem(SS,SURFSZ)).hexdigest();hs0=slices();pc0=u(PCB+0x180);time.sleep(1.0);rh1=hashlib.sha256(mem(RS,SURFSZ)).hexdigest();sh1=hashlib.sha256(mem(SS,SURFSZ)).hexdigest();hs1=slices();pc1=u(PCB+0x180)
 assert rh0==rh1 and sh0!=sh1 and all(b>a for a,b in zip(hs0,hs1));log['hang1']={'raster_surface_sha_before':rh0,'raster_surface_sha_after':rh1,'raster_surface_frozen':True,'system_surface_changed':sh0!=sh1,'slice_delta':[b-a for a,b in zip(hs0,hs1)],'pid1_pc_before':pc0,'pid1_pc_after':pc1}
 cap('vm20_proof_04_hang1_other_pids_live.png')
 cmd('kill1',7);wait(lambda:u(P+44)==0 and u(S+16)==0,6,'kill');ks0=slices();time.sleep(.8);ks1=slices();assert ks1[1]==ks0[1] and all(ks1[i]>ks0[i] for i in [0,2,3,4,5]);log['kill1']={'run_flags':runs(),'slice_before':ks0,'slice_after':ks1,'slice_delta':[b-a for a,b in zip(ks0,ks1)]};cap('vm20_proof_05_kill1.png')
 cmd('run1',9);wait(lambda:u(P+44)==1 and u(S+16)==1,12,'run1');rs0=slices();time.sleep(.8);rs1=slices();assert rs1[1]>rs0[1];log['run1']={'run_flags':runs(),'slice_before':rs0,'slice_after':rs1,'slice_delta':[b-a for a,b in zip(rs0,rs1)],'pcb1_sp':u(PCB+0x17c)};cap('vm20_proof_06_run1_reloaded.png')
finally:
 if p.poll() is None:p.kill();p.wait()
 D.close()
log['elf']={'size':ELF.stat().st_size,'sha256':hashlib.sha256(ELF.read_bytes()).hexdigest()}
(W/'PARS_VM20_RUNTIME_PROOF.json').write_text(json.dumps(log,indent=2));print(json.dumps(log,indent=2))
