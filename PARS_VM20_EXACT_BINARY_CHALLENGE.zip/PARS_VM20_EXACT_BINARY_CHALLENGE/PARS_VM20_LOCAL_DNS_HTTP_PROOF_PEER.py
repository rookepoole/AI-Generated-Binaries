import socket, threading, time, pathlib
LOG=pathlib.Path(__file__).resolve().parent/'net_peer.log'
LOG.write_text('')
def log(s):
    with LOG.open('a') as f: f.write(s+'\n')
def dns():
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); s.bind(('127.0.0.1',15353))
    while True:
        data,addr=s.recvfrom(2048); i=12; labels=[]
        while i<len(data) and data[i]:
            n=data[i]; i+=1; labels.append(data[i:i+n].decode(errors='replace')); i+=n
        i+=1; qname='.'.join(labels); log('DNS '+qname+' '+data.hex()); question=data[12:i+4]
        resp=data[:2]+b'\x81\x80\x00\x01\x00\x01\x00\x00\x00\x00'+question+b'\xc0\x0c\x00\x01\x00\x01\x00\x00\x00\x3c\x00\x04\x7f\x00\x00\x01'
        s.sendto(resp,addr)
def http():
    s=socket.socket(); s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); s.bind(('127.0.0.1',18080)); s.listen(5)
    while True:
        c,a=s.accept(); data=b''
        while b'\r\n\r\n' not in data:
            p=c.recv(4096)
            if not p: break
            data+=p
        log('HTTP '+repr(data.decode(errors='replace')))
        body=b'<html><h1>VM20 HTTP REGRESSION</h1><p>TLS BUILD PRESERVES HTTP</p><a href="/about">ABOUT</a></html>\n'
        c.sendall(b'HTTP/1.0 200 OK\r\nContent-Type: text/html\r\nContent-Length: '+str(len(body)).encode()+b'\r\n\r\n'+body); c.close()
threading.Thread(target=dns,daemon=True).start();threading.Thread(target=http,daemon=True).start()
while True: time.sleep(1)
