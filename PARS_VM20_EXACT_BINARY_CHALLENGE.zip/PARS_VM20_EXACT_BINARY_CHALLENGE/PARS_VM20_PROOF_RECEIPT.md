# PARS-VM/20 — Certificate HTTPS proof receipt

## Frozen authority

- Target: `PARS_VM20_EXACT_BYTE_STREAM.elf`
- Size: **56,394 bytes**
- SHA-256: `a5ffd98dc0941a9bebedc2b09ca3650ead465a1b3eb1dcdbfc05afada4125271`
- ELF: Linux x86-64, static, one `PT_LOAD`, entry `0x400078`, no section table.
- A second constructor run reproduced the exact ELF byte-for-byte.
- `PARS_VM20_RECONSTRUCTED_FROM_HEX.elf` was reconstructed solely from the frozen hexadecimal stream and is byte-for-byte identical.

## What VM/20 adds

VM/20 replaces VM/19's TLS-PSK proof route with a pinned X.509 certificate / RSA key-exchange route while preserving the Tiny32 desktop, six-process preemptive scheduler, compositor, PFS1/PFS2, durable block storage, guest WASM runtime, DNS, TCP, and HTTP.

The deterministic proof endpoint is:

`https://tls20.test:18444/vm20.html`

The proof certificate is a self-signed **test-only** X.509 certificate:

- Subject / issuer CN: `tls20.test`
- DER length: 446 bytes
- DER SHA-256: `6a17a23e61757ebed0c6d3cb3c7c46cc7c5e51d69dad99f8096ef78bf2c8c4f6`
- RSA key: 1024-bit, exponent 3

The selected proof cipher suite is TLS 1.2 `TLS_RSA_WITH_AES_128_CBC_SHA256` (`0x003C`). This is intentionally a legacy, deterministic interoperability/protocol proof suite, **not a production security recommendation**.

## Guest-side cryptographic implementation

Tiny32 Browser PID3 executes these primitives as Tiny32 guest instructions:

1. SHA-256
2. HMAC-SHA256
3. TLS 1.2 PRF
4. AES-128 encryption
5. AES-128 decryption / key expansion
6. TLS key-block derivation
7. CBC record protect / authenticate / unprotect
8. 1024-bit RSA public operation using guest multi-precision modular arithmetic

VM/20 added a generic Tiny32 unsigned-less-than operation to make multi-precision arithmetic practical. There is **no RSA, modular-exponentiation, certificate, TLS, HTTPS, OpenSSL, or crypto syscall** exposed to the guest.

The RSA self-test reproduces a fixed 1024-bit known-answer ciphertext exactly before the browser accepts the TLS path; guest crypto status must reach `8/8`.

## Certificate checks performed by Tiny32

For the deterministic proof certificate the guest:

- hashes the received DER with guest SHA-256 and compares it to the pinned digest (`CERT_OK=1`),
- requires the proof hostname bytes `tls20.test` to occur in the expected certificate (`HOST_OK=1`),
- locates the expected 1024-bit RSA INTEGER encoding, extracts the 128-byte modulus, converts it into guest limbs, and compares it with the pinned modulus (`RSA_KEY_OK=1`).

This is **minimal pinned-certificate verification**, not a general ASN.1/X.509/WebPKI validator.

## Live TLS/HTTPS proof

The frozen ELF performed three independent sessions against the local proof peers:

### Session 1 — home

- URL: `https://tls20.test:18444/vm20.html`
- Guest DNS A query emitted for `tls20.test`
- SNI: `tls20.test`
- Certificate pin: PASS
- Hostname proof check: PASS
- RSA modulus extraction/validation: PASS
- ClientKeyExchange: guest RSA public operation
- Client Finished: accepted by proof peer
- Server Finished: authenticated/verified by Tiny32 (`FINISHED_OK=1`)
- HTTPS response decrypted in guest RAM: **198 bytes**
- Parsed link: `/about.html`

### Session 2 — OPEN LINK

- Address rebuilt by Tiny32: `https://tls20.test:18444/about.html`
- New DNS/TCP/TLS session
- HTTPS response decrypted in guest RAM: **199 bytes**

### Session 3 — BACK

- Address restored by Tiny32: `https://tls20.test:18444/vm20.html`
- New DNS/TCP/TLS session
- HTTPS response decrypted in guest RAM: **198 bytes**

The independent peer log records `GET /vm20.html`, `GET /about.html`, then `GET /vm20.html` after valid TLS handshakes.

## Native / host boundary

The exact-byte native host layer provides primitive transport/device operations only: raw X11 presentation/input, UDP/TCP stream transport, and raw PFS2 block sectors. It does not expose a URL fetcher or browser engine.

For the TLS proof, the Python proof peer is an **external server/test oracle**, not part of the target executable. It uses normal host cryptography to play the server role and verify the records produced by Tiny32. The guest implementation remains inside the frozen ELF.

## VM/18 subsystem regression on the frozen VM/20 ELF

The same frozen ELF re-passed:

- PID0–PID5 all runnable and accumulating preemptive slices.
- `HANG1`: Raster surface remains bit-identical while all six PID slice counters continue to advance.
- `KILL1`: PID1 slice delta becomes exactly zero while PID0/PID2/PID3/PID4/PID5 continue.
- `RUN1`: Raster reloads and resumes scheduling.
- Durable PFS2: `PROCESS SAVE` survives full process death and cold restart in the 4,096-byte raw virtual disk.
- Nested WASM: the PFS1 HTML/WASM page reloads and WASM globals advance `0,0 -> 2,2` under Tiny32's interpreter.
- Plain HTTP: Tiny32/20 emits the raw `demo.test` DNS query and `GET / HTTP/1.0` with `User-Agent: Tiny32/20`.

See the JSON proof files and frozen-ELF harnesses in this package.

## Exact-byte construction boundary

The authority ELF is emitted by `PARS_VM20_EXPLICIT_BYTE_CONSTRUCTION.py` as explicit ELF header, x86-64 opcodes/data, Tiny32 instruction bytes, and embedded PFS1 bytes. It does not invoke an assembler, compiler, linker, object file, or prebuilt executable template to produce the final ELF.

`vm20_transform.py` is a development-time script that deterministically derives the VM/20 constructor from the released VM/19 constructor. The final authority is independently rebuilt by the resulting VM/20 constructor and again from the frozen hex stream.

## Security/scope limits

VM/20 should **not** be represented as a production-secure or general public-Web TLS client:

- The certificate is self-signed and pinned; there is no CA chain / root trust store / WebPKI validation.
- Hostname validation is deliberately minimal and proof-specific.
- RSA-1024/e=3 and TLS 1.2 RSA/AES-CBC/SHA256 are legacy and not suitable choices for modern production TLS.
- Client random and premaster secret are deterministic for exact reproducibility, not cryptographically random.
- The sandbox blocks the public outbound networking needed for a live public-site proof.

VM/20 proves the architectural boundary: **an exact-byte virtual computer receives a certificate over a TLS wire connection, authenticates the pinned identity, performs its own RSA/key schedule/record cryptography, verifies Finished, sends encrypted HTTPS, decrypts the response, and renders it inside its scheduled guest browser process.**
