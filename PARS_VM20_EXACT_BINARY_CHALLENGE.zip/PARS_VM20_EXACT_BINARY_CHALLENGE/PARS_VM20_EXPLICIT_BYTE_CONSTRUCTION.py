from pathlib import Path
import struct, math, hashlib, textwrap

OUT = Path(__file__).resolve().parent
BASE = 0x400000
ENTRY_OFF = 0x78
GUEST_BASE = 0x420000
REG_BASE = 0x1200000
X11_SCRATCH = 0x1210000
X11_EVENT = 0x1210100
X11_POLL = 0x1210140
HOST_STATE = 0x1211000
SOCKADDR = 0x1212000
VRAM_GUEST = 0x10000
# VM/20 guest-owned full-screen application surfaces. Linux never composes them.
RASTER_SURF = 0x100000
SYSTEM_SURF = 0x200000
BROWSER_SURF = 0x300000
TERMINAL_SURF = 0x800000
EDITOR_SURF = 0x900000
RASTER_BACK = 0x600000
SYSTEM_BACK = 0x700000
BROWSER_BACK = 0xA00000
TERMINAL_BACK = 0xB00000
EDITOR_BACK = 0xC00000
DRAW_BASE_PTR = 0x50F0
APP_LOAD = 0x4000
DIRBUF = 0x3C00
STACK_TOP = 0xF000

# Carry-forward opcode core from the proven VM/6 transport/interpreter, re-emitted
# here as an explicit byte literal. This constructor does not read, copy, or patch
# any prior ELF/executable file. VM/7 adds its block-device trampoline, new guest
# kernel, PFS1 virtual disk, and separately stored application from explicit bytes.
HOST_CORE_HEX = r"""
48be550840000000000048bf0080400000000000b9601d0000f3a44531ed49be008040000000000049bf0080450000000000e900000000438b042e4183c50441
89c40fb6c880f9010f84a700000080f9020f84b900000080f9030f84cf00000080f9040f84e500000080f9050f84fb00000080f9060f841801000080f9070f84
3001000080f9080f844201000080f9090f845401000080f9100f846c01000080f9110f849101000080f9200f84b601000080f9210f84be01000080f9220f84db
01000080f9230f84f801000080f9240f841502000080f9250f842a02000080f9300f843302000080f9ff0f8478020000e9730200004489e1c1e90883e11f4489
e0c1e8100fbfc04189048fe927ffffff4489e0c1e80883e01f4489e1c1e91083e11f418b148f41891487e908ffffff4489e0c1e80883e01f4489e1c1e91083e1
1f418b148f41011487e9e9feffff4489e0c1e80883e01f4489e1c1e91083e11f418b148f41291487e9cafeffff4489e0c1e80883e01f4489e1c1e91083e11f41
8b1c87418b148f0fafda41891c87e9a4feffff4489e0c1e80883e01f4489e1c1e91083e11f418b1487d3fa41891487e983feffff4489e0c1e80883e01f4489e1
c1e9100fbec941010c87e968feffff4489e0c1e80883e01f4489e1c1e9100fb6c941210c87e94dfeffff4489e0c1e80883e01f4489e1c1e91083e11f418b1487
d3e241891487e92cfeffff4489e0c1e80883e01f4489e1c1e91083e11f418b148f4489e3c1eb180fbedb01da418b1c1641891c87e9fefdffff4489e0c1e80883
e01f4489e1c1e91083e11f418b148f4489e3c1eb180fbedb01da418b348741893416e9d0fdffff4489e0c1e8100fb7c04189c5e9bffdffff4489e0c1e80883e0
1f418b0c8785c90f85aafdffff4489e0c1e8100fb7c04189c5e999fdffff4489e0c1e80883e01f418b0c8785c90f8484fdffff4489e0c1e8100fb7c04189c5e9
73fdffff4489e0c1e80883e01f418b0c8785c90f895efdffff4489e0c1e8100fb7c04189c5e94dfdffff41836f7c04418b477c45892c064489e0c1e8100fb7c0
4189c5e92ffdffff418b477c458b2c064183477c04e91dfdffff4489e1c1e9080fb6c983f9000f841700000083f9030f841800000083f9040f8419000000e9f4
fcffffe848000000e9eafcffffe89a020000e9e0fcffffe8d002000041890741895704e9cffcffff48bb00704000000000008b3bb8030000000f05b83c000000
31ff0f05b83c000000bf010000000f05b829000000bf01000000be0100000031d20f054885c00f88d8ffffff4989c448bb0070400000000000448923b82a0000
004489e748be7707400000000000ba180000000f054885c00f88a6ffffffb8010000004489e748bee507400000000000ba0c0000000f0531c04489e748be0030
400000000000ba080000000f054883f8080f8c6dffffff48bb0030400000000000440fb74b0641c1e10249b808304000000000004585c90f842100000031c044
89e74c89c64489ca0f054885c00f8e31ffffff4901c04129c1e9d6ffffff48bb0030400000000000803b010f8513ffffff8b430c89c183c80148ba0870400000
000000890289c883c80248ba0c7040000000000089020fb7431883c00383e0fc0fb64b1dc1e10301c883c0284801d88b0848ba1070400000000000890a48baf1
0740000000000048bb08704000000000008b0b894a0448bb10704000000000008b0b894a088b480c894a2048ba190840000000000048bb0c704000000000008b
0b894a0448bb08704000000000008b0b894a0848ba290840000000000048bb08704000000000008b0b894a0448ba310840000000000048bb0870400000000000
8b0b894a0448ba3d0840000000000048bb08704000000000008b0b894a0448bb0c704000000000008b0b894a080fb64826884a15b8010000004489e748bef107
400000000000ba280000000f05b8010000004489e748be1908400000000000ba100000000f05b8010000004489e748be2908400000000000ba080000000f05b8
010000004489e748be3108400000000000ba0c0000000f0548bb408145000000000044892366c743040100c348bb0070400000000000448b23b8010000004489
e748be3d08400000000000ba180000000f05b8010000004489e748be0080410000000000ba008403000f05c3b80700000048bf4081450000000000be01000000
ba100000000f0585c00f8e8300000048bb00704000000000008b3b31c048be0081450000000000ba200000000f0585c00f8e5c00000048bb0081450000000000
0fb60b83e17f83f9020f85430000000fb64b0183f9240f843b00000083f9180f845200000083f9260f843100000083f9280f843000000083f9090f842f000000
83f9710f841600000083f9720f841500000031c031d2c3b80100000031d2c3b80200000031d2c3b80300000031d2c3b80400000031d2c3b80500000031d2c301
002f746d702f2e5831312d756e69782f583939000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006c000b00000000000000000001000a00000000
0000000000000000004001b40000000100000000000208000000000000018000003700040000000000000000000000000008000200000000002a000300000000
0000000000480206e100000000000000004001b4000000000000000000
"""
HOST_CORE = bytes.fromhex(HOST_CORE_HEX.replace("\n", ""))
assert len(HOST_CORE) == 0x855-0x78

# VM/20 uses an expanded guest RAM map so three full-screen app surfaces can coexist with display VRAM.
# Runtime scratch/register banks are moved above those guest surfaces so nothing overlaps.
# the Tiny32 register bank or X11 event buffers. These are fixed-width byte patches
# to the explicit host literal, not compiled/linker relocation.
def patch_qword(blob, old, new):
    oldb=struct.pack('<Q',old); newb=struct.pack('<Q',new)
    n=blob.count(oldb)
    if n == 0: raise ValueError(('missing host qword',hex(old)))
    return blob.replace(oldb,newb)
for _old,_new in [
    (0x408000,GUEST_BASE),(0x458000,REG_BASE),(0x403000,X11_SCRATCH),(0x403008,X11_SCRATCH+8),
    (0x458100,X11_EVENT),(0x458140,X11_POLL),(0x407000,HOST_STATE),(0x407008,HOST_STATE+8),
    (0x40700c,HOST_STATE+12),(0x407010,HOST_STATE+16)]:
    HOST_CORE=patch_qword(HOST_CORE,_old,_new)

class G:
    def __init__(self, origin=0):
        self.origin=origin; self.b=bytearray(); self.labels={}; self.fix=[]; self.notes=[]
    @property
    def pc(self): return self.origin+len(self.b)
    def label(self,n):
        if n in self.labels: raise ValueError(n)
        self.labels[n]=self.pc
    def ins(self,op,a=0,b=0,c=0,note=None):
        p=self.pc; self.b += bytes((op&255,a&255,b&255,c&255))
        if note: self.notes.append((p, bytes(self.b[-4:]), note))
        return p
    def ldi(self,r,v,note=None):
        v &= 0xffff; return self.ins(0x01,r,v&255,v>>8,note or f'LDI R{r}, {struct.unpack("<h",struct.pack("<H",v))[0]}')
    def ldi_label(self,r,label,note=None):
        p=self.ins(0x01,r,0,0,note or f'LDI R{r}, {label}')
        self.fix.append((p-self.origin+2,label,'u16')); return p
    def mov(self,d,s): return self.ins(0x02,d,s,0,f'MOV R{d}, R{s}')
    def add(self,d,s): return self.ins(0x03,d,s,0,f'ADD R{d}, R{s}')
    def sub(self,d,s): return self.ins(0x04,d,s,0,f'SUB R{d}, R{s}')
    def mul(self,d,s): return self.ins(0x05,d,s,0,f'MUL R{d}, R{s}')
    def sar(self,d,amt): return self.ins(0x06,d,amt,0,f'SAR R{d}, {amt}')
    def addi(self,d,v): return self.ins(0x07,d,v&255,0,f'ADDI R{d}, {v}')
    def andi(self,d,v): return self.ins(0x08,d,v&255,0,f'ANDI R{d}, {v}')
    def shl(self,d,amt): return self.ins(0x09,d,amt,0,f'SHL R{d}, {amt}')
    def xor(self,d,s): return self.ins(0x0a,d,s,0,f'XOR R{d}, R{s}')
    def andr(self,d,s): return self.ins(0x0b,d,s,0,f'AND R{d}, R{s}')
    def shr(self,d,amt): return self.ins(0x0c,d,amt,0,f'SHR R{d}, {amt}')
    def ror(self,d,amt): return self.ins(0x0d,d,amt,0,f'ROR R{d}, {amt}')
    def bswap(self,d): return self.ins(0x0e,d,0,0,f'BSWAP R{d}')
    def ult(self,d,s): return self.ins(0x0f,d,s,0,f'ULT R{d}, R{s}')
    def addr_label(self,r,label):
        p=self.ins(0x01,r,0,0,f'LDADDRHI R{r}, {label}'); self.fix.append((p-self.origin+2,label,'addrhi'))
        self.shl(r,8)
        q=self.ins(0x07,r,0,0,f'LDADDRLO R{r}, {label}'); self.fix.append((q-self.origin+2,label,'addrlo'))
        return p
    def ld(self,d,base,off=0): return self.ins(0x10,d,base,off&255,f'LD32 R{d}, [R{base}{off:+d}]')
    def st(self,s,base,off=0): return self.ins(0x11,s,base,off&255,f'ST32 R{s}, [R{base}{off:+d}]')
    def branch(self,op,r,label,mnem):
        p=self.ins(op,r,0,0,f'{mnem} R{r}, {label}' if r else f'{mnem} {label}')
        if isinstance(label,int):
            self.b[p-self.origin+2:p-self.origin+4]=struct.pack('<H',label&0xffff)
        else:
            self.fix.append((p-self.origin+2,label,'u16'))
        return p
    def jmp(self,l): return self.branch(0x20,0,l,'JMP')
    def jz(self,r,l): return self.branch(0x21,r,l,'JZ')
    def jnz(self,r,l): return self.branch(0x22,r,l,'JNZ')
    def js(self,r,l): return self.branch(0x23,r,l,'JS')
    def call(self,l): return self.branch(0x24,0,l,'CALL')
    def ret(self): return self.ins(0x25,0,0,0,'RET')
    def iret(self): return self.ins(0x26,0,0,0,'IRET')
    def sys(self,n): return self.ins(0x30,n,0,0,f'SYS {n}')
    def halt(self): return self.ins(0xff,0,0,0,'HALT')
    def pad_to(self,addr,fill=0):
        if self.pc>addr: raise ValueError((hex(self.pc),hex(addr)))
        self.b += bytes([fill])*(addr-self.pc)
    def data_u32(self,vals):
        for v in vals: self.b += struct.pack('<I', v & 0xffffffff)
    def data_str32(self,s):
        for ch in s: self.b += struct.pack('<I',ord(ch))
        self.b += b'\0\0\0\0'
    def resolve(self):
        for off,label,kind in self.fix:
            if label not in self.labels: raise KeyError(label)
            v=self.labels[label]
            if not (0<=v<=0xffff): raise ValueError((label,hex(v)))
            if kind=='u16': self.b[off:off+2]=struct.pack('<H',v)
            elif kind=='addrhi':
                lo=v&0xff; hi=((v+(0x100 if lo>=128 else 0))>>8)&0xffff; self.b[off:off+2]=struct.pack('<H',hi)
            elif kind=='addrlo': self.b[off]=v&0xff
            else: raise ValueError(kind)
        return bytes(self.b)

# 5x7 glyphs, rows are 5-bit patterns, bit0 is leftmost pixel.
# Only glyphs used by the guest UI are materialized.
FONT = {
' ':['00000']*7,
'A':['01110','10001','10001','11111','10001','10001','10001'],
'B':['11110','10001','10001','11110','10001','10001','11110'],
'C':['01111','10000','10000','10000','10000','10000','01111'],
'D':['11110','10001','10001','10001','10001','10001','11110'],
'E':['11111','10000','10000','11110','10000','10000','11111'],
'F':['11111','10000','10000','11110','10000','10000','10000'],
'G':['01111','10000','10000','10111','10001','10001','01111'],
'H':['10001','10001','10001','11111','10001','10001','10001'],
'I':['11111','00100','00100','00100','00100','00100','11111'],
'J':['00111','00010','00010','00010','10010','10010','01100'],
'K':['10001','10010','10100','11000','10100','10010','10001'],
'L':['10000','10000','10000','10000','10000','10000','11111'],
'M':['10001','11011','10101','10101','10001','10001','10001'],
'N':['10001','11001','10101','10011','10001','10001','10001'],
'O':['01110','10001','10001','10001','10001','10001','01110'],
'P':['11110','10001','10001','11110','10000','10000','10000'],
'Q':['01110','10001','10001','10001','10101','10010','01101'],
'R':['11110','10001','10001','11110','10100','10010','10001'],
'S':['01111','10000','10000','01110','00001','00001','11110'],
'T':['11111','00100','00100','00100','00100','00100','00100'],
'U':['10001','10001','10001','10001','10001','10001','01110'],
'V':['10001','10001','10001','10001','10001','01010','00100'],
'W':['10001','10001','10001','10101','10101','10101','01010'],
'X':['10001','10001','01010','00100','01010','10001','10001'],
'Y':['10001','10001','01010','00100','00100','00100','00100'],
'Z':['11111','00001','00010','00100','01000','10000','11111'],
'0':['01110','10001','10011','10101','11001','10001','01110'],
'1':['00100','01100','00100','00100','00100','00100','01110'],
'2':['01110','10001','00001','00010','00100','01000','11111'],
'3':['11110','00001','00001','01110','00001','00001','11110'],
'4':['00010','00110','01010','10010','11111','00010','00010'],
'5':['11111','10000','10000','11110','00001','00001','11110'],
'6':['01110','10000','10000','11110','10001','10001','01110'],
'7':['11111','00001','00010','00100','01000','01000','01000'],
'8':['01110','10001','10001','01110','10001','10001','01110'],
'9':['01110','10001','10001','01111','00001','00001','01110'],
'/':['00001','00010','00010','00100','01000','01000','10000'],
'.':['00000','00000','00000','00000','00000','01100','01100'],
'-':['00000','00000','00000','11111','00000','00000','00000'],
'+':['00000','00100','00100','11111','00100','00100','00000'],
':':['00000','01100','01100','00000','01100','01100','00000'],
'[':['01110','01000','01000','01000','01000','01000','01110'],
']':['01110','00010','00010','00010','00010','00010','01110'],
'=':['00000','11111','00000','11111','00000','00000','00000'],
'<':['00010','00100','01000','10000','01000','00100','00010'],
'>':['01000','00100','00010','00001','00010','00100','01000'],
}

def rowbits(s):
    v=0
    for i,c in enumerate(s):
        if c=='1': v |= 1<<i
    return v


# PARS-VM/20: networked desktop + three separately loaded cooperative processes, including a Tiny32 HTTP browser.
# The final ELF remains explicit bytes only: no compiler, assembler, linker,
# object file, or prior executable is read by this constructor.
DIRBUF = 0x5100
STATE = 0x5040
RASTER_LOAD = 0x6000
SYSTEM_LOAD = 0x5400
BROWSER_LOAD = 0x7000
TERMINAL_LOAD = 0xE000
EDITOR_LOAD = 0xF000
ADDR_BUF = 0x400000          # u32-per-character editable address
HOST_BUF = 0x400200          # parsed host, u32-per-character
PATH_BUF = 0x400400          # parsed path, u32-per-character
REQ_BUF = 0x400800           # raw HTTP request bytes
DNS_BUF = 0x401800           # raw DNS query bytes
DNS_RESP = 0x401A00          # raw DNS response bytes
RESP_BUF = 0x402000          # raw HTTP response bytes
LINK_BUF = 0x404000          # first parsed href, u32-per-character
PREV_BUF = 0x404200          # one-entry browser history
STACK_TOP = 0xF000
HTML_BUF = 0x404400          # local PFS1 HTML asset (raw bytes)
WASM_BUF = 0x404800          # local PFS1 WebAssembly module (raw bytes)
WASM_META = 0x404C00         # html_size, wasm_size, ready, codeptr, globals[2], error
WASM_STACK = 0x404D00        # interpreter operand stack

# VM/20 guest TLS/crypto workspace. These are ordinary Tiny32 guest RAM buffers.
TLS_HMAC_WORK = 0x405000     # HMAC staging (separate so SHA copy never aliases)
TLS_WORK = 0x406000          # SHA padded message workspace
TLS_W = 0x406800             # SHA-256 schedule, 64 u32 words
TLS_H = 0x406900             # SHA-256 state, 8 u32 words
TLS_INNER = 0x406940         # SHA/HMAC intermediate digest
TLS_A = 0x406A00             # TLS PRF A(i)
TLS_T = 0x406A40             # TLS PRF output block
TLS_SEED = 0x406B00          # PRF label+seed staging
TLS_PRF_MSG = 0x406D00       # A(i)||seed staging
TLS_PREMASTER = 0x406F00     # PSK premaster secret
TLS_MASTER = 0x407000        # 48-byte master secret
TLS_KEYBLOCK = 0x407100      # 96-byte TLS 1.2 CBC key block
TLS_CMAC = 0x407200          # client MAC key 32
TLS_SMAC = 0x407240          # server MAC key 32
TLS_CKEY = 0x407300          # client AES key 16
TLS_SKEY = 0x407340          # server AES key 16
TLS_CKEYEXP = 0x407400       # 176-byte AES expanded key
TLS_SKEYEXP = 0x407500       # 176-byte AES expanded key
TLS_CLIENT_RANDOM = 0x407600 # 32 bytes
TLS_SERVER_RANDOM = 0x407640 # 32 bytes
TLS_TRANSCRIPT = 0x408000    # raw handshake transcript
TLS_TX = 0x409000            # TLS record construction buffer
TLS_HSBUF = 0x40A800         # TLS handshake/decrypted record staging
TLS_RX = 0x40B000            # TLS record receive/decrypt buffer
TLS_PLAIN = 0x40D000         # TLS plaintext/MAC/padding workspace
TLS_AES_A = 0x40E000         # AES state A
TLS_AES_B = 0x40E100         # AES state B
TLS_BLOCK_IN = 0x40E200      # one CBC block input
TLS_BLOCK_OUT = 0x40E240     # one CBC block output
TLS_MACMSG = 0x40D800        # TLS MAC header + plaintext staging
TLS_META2 = 0x40F000         # crypto parameter/status words
TLS_TEST_OUT = 0x40F400      # crypto self-test output

# VM/20 pinned-certificate RSA workspace. No host RSA/certificate primitive exists.
RSA_N = 0x410000            # extracted 1024-bit modulus, 32 little-endian u32 limbs
RSA_A = 0x410100            # bignum operand A
RSA_B = 0x410200            # bignum operand B
RSA_R = 0x410300            # bignum result / RSA ciphertext
RSA_SUM = 0x410400          # modular-add workspace
RSA_TMP = 0x410500          # modular-multiply doubling operand
RSA_CERT = 0x411000         # received DER certificate copy
RSA_CERT_SHA = 0x411400     # computed certificate SHA-256
RSA_CKE = 0x411800          # ClientKeyExchange handshake staging
RSA_META = 0x411A00         # certificate/RSA status words
RM_CERTLEN2=0; RM_CERTOK2=4; RM_HOSTOK2=8; RM_RSAOK2=12; RM_MODPTR2=16; RM_BPTR2=20; RM_OUTPTR2=24; RM_LIMB2=28; RM_BIT2=32; RM_WORD2=36

# TLS_META2 offsets
TM_SHA_IN=0; TM_SHA_LEN=4; TM_SHA_OUT=8; TM_SHA_BLOCK=12; TM_SHA_BLOCKS=16
TM_HKEY=20; TM_HKEYLEN=24; TM_HMSG=28; TM_HMSGLEN=32; TM_HOUT=36
TM_PRF_SECRET=40; TM_PRF_SECLEN=44; TM_PRF_SEED=48; TM_PRF_SEEDLEN=52; TM_PRF_OUT=56; TM_PRF_OUTLEN=60
TM_CRYPTO_OK=64; TM_TLS_STATUS=68; TM_TLS_FD=72; TM_TLS_TLEN=76; TM_TLS_CSEQ=80; TM_TLS_SSEQ=84
TM_AES_KEY=88; TM_AES_EXP=92; TM_AES_IN=96; TM_AES_OUT=100; TM_AES_RK=104
TM_TLS_MODE=108; TM_SCHEMELEN=112; TM_TLS_APPRESP=116; TM_TLS_PEEROK=120
# TLS record metadata uses a dedicated page so every LD/ST immediate stays in signed-8 range.
TLS_REC_META=0x40F100
RM_KEYEXP=0; RM_MAC=4; RM_SEQ=8; RM_TYPE=12; RM_IN=16; RM_INLEN=20; RM_OUT=24; RM_OUTLEN=28; RM_QLEN=32; RM_BLOCKS=36; RM_BLOCKIDX=40; RM_PLAINLEN=44; RM_SAVEDOUT=48

# Shared state offsets (guest RAM)
S_CX=0; S_CY=4; S_DRAG=8; S_FOCUS=12
S_RRES=16; S_ROPEN=20; S_SRES=24; S_SOPEN=28
S_RX=32; S_RY=36; S_SX=40; S_SY=44
S_TICK=48; S_CMD=52; S_DX=56; S_DY=60
S_BRES=64; S_BOPEN=68; S_BLEN=72; S_BFETCH=76; S_BSTATUS=80; S_BRESP=84
S_BACTION=88; S_BPORT=92; S_BIP=96; S_BHLEN=100; S_BPLEN=104
S_BLINKLEN=108; S_BPREVLEN=112; S_BPREFIXLEN=116; S_BDNSLEN=120; S_BREQ=124
PROC_CTL=0x5300
PC_TRES=0; PC_TOPEN=4; PC_ERES=8; PC_EOPEN=12; PC_REQ=16; PC_TKEY=20; PC_EKEY=24; PC_BKEY=28; PC_RHANG=32; PC_RUN0=40
SHELL_STATE=0x50C0
SH_MENU=0; SH_SHELL=4
# VM/20 guest-owned writable session filesystem (PFS2). No native filesystem API touches it.
PFS2_BASE=0x500000
PFS2_TERM=0x500100     # u32-per-character terminal command line
PFS2_EDIT=0x500300     # u32-per-character editor body text
PFS2_FILE=0x500800     # u32-per-character saved HTML document
P2_EXISTS=0; P2_FILELEN=4; P2_VERSION=8; P2_TERMLEN=12; P2_TERMSTATUS=16; P2_EDITLEN=20; P2_DIRTY=24; P2_DISKSTATUS=28

# VM/20 timer/interrupt architecture. The host CPU creates a hardware trap frame;
# the Tiny32 kernel owns PCBs, runnable selection, slice accounting, and IRET.
IRQ_BASE=0x501000
TRAP_BASE=0x501100          # 32 regs + interrupted PC (33 u32 words)
PCB_BASE=0x502000           # PID0/1/2 contexts, 0x100 bytes each
PCB_STRIDE=0x100
SLICE_BASE=0x503000         # u32 slice counters indexed by PID
PROC1_STACK=0x510000
PROC2_STACK=0x512000
PROC3_STACK=0x514000
PROC4_STACK=0x516000
PROC5_STACK=0x518000
IRQ_CURPID=0; IRQ_ENABLE=4; IRQ_INSERVICE=8; IRQ_VECTOR=12; IRQ_SWITCHES=16; IRQ_LASTPC=20

k=G(0)

def state_base(r=29):
    k.ldi(r,STATE)

def shell_state_base(r=29):
    k.ldi(r,SHELL_STATE)

def proc_ctl_base(r=29):
    k.ldi(r,PROC_CTL)

def k_abs(reg,addr):
    # Construct an exact arbitrary guest RAM address using signed ADDI for the low byte.
    # For low bytes >=128, round the high part up before adding the negative signed low byte.
    lo=addr&0xff; hi=((addr + (0x100 if lo>=128 else 0))>>8)&0xffff
    k.ldi(reg,hi); k.shl(reg,8)
    if lo: k.addi(reg,lo if lo<128 else lo-256)

def k_color(reg, off):
    k.ldi_label(14,'palette'); k.ld(reg,14,off)

def call_rect(x,y,w,h,coff):
    k.ldi(0,x); k.ldi(1,y); k.ldi(2,w); k.ldi(3,h); k_color(4,coff); k.call('fill_rect')

def call_text(x,y,label,coff):
    k.ldi(0,x); k.ldi(1,y); k.ldi_label(2,label); k_color(3,coff); k.call('draw_text')

def call_text_big(x,y,label,coff):
    k.ldi(0,x); k.ldi(1,y); k.ldi_label(2,label); k_color(3,coff); k.call('draw_text_big')

# boot and state init
k.label('boot')
k.sys(0)
k.ldi(31,240); k.shl(31,8)
state_base()
for off,val in [(S_CX,318),(S_CY,178),(S_DRAG,0),(S_FOCUS,0),(S_RRES,0),(S_ROPEN,0),(S_SRES,0),(S_SOPEN,0),
                (S_RX,20),(S_RY,48),(S_SX,392),(S_SY,92),(S_TICK,0),(S_CMD,0),(S_DX,0),(S_DY,0),
                (S_BRES,0),(S_BOPEN,0),(S_BLEN,0),(S_BFETCH,0),(S_BSTATUS,0),(S_BRESP,0),
                (S_BACTION,0),(S_BPORT,80),(S_BIP,0),(S_BHLEN,0),(S_BPLEN,0),(S_BLINKLEN,0),
                (S_BPREVLEN,0),(S_BPREFIXLEN,0),(S_BDNSLEN,0),(S_BREQ,0)]:
    k.ldi(0,val); k.st(0,29,off)
shell_state_base(); k.ldi(0,0); k.st(0,29,SH_MENU); k.st(0,29,SH_SHELL)
proc_ctl_base(); k.ldi(0,0)
for _off in (PC_TRES,PC_TOPEN,PC_ERES,PC_EOPEN,PC_REQ,PC_TKEY,PC_EKEY,PC_BKEY,PC_RHANG): k.st(0,29,_off)
# PID0 kernel runnable at boot; PIDs 1..5 start stopped.
k.ldi(0,1); k.st(0,29,PC_RUN0); k.ldi(0,0)
for _off in (PC_RUN0+4,PC_RUN0+8,PC_RUN0+12,PC_RUN0+16,PC_RUN0+20): k.st(0,29,_off)
# Restore the raw 4 KiB PFS2 image from the durable block device. On first boot the
# backing image is empty, so untouched zero-fill RAM remains a clean filesystem.
k.ldi(0,0); k_abs(1,PFS2_BASE); k.ldi(2,8); k.sys(11)
k_abs(28,PFS2_BASE); k.mov(9,0); k.ldi(0,0); k.st(0,28,P2_TERMLEN); k.st(0,28,P2_TERMSTATUS); k.st(0,28,P2_DIRTY); k_abs(27,PFS2_TERM); k.st(0,27,0)
# Record whether this boot restored a complete 8-sector image. This status is guest-only.
k.ldi(10,4096); k.sub(9,10); k.jnz(9,'pfs2_boot_new'); k.ldi(10,1); k.st(10,28,P2_DISKSTATUS); k.jmp('pfs2_boot_done')
k.label('pfs2_boot_new'); k.ldi(10,0); k.st(10,28,P2_DISKSTATUS)
k.label('pfs2_boot_done')
# drawing defaults to the physical guest display surface
k.ldi(10,DRAW_BASE_PTR); k.ldi(11,256); k.shl(11,8); k.st(11,10,0)
# Program the hardware timer vector. Interrupts become live only after all boot state
# and the durable PFS2 restore are complete.
k_abs(28,IRQ_BASE); k.ldi(0,0); k.st(0,28,IRQ_CURPID); k.st(0,28,IRQ_ENABLE); k.st(0,28,IRQ_INSERVICE); k.st(0,28,IRQ_SWITCHES); k.st(0,28,IRQ_LASTPC)
k.ldi_label(0,'irq_handler'); k.st(0,28,IRQ_VECTOR)
k_abs(27,SLICE_BASE); k.ldi(0,0)
for _off in (0,4,8,12,16,20): k.st(0,27,_off)
k.ldi(0,1); k.st(0,28,IRQ_ENABLE)
k.jmp('main_loop')

# fill_rect: R0=x,R1=y,R2=w,R3=h,R4=color; clobber R5-R12
k.label('fill_rect')
k.mov(5,3)
k.mov(7,1); k.ldi(9,640); k.mul(7,9); k.add(7,0); k.shl(7,2)
k.ldi(10,DRAW_BASE_PTR); k.ld(10,10,0); k.add(7,10)
k.ldi(12,640); k.sub(12,2); k.shl(12,2)
k.label('fr_row')
k.mov(8,2)
k.label('fr_col')
k.st(4,7,0); k.addi(7,4); k.addi(8,-1); k.jnz(8,'fr_col')
k.add(7,12); k.addi(5,-1); k.jnz(5,'fr_row'); k.ret()

# draw_char: R0=x,R1=y,R2=ASCII,R3=color
k.label('draw_char')
k.ldi_label(8,'font_map'); k.mov(9,2); k.shl(9,2); k.add(8,9); k.ld(10,8,0)
k.ldi_label(11,'font_rows'); k.ldi(12,28); k.mul(10,12); k.add(11,10)
k.ldi(14,0)
k.label('dc_row')
k.mov(17,1); k.add(17,14); k.ldi(12,640); k.mul(17,12); k.add(17,0); k.shl(17,2)
k.ldi(18,DRAW_BASE_PTR); k.ld(18,18,0); k.add(17,18)
k.mov(12,14); k.shl(12,2); k.add(12,11); k.ld(15,12,0)
for ci,mask in enumerate((1,2,4,8,16)):
    k.mov(18,15); k.andi(18,mask); k.jz(18,f'dc_skip_{ci}'); k.st(3,17,0)
    k.label(f'dc_skip_{ci}'); k.addi(17,4)
k.addi(14,1); k.mov(18,14); k.addi(18,-7); k.jnz(18,'dc_row'); k.ret()

# draw_text: R0=x,R1=y,R2=ptr,R3=color
k.label('draw_text')
k.mov(4,2); k.mov(5,0); k.mov(6,1)
k.label('dt_loop')
k.ld(2,4,0); k.jz(2,'dt_done'); k.mov(0,5); k.mov(1,6); k.call('draw_char'); k.addi(5,6); k.addi(4,4); k.jmp('dt_loop')
k.label('dt_done'); k.ret()

# draw_char_big / draw_text_big: 2x crisp guest typography for OS headings.
# R0=x,R1=y,R2=ASCII,R3=color. A 5x7 glyph becomes 10x14 pixels.
k.label('draw_char_big')
k.ldi_label(8,'font_map'); k.mov(9,2); k.shl(9,2); k.add(8,9); k.ld(10,8,0)
k.ldi_label(11,'font_rows'); k.ldi(12,28); k.mul(10,12); k.add(11,10)
k.ldi(14,0)
k.label('dcb_row')
k.mov(17,14); k.shl(17,1); k.add(17,1); k.ldi(12,640); k.mul(17,12); k.add(17,0); k.shl(17,2)
k.ldi(18,DRAW_BASE_PTR); k.ld(18,18,0); k.add(17,18)
k.mov(19,17); k.ldi(20,10); k.shl(20,8); k.add(19,20)  # +2560 bytes = next scanline
k.mov(12,14); k.shl(12,2); k.add(12,11); k.ld(15,12,0)
for ci,mask in enumerate((1,2,4,8,16)):
    k.mov(18,15); k.andi(18,mask); k.jz(18,f'dcb_skip_{ci}')
    k.st(3,17,0); k.st(3,17,4); k.st(3,19,0); k.st(3,19,4)
    k.label(f'dcb_skip_{ci}'); k.addi(17,8); k.addi(19,8)
k.addi(14,1); k.mov(18,14); k.addi(18,-7); k.jnz(18,'dcb_row'); k.ret()

k.label('draw_text_big')
k.mov(4,2); k.mov(5,0); k.mov(6,1)
k.label('dtb_loop')
k.ld(2,4,0); k.jz(2,'dtb_done'); k.mov(0,5); k.mov(1,6); k.call('draw_char_big'); k.addi(5,12); k.addi(4,4); k.jmp('dtb_loop')
k.label('dtb_done'); k.ret()

# blit_rect: guest compositor copies a rectangular region from an app surface into
# physical display VRAM. R0=src base, R1=x, R2=y, R3=w, R4=h.
k.label('blit_rect')
k.mov(20,0); k.mov(21,1); k.mov(22,2); k.mov(23,3); k.mov(24,4)
# byte offset = ((y*640)+x)*4
k.mov(25,22); k.ldi(26,640); k.mul(25,26); k.add(25,21); k.shl(25,2)
k.add(20,25)
k.ldi(27,256); k.shl(27,8); k.add(27,25)  # display VRAM 0x10000 + offset
k.ldi(28,640); k.sub(28,23); k.shl(28,2)    # row skip
k.label('br_row')
k.mov(19,23)
k.label('br_col')
k.ld(18,20,0); k.st(18,27,0); k.addi(20,4); k.addi(27,4); k.addi(19,-1); k.jnz(19,'br_col')
k.add(20,28); k.add(27,28); k.addi(24,-1); k.jnz(24,'br_row'); k.ret()

# copy_rect_surface: stable preemptive frame publication. R0=src base,R1=dst base,
# R2=x,R3=y,R4=w,R5=h. Callers mask timer IRQ only for this finite copy so the
# compositor never observes a half-published frame.
k.label('copy_rect_surface')
k.mov(20,0); k.mov(21,1); k.mov(22,2); k.mov(23,3); k.mov(24,4); k.mov(25,5)
k.mov(26,23); k.ldi(27,640); k.mul(26,27); k.add(26,22); k.shl(26,2); k.add(20,26); k.add(21,26)
k.ldi(28,640); k.sub(28,24); k.shl(28,2)
k.label('crs_row'); k.mov(19,24)
k.label('crs_col'); k.ld(18,20,0); k.st(18,21,0); k.addi(20,4); k.addi(21,4); k.addi(19,-1); k.jnz(19,'crs_col')
k.add(20,28); k.add(21,28); k.addi(25,-1); k.jnz(25,'crs_row'); k.ret()

k.label('publish_raster')
k_abs(28,IRQ_BASE); k.ldi(17,0); k.st(17,28,IRQ_ENABLE)
k_abs(0,RASTER_BACK); k_abs(1,RASTER_SURF); state_base(); k.ld(2,29,S_RX); k.ld(3,29,S_RY); k.ldi(4,370); k.ldi(5,250); k.call('copy_rect_surface')
k_abs(28,IRQ_BASE); k.ldi(17,1); k.st(17,28,IRQ_ENABLE); k.ret()

k.label('publish_system')
k_abs(28,IRQ_BASE); k.ldi(17,0); k.st(17,28,IRQ_ENABLE)
k_abs(0,SYSTEM_BACK); k_abs(1,SYSTEM_SURF); state_base(); k.ld(2,29,S_SX); k.ld(3,29,S_SY); k.ldi(4,230); k.ldi(5,180); k.call('copy_rect_surface')
k_abs(28,IRQ_BASE); k.ldi(17,1); k.st(17,28,IRQ_ENABLE); k.ret()

k.label('publish_browser')
k_abs(28,IRQ_BASE); k.ldi(17,0); k.st(17,28,IRQ_ENABLE)
k.ldi(0,0xA0); k.shl(0,16); k_abs(1,BROWSER_SURF); k.ldi(2,10); k.ldi(3,34); k.ldi(4,620); k.ldi(5,310); k.call('copy_rect_surface')
k_abs(28,IRQ_BASE); k.ldi(17,1); k.st(17,28,IRQ_ENABLE); k.ret()

k.label('publish_terminal')
k_abs(28,IRQ_BASE); k.ldi(17,0); k.st(17,28,IRQ_ENABLE)
k.ldi(0,0xB0); k.shl(0,16); k.ldi(1,0x80); k.shl(1,16); k.ldi(2,55); k.ldi(3,70); k.ldi(4,420); k.ldi(5,220); k.call('copy_rect_surface')
k_abs(28,IRQ_BASE); k.ldi(17,1); k.st(17,28,IRQ_ENABLE); k.ret()

k.label('publish_editor')
k_abs(28,IRQ_BASE); k.ldi(17,0); k.st(17,28,IRQ_ENABLE)
k.ldi(0,0xC0); k.shl(0,16); k.ldi(1,0x90); k.shl(1,16); k.ldi(2,120); k.ldi(3,58); k.ldi(4,430); k.ldi(5,244); k.call('copy_rect_surface')
k_abs(28,IRQ_BASE); k.ldi(17,1); k.st(17,28,IRQ_ENABLE); k.ret()

# compositor helpers. Shadow and focus chrome are OS-owned and drawn into front VRAM.
k.label('compose_raster')
k.ldi(10,DRAW_BASE_PTR); k.ldi(11,256); k.shl(11,8); k.st(11,10,0)
state_base(); k.ld(1,29,S_RX); k.ld(2,29,S_RY)
# shadow at +6,+7
k.mov(0,1); k.addi(0,6); k.mov(5,2); k.addi(5,7); k.mov(1,5); k.ldi(2,370); k.ldi(3,250); k_color(4,8); k.call('fill_rect')
state_base(); k.ld(1,29,S_RX); k.ld(2,29,S_RY); k.ldi(0,0x1000); k.shl(0,8); k.ldi(3,370); k.ldi(4,250); k.call('blit_rect')
# focus accent top edge
state_base(); k.ld(8,29,S_FOCUS); k.addi(8,-1); k.jnz(8,'cr_done'); k.ld(0,29,S_RX); k.ld(1,29,S_RY); k.ldi(2,370); k.ldi(3,2); k_color(4,68); k.call('fill_rect')
k.label('cr_done'); k.ret()

k.label('compose_system')
k.ldi(10,DRAW_BASE_PTR); k.ldi(11,256); k.shl(11,8); k.st(11,10,0)
state_base(); k.ld(1,29,S_SX); k.ld(2,29,S_SY)
k.mov(0,1); k.addi(0,6); k.mov(5,2); k.addi(5,7); k.mov(1,5); k.ldi(2,230); k.ldi(3,180); k_color(4,8); k.call('fill_rect')
state_base(); k.ld(1,29,S_SX); k.ld(2,29,S_SY); k.ldi(0,0x2000); k.shl(0,8); k.ldi(3,230); k.ldi(4,180); k.call('blit_rect')
state_base(); k.ld(8,29,S_FOCUS); k.addi(8,-2); k.jnz(8,'cs_done'); k.ld(0,29,S_SX); k.ld(1,29,S_SY); k.ldi(2,230); k.ldi(3,2); k_color(4,84); k.call('fill_rect')
k.label('cs_done'); k.ret()

k.label('compose_browser')
k.ldi(10,DRAW_BASE_PTR); k.ldi(11,256); k.shl(11,8); k.st(11,10,0)
# browser is currently a near-maximized fixed guest window at 10,34
k.ldi(0,16); k.ldi(1,41); k.ldi(2,620); k.ldi(3,310); k_color(4,8); k.call('fill_rect')
k.ldi(0,0x3000); k.shl(0,8); k.ldi(1,10); k.ldi(2,34); k.ldi(3,620); k.ldi(4,310); k.call('blit_rect')
state_base(); k.ld(8,29,S_FOCUS); k.addi(8,-3); k.jnz(8,'cb_done'); k.ldi(0,10); k.ldi(1,34); k.ldi(2,620); k.ldi(3,2); k_color(4,68); k.call('fill_rect')
k.label('cb_done'); k.ret()

k.label('compose_terminal')
k.ldi(10,DRAW_BASE_PTR); k.ldi(11,256); k.shl(11,8); k.st(11,10,0)
k.ldi(0,61); k.ldi(1,77); k.ldi(2,420); k.ldi(3,220); k_color(4,8); k.call('fill_rect')
k.ldi(0,0x80); k.shl(0,16); k.ldi(1,55); k.ldi(2,70); k.ldi(3,420); k.ldi(4,220); k.call('blit_rect')
state_base(); k.ld(8,29,S_FOCUS); k.addi(8,-4); k.jnz(8,'ct_done'); k.ldi(0,55); k.ldi(1,70); k.ldi(2,420); k.ldi(3,2); k_color(4,80); k.call('fill_rect')
k.label('ct_done'); k.ret()

k.label('compose_editor')
k.ldi(10,DRAW_BASE_PTR); k.ldi(11,256); k.shl(11,8); k.st(11,10,0)
k.ldi(0,126); k.ldi(1,65); k.ldi(2,430); k.ldi(3,244); k_color(4,8); k.call('fill_rect')
k.ldi(0,0x90); k.shl(0,16); k.ldi(1,120); k.ldi(2,58); k.ldi(3,430); k.ldi(4,244); k.call('blit_rect')
state_base(); k.ld(8,29,S_FOCUS); k.addi(8,-5); k.jnz(8,'ce_done'); k.ldi(0,120); k.ldi(1,58); k.ldi(2,430); k.ldi(3,2); k_color(4,64); k.call('fill_rect')
k.label('ce_done'); k.ret()

# compose all open app surfaces in z-order; focused app is copied last.
k.label('compose')
# non-focused app surfaces
state_base(); k.ld(8,29,S_ROPEN); k.jz(8,'comp_no_r'); k.ld(9,29,S_FOCUS); k.addi(9,-1); k.jz(9,'comp_no_r'); k.call('compose_raster')
k.label('comp_no_r')
state_base(); k.ld(8,29,S_SOPEN); k.jz(8,'comp_no_s'); k.ld(9,29,S_FOCUS); k.addi(9,-2); k.jz(9,'comp_no_s'); k.call('compose_system')
k.label('comp_no_s')
state_base(); k.ld(8,29,S_BOPEN); k.jz(8,'comp_no_b'); k.ld(9,29,S_FOCUS); k.addi(9,-3); k.jz(9,'comp_no_b'); k.call('compose_browser')
k.label('comp_no_b')
proc_ctl_base(); k.ld(8,29,PC_TOPEN); k.jz(8,'comp_no_t'); state_base(); k.ld(9,29,S_FOCUS); k.addi(9,-4); k.jz(9,'comp_no_t'); k.call('compose_terminal')
k.label('comp_no_t')
proc_ctl_base(); k.ld(8,29,PC_EOPEN); k.jz(8,'comp_focus'); state_base(); k.ld(9,29,S_FOCUS); k.addi(9,-5); k.jz(9,'comp_focus'); k.call('compose_editor')
k.label('comp_focus')
state_base(); k.ld(9,29,S_FOCUS); k.addi(9,-1); k.jz(9,'comp_focus_r'); k.addi(9,-1); k.jz(9,'comp_focus_s'); k.addi(9,-1); k.jz(9,'comp_focus_b'); k.addi(9,-1); k.jz(9,'comp_focus_t'); k.addi(9,-1); k.jz(9,'comp_focus_e'); k.ret()
k.label('comp_focus_r'); k.ld(8,29,S_ROPEN); k.jz(8,'comp_done'); k.call('compose_raster'); k.jmp('comp_done')
k.label('comp_focus_s'); k.ld(8,29,S_SOPEN); k.jz(8,'comp_done'); k.call('compose_system'); k.jmp('comp_done')
k.label('comp_focus_b'); k.ld(8,29,S_BOPEN); k.jz(8,'comp_done'); k.call('compose_browser'); k.jmp('comp_done')
k.label('comp_focus_t'); proc_ctl_base(); k.ld(8,29,PC_TOPEN); k.jz(8,'comp_done'); k.call('compose_terminal'); k.jmp('comp_done')
k.label('comp_focus_e'); proc_ctl_base(); k.ld(8,29,PC_EOPEN); k.jz(8,'comp_done'); k.call('compose_editor')
k.label('comp_done'); k.ret()

# point_in_rect: R1=px,R2=py,R4=x,R5=y,R6=w,R7=h -> R0 0/1
k.label('hit_rect')
k.mov(8,1); k.sub(8,4); k.js(8,'hit_no')
k.mov(9,8); k.sub(9,6); k.js(9,'hit_x_ok'); k.jmp('hit_no')
k.label('hit_x_ok')
k.mov(8,2); k.sub(8,5); k.js(8,'hit_no')
k.mov(9,8); k.sub(9,7); k.js(9,'hit_yes'); k.jmp('hit_no')
k.label('hit_yes'); k.ldi(0,1); k.ret()
k.label('hit_no'); k.ldi(0,0); k.ret()

# guest modern 640x360 desktop shell: top status, navigation rail, workspace, activity, centered dock
k.label('desktop')
# native 640x360 layered wallpaper
call_rect(0,0,640,360,0)
call_rect(0,26,640,322,4)
call_rect(0,26,640,86,8)
call_rect(0,112,640,236,0)
# geometric accents / horizon lines
call_rect(470,36,154,4,64); call_rect(506,44,118,3,80); call_rect(542,51,82,2,112)
call_rect(162,300,180,2,32); call_rect(352,300,272,2,32)
# top status bar
call_rect(0,0,640,26,12)
call_rect(12,5,72,16,64); call_text(29,10,'s_pars',96)
call_text(96,10,'s_os13',96); call_text(180,10,'s_exact',112)
call_rect(489,5,40,16,16); call_text(499,10,'s_net',96)
call_rect(533,5,47,16,20); call_text(543,10,'s_pfs1',96)
call_rect(584,5,44,16,32); call_text(591,10,'s_wasmchip',96)
# left navigation rail
call_rect(14,40,142,260,32); call_rect(17,43,136,254,0)
call_text(28,52,'s_workspace',96); call_text(28,65,'s_quicklaunch',112)
# nav/app rows
call_rect(24,82,122,34,12); call_rect(27,85,4,28,64); call_text(39,89,'s_webbrowser',96); call_text(39,101,'s_http_pfs',112)
call_rect(24,122,122,34,12); call_rect(27,125,4,28,80); call_text(39,129,'s_3draster',96); call_text(39,141,'s_guestgpu',112)
call_rect(24,162,122,34,12); call_rect(27,165,4,28,64); call_text(39,169,'s_sysmonitor',96); call_text(39,181,'s_liveproc',112)
call_rect(24,202,122,34,12); call_rect(27,205,4,28,80); call_text(39,209,'s_files',96); call_text(39,221,'s_virtualdisk',112)
call_rect(24,242,122,34,12); call_rect(27,245,4,28,32); call_text(39,249,'s_aboutshort',96); call_text(39,261,'s_machine',112)
# main workspace heading
call_text_big(178,42,'s_welcome13',96); call_text(178,62,'s_native',112)
# capability cards
call_rect(178,82,138,70,32); call_rect(181,85,132,64,0); call_rect(181,85,4,64,64)
call_text(193,94,'s_network',96); call_text(193,109,'s_dnshttp',112); call_text(193,124,'s_online',80); call_text(193,138,'s_tcpudp',112)
call_rect(328,82,138,70,32); call_rect(331,85,132,64,0); call_rect(331,85,4,64,80)
call_text(343,94,'s_storage',96); call_text(343,109,'s_sixfiles',112); call_text(343,124,'s_ready',80); call_text(343,138,'s_virtualdisk',112)
call_rect(478,82,146,70,32); call_rect(481,85,140,64,0); call_rect(481,85,4,64,64)
call_text(493,94,'s_runtime',96); call_text(493,109,'s_cpu',112); call_text(493,124,'s_wasmready',80); call_text(493,138,'s_guestgpu',112)
# large activity panel
call_rect(178,164,446,124,32); call_rect(181,167,440,118,0)
call_text(194,177,'s_activity',96); call_text(503,177,'s_live',80)
call_text(194,198,'s_cpu',112); call_text(194,222,'s_vramlabel',112); call_text(194,246,'s_sched',112)
# tracks
call_rect(258,198,332,8,4); call_rect(258,222,332,8,4); call_rect(258,246,332,8,4)
# dynamic activity fills from scheduler tick
state_base(); k.ld(20,29,S_TICK)
k.mov(21,20); k.andi(21,127); k.addi(21,40); k.ldi(0,258); k.ldi(1,198); k.mov(2,21); k.ldi(3,8); k_color(4,64); k.call('fill_rect')
k.mov(22,20); k.sar(22,1); k.andi(22,127); k.addi(22,64); k.ldi(0,258); k.ldi(1,222); k.mov(2,22); k.ldi(3,8); k_color(4,80); k.call('fill_rect')
k.mov(23,20); k.sar(23,2); k.andi(23,127); k.addi(23,88); k.ldi(0,258); k.ldi(1,246); k.mov(2,23); k.ldi(3,8); k_color(4,64); k.call('fill_rect')
call_text(194,268,'s_boundary',112)
# centered dock
call_rect(172,312,296,38,32); call_rect(175,315,290,32,12)
call_rect(183,320,38,22,64); call_text(198,327,'s_p',96)
call_rect(229,320,48,22,4); call_text(243,327,'s_3d',96)
call_rect(285,320,54,22,4); call_text(300,327,'s_web',96)
call_rect(347,320,54,22,4); call_text(361,327,'s_sys',96)
call_rect(409,320,48,22,4); call_text(420,327,'s_pf',96)
# resident/open indicators
state_base(); k.ld(8,29,S_RRES); k.jz(8,'desk_no_r'); call_rect(245,344,16,2,64); k.label('desk_no_r')
state_base(); k.ld(8,29,S_BRES); k.jz(8,'desk_no_b'); call_rect(303,344,18,2,64); k.label('desk_no_b')
state_base(); k.ld(8,29,S_SRES); k.jz(8,'desk_no_s'); call_rect(365,344,18,2,80); k.label('desk_no_s')
k.ret()

# shell overlays are drawn after applications so launcher/files/about feel OS-owned
k.label('shell_overlay')
shell_state_base(); k.ld(8,29,SH_SHELL); k.jz(8,'overlay_menu_check'); k.addi(8,-1); k.jz(8,'overlay_files'); k.jmp('overlay_about')
k.label('overlay_files')
# centered file manager
call_rect(70,48,500,264,32); call_rect(73,51,494,258,0); call_rect(73,51,494,24,12)
call_text_big(88,55,'s_files',96); call_text(501,60,'s_close',112)
# sidebar
call_rect(82,84,112,214,4); call_text(94,94,'s_places',112); call_rect(88,111,100,26,12); call_text(99,120,'s_pfs1',96)
call_text(99,153,'s_apps',112); call_text(99,177,'s_web',112); call_text(99,201,'s_system',112); call_text(99,225,'s_storage',112)
# file table
call_text(214,88,'s_name',112); call_text(507,88,'s_size',112); call_rect(209,101,344,1,32)
for_y=[112,140,168,196,224,252]
# explicit rows keep the byte stream inspectable
call_rect(209,106,344,24,12); call_text(216,114,'s_rasterbin',96); call_text(511,114,'s_2k',112)
call_text(216,142,'s_systembin',96); call_text(511,142,'s_2k',112)
call_rect(209,162,344,24,12); call_text(216,170,'s_browserbin',96); call_text(511,170,'s_7k',112)
call_text(216,198,'s_terminal',96); call_text(511,198,'s_2k',112)
call_rect(209,218,344,24,12); call_text(216,226,'s_editor',96); call_text(511,226,'s_1k',112)
call_text(216,254,'s_wasmhtml',96); call_text(511,254,'s_1k',112)
# PFS2 user row appears only after Terminal/Editor creates a file.
k_abs(28,PFS2_BASE); k.ld(8,28,P2_EXISTS); k.jz(8,'files_no_pfs2')
call_rect(209,274,344,24,12); call_text(216,282,'s_userhtml',80); call_text(505,282,'s_user',112)
k.label('files_no_pfs2'); call_text(216,302,'s_diskfooter15',112)
k.jmp('overlay_menu_check')
k.label('overlay_about')
call_rect(145,72,350,220,32); call_rect(148,75,344,214,0); call_rect(148,75,344,24,64)
call_text_big(164,79,'s_about',96); call_text(426,84,'s_close',96)
call_text(166,116,'s_exact',96); call_text(166,135,'s_native',112); call_text(166,154,'s_tinycpu',112); call_text(166,173,'s_pfssystem',112); call_text(166,192,'s_dnsh',112); call_text(166,211,'s_wasminterp',112); call_text(166,230,'s_soft3d',80); call_text(166,255,'s_x11strip',112); call_text(166,274,'s_boundary',112)
# Terminal and Editor are independent preemptive PFS1 processes in VM/20.
k.label('overlay_menu_check')
shell_state_base(); k.ld(8,29,SH_MENU); k.jz(8,'overlay_done')
# app launcher
call_rect(18,36,304,270,32); call_rect(21,39,298,264,0); call_rect(21,39,298,24,64)
call_text_big(36,44,'s_launcher',96)
call_rect(32,72,276,24,4); call_text(45,80,'s_search',112)
call_text(36,108,'s_apps',112)
call_rect(32,122,276,34,12); call_rect(36,126,4,26,64); call_text(50,131,'s_webbrowser',96); call_text(50,143,'s_http_pfs',112)
call_rect(32,162,276,34,12); call_rect(36,166,4,26,80); call_text(50,171,'s_3draster',96); call_text(50,183,'s_guestgpu',112)
call_rect(32,202,276,34,12); call_rect(36,206,4,26,64); call_text(50,211,'s_sysmonitor',96); call_text(50,223,'s_liveproc',112)
call_rect(32,246,132,38,12); call_text(48,259,'s_terminal',96)
call_rect(176,246,132,38,12); call_text(194,259,'s_editor',96)
k.label('overlay_done'); k.ret()

# guest-drawn mouse cursor, always drawn last
k.label('cursor')
state_base(); k.ld(0,29,S_CX); k.ld(1,29,S_CY)
k.mov(20,0); k.mov(21,1)
k.ldi(2,3); k.ldi(3,14); k_color(4,96); k.call('fill_rect')
k.mov(0,20); k.mov(1,21); k.addi(1,10); k.ldi(2,10); k.ldi(3,3); k_color(4,96); k.call('fill_rect')
k.mov(0,20); k.addi(0,3); k.mov(1,21); k.addi(1,3); k.ldi(2,3); k.ldi(3,10); k_color(4,112); k.call('fill_rect')
k.ret()

# generic loader overlay. R17=file id, R18=label selector (1 raster,2 system,3 browser)
k.label('loader')
k.mov(27,17); k.mov(28,18)
k.ldi(10,DRAW_BASE_PTR); k.ldi(11,256); k.shl(11,8); k.st(11,10,0)
k.call('desktop')
call_rect(120,92,400,166,32); call_rect(123,95,394,160,0); call_rect(123,95,394,24,64)
call_text(140,104,'s_loader',96)
k.mov(7,28); k.addi(7,-1); k.jz(7,'load_text_r')
k.addi(7,-1); k.jz(7,'load_text_s')
k.addi(7,-1); k.jz(7,'load_text_b')
k.addi(7,-1); k.jz(7,'load_text_t')
call_text(142,137,'s_path_edit',96); k.jmp('load_text_done')
k.label('load_text_t'); call_text(142,137,'s_path_term',96); k.jmp('load_text_done')
k.label('load_text_b'); call_text(142,137,'s_path_web',96); k.jmp('load_text_done')
k.label('load_text_s'); call_text(142,137,'s_path_sys',96); k.jmp('load_text_done')
k.label('load_text_r'); call_text(142,137,'s_path_r3d',96)
k.label('load_text_done')
call_text(142,158,'s_pfsread',112); call_text(142,179,'s_launching',112)
call_rect(142,205,356,14,4); call_rect(145,208,350,8,12); k.sys(3)
k.ldi(24,3); k.label('loader_intro_wait'); k.sys(4); k.addi(24,-1); k.jnz(24,'loader_intro_wait')
# directory
k.ldi(0,0); k.ldi(1,DIRBUF); k.ldi(2,1); k.sys(5)
k.ldi(6,DIRBUF); k.ld(7,6,0); k.ldi_label(8,'pfs_magic_const'); k.ld(8,8,0); k.sub(7,8); k.jnz(7,'fs_error')
k.ldi(6,DIRBUF); k.ld(19,6,4); k.addi(6,16)
k.label('dir_scan')
k.ld(7,6,0); k.mov(8,7); k.sub(8,27); k.jz(8,'dir_found')
k.addi(6,64); k.addi(19,-1); k.jnz(19,'dir_scan'); k.jmp('fs_error')
k.label('dir_found')
k.ld(19,6,8); k.ld(20,6,12); k.ld(21,6,20); k.ldi(22,0)
k.label('load_block_loop')
k.mov(0,19); k.add(0,22); k.mov(1,21); k.ldi(2,1); k.sys(5)
# progress, width 26 each block
k.mov(0,22); k.ldi(5,8); k.mul(0,5); k.ldi(15,147); k.add(0,15); k.ldi(1,208); k.ldi(2,7); k.ldi(3,8); k_color(4,64); k.call('fill_rect'); k.sys(3)
k.ldi(24,4); k.label('loader_tick'); k.sys(4); k.addi(24,-1); k.jnz(24,'loader_tick')
k.ldi(6,512); k.add(21,6); k.addi(22,1); k.mov(23,22); k.sub(23,20); k.jnz(23,'load_block_loop')
call_text(261,232,'s_exec',96); k.sys(3)
k.ldi(24,5); k.label('loader_exec_wait'); k.sys(4); k.addi(24,-1); k.jnz(24,'loader_exec_wait')
k.ret()

k.label('fs_error')
call_rect(142,202,356,26,0); call_text(252,211,'s_fserr',128); k.sys(3)
k.ldi(24,18); k.label('err_wait'); k.sys(4); k.addi(24,-1); k.jnz(24,'err_wait'); k.ret()

# Launch every major application as a separately loaded preemptive process.
k.label('open_raster')
state_base(); k.ld(8,29,S_RRES); k.jnz(8,'raster_resident')
k.ldi(17,0x3d01); k.ldi(18,1); k.call('loader'); k.ldi(17,1); k_abs(18,RASTER_LOAD); k_abs(19,PROC1_STACK); k.call('proc_init')
state_base(); k.ldi(8,1); k.st(8,29,S_RRES)
k.label('raster_resident'); state_base(); k.ldi(8,1); k.st(8,29,S_ROPEN); k.st(8,29,S_FOCUS); k.ret()

k.label('open_system')
state_base(); k.ld(8,29,S_SRES); k.jnz(8,'system_resident')
k.ldi(17,0x5a01); k.ldi(18,2); k.call('loader'); k.ldi(17,2); k_abs(18,SYSTEM_LOAD); k_abs(19,PROC2_STACK); k.call('proc_init')
state_base(); k.ldi(8,1); k.st(8,29,S_SRES)
k.label('system_resident'); state_base(); k.ldi(8,1); k.st(8,29,S_SOPEN); k.ldi(8,2); k.st(8,29,S_FOCUS); k.ret()

k.label('open_browser')
state_base(); k.ld(8,29,S_BRES); k.jnz(8,'browser_resident')
k.ldi(17,0x6901); k.ldi(18,3); k.call('loader'); k.ldi(17,3); k_abs(18,BROWSER_LOAD); k_abs(19,PROC3_STACK); k.call('proc_init')
state_base(); k.ldi(8,1); k.st(8,29,S_BRES)
k.label('browser_resident'); state_base(); k.ldi(8,1); k.st(8,29,S_BOPEN); k.ldi(8,3); k.st(8,29,S_FOCUS); k.ret()

k.label('open_terminal')
proc_ctl_base(); k.ld(8,29,PC_TRES); k.jnz(8,'terminal_resident')
k.ldi(17,0x7101); k.ldi(18,4); k.call('loader'); k.ldi(17,4); k_abs(18,TERMINAL_LOAD); k_abs(19,PROC4_STACK); k.call('proc_init')
proc_ctl_base(); k.ldi(8,1); k.st(8,29,PC_TRES)
k.label('terminal_resident'); proc_ctl_base(); k.ldi(8,1); k.st(8,29,PC_TOPEN); state_base(); k.ldi(8,4); k.st(8,29,S_FOCUS); k.ret()

k.label('open_editor')
proc_ctl_base(); k.ld(8,29,PC_ERES); k.jnz(8,'editor_resident')
# Opening Editor from launcher creates a blank guest file if none exists.
k_abs(28,PFS2_BASE); k.ld(9,28,P2_EXISTS); k.jnz(9,'editor_file_ready'); k.ldi(9,1); k.st(9,28,P2_EXISTS); k.ldi(9,0); k.st(9,28,P2_EDITLEN); k.st(9,28,P2_DIRTY); k_abs(27,PFS2_EDIT); k.st(9,27,0)
k.label('editor_file_ready'); k.ldi(17,0x7201); k.ldi(18,5); k.call('loader'); k.ldi(17,5); k_abs(18,EDITOR_LOAD); k_abs(19,PROC5_STACK); k.call('proc_init')
proc_ctl_base(); k.ldi(8,1); k.st(8,29,PC_ERES)
k.label('editor_resident'); proc_ctl_base(); k.ldi(8,1); k.st(8,29,PC_EOPEN); state_base(); k.ldi(8,5); k.st(8,29,S_FOCUS); k.ret()

# Kernel services requested by user processes. PC_REQ: 1=kill raster, 2=open editor, 3=run raster.
k.label('service_requests')
proc_ctl_base(); k.ld(8,29,PC_REQ); k.jz(8,'service_done'); k.ldi(9,0); k.st(9,29,PC_REQ)
k.mov(10,8); k.addi(10,-1); k.jz(10,'service_kill_raster'); k.addi(10,-1); k.jz(10,'service_open_editor'); k.addi(10,-1); k.jz(10,'service_run_raster'); k.ret()
k.label('service_kill_raster')
# Stop PID1 and reclaim its visible/resident state. PCB remains as postmortem evidence.
proc_ctl_base(); k.ldi(9,0); k.st(9,29,PC_RUN0+4); k.st(9,29,PC_RHANG)
state_base(); k.st(9,29,S_RRES); k.st(9,29,S_ROPEN); k.ld(10,29,S_FOCUS); k.addi(10,-1); k.jnz(10,'service_done'); k.st(9,29,S_FOCUS); k.ret()
k.label('service_open_editor'); k.call('open_editor'); k.ret()
k.label('service_run_raster'); k.call('open_raster')
k.label('service_done'); k.ret()

# Display pass: all applications now execute independently under timer IRQ preemption.
k.label('schedule')
k.call('compose'); k.ret()

# unpack mouse packed R1 => R1=x,R2=y and store cursor
k.label('mouse_unpack')
k.mov(2,1); k.sar(2,16); k.shl(1,16); k.sar(1,16)
# clamp guest cursor so its drawn shape never leaves VRAM
k.mov(8,1); k.ldi(9,631); k.sub(8,9); k.js(8,'mouse_x_ok'); k.ldi(1,630)
k.label('mouse_x_ok'); k.mov(8,2); k.ldi(9,346); k.sub(8,9); k.js(8,'mouse_y_ok'); k.ldi(2,345)
k.label('mouse_y_ok'); state_base(); k.st(1,29,S_CX); k.st(2,29,S_CY); k.ret()

# update dragged window from current R1/R2 using stored drag offsets
k.label('drag_update')
state_base(); k.ld(8,29,S_DRAG); k.jz(8,'drag_done')
k.ld(9,29,S_DX); k.ld(10,29,S_DY); k.mov(11,1); k.sub(11,9); k.mov(12,2); k.sub(12,10)
# clamp y >= 30
k.mov(13,12); k.addi(13,-30); k.js(13,'drag_y_min'); k.jmp('drag_y_min_done')
k.label('drag_y_min'); k.ldi(12,30)
k.label('drag_y_min_done')
# which window
k.mov(13,8); k.addi(13,-1); k.jz(13,'drag_raster')
# system x clamp 0..410, y <=180
k.js(11,'sys_x_min'); k.mov(13,11); k.ldi(14,411); k.sub(13,14); k.js(13,'sys_x_ok'); k.ldi(11,410); k.jmp('sys_x_ok')
k.label('sys_x_min'); k.ldi(11,0)
k.label('sys_x_ok')
k.mov(13,12); k.ldi(14,181); k.sub(13,14); k.js(13,'sys_y_ok'); k.ldi(12,180)
k.label('sys_y_ok'); state_base(); k.st(11,29,S_SX); k.st(12,29,S_SY); k.jmp('drag_done')
k.label('drag_raster')
k.js(11,'ras_x_min'); k.mov(13,11); k.ldi(14,271); k.sub(13,14); k.js(13,'ras_x_ok'); k.ldi(11,270); k.jmp('ras_x_ok')
k.label('ras_x_min'); k.ldi(11,0)
k.label('ras_x_ok')
k.mov(13,12); k.ldi(14,111); k.sub(13,14); k.js(13,'ras_y_ok'); k.ldi(12,110)
k.label('ras_y_ok'); state_base(); k.st(11,29,S_RX); k.st(12,29,S_RY)
k.label('drag_done'); k.ret()

# mouse press: OS chrome/launcher/dock first, then window controls and dragging
k.label('mouse_press')
k.call('mouse_unpack')
# PARS launcher button
k.ldi(4,12); k.ldi(5,5); k.ldi(6,72); k.ldi(7,16); k.call('hit_rect'); k.jz(0,'press_shell_close')
shell_state_base(); k.ld(8,29,SH_MENU); k.jz(8,'menu_turn_on'); k.ldi(8,0); k.st(8,29,SH_MENU); k.ret()
k.label('menu_turn_on'); k.ldi(8,1); k.st(8,29,SH_MENU); k.ldi(8,0); k.st(8,29,SH_SHELL); k.ret()
# close built-in shell panels
k.label('press_shell_close')
shell_state_base(); k.ld(8,29,SH_SHELL); k.jz(8,'press_menu_items')
k.mov(9,8); k.addi(9,-1); k.jz(9,'close_files_hit')
# about close
k.ldi(4,418); k.ldi(5,76); k.ldi(6,70); k.ldi(7,24); k.call('hit_rect'); k.jz(0,'press_menu_items'); shell_state_base(); k.ldi(8,0); k.st(8,29,SH_SHELL); k.ret()
k.label('close_files_hit'); k.ldi(4,493); k.ldi(5,50); k.ldi(6,66); k.ldi(7,26); k.call('hit_rect'); k.jz(0,'press_menu_items'); shell_state_base(); k.ldi(8,0); k.st(8,29,SH_SHELL); k.ret()
# launcher menu items
k.label('press_menu_items')
shell_state_base(); k.ld(8,29,SH_MENU); k.jz(8,'press_desktop_nav')
k.ldi(4,32); k.ldi(5,122); k.ldi(6,276); k.ldi(7,34); k.call('hit_rect'); k.jz(0,'menu_raster'); shell_state_base(); k.ldi(8,0); k.st(8,29,SH_MENU); k.call('open_browser'); k.ret()
k.label('menu_raster'); k.ldi(4,32); k.ldi(5,162); k.ldi(6,276); k.ldi(7,34); k.call('hit_rect'); k.jz(0,'menu_system'); shell_state_base(); k.ldi(8,0); k.st(8,29,SH_MENU); k.call('open_raster'); k.ret()
k.label('menu_system'); k.ldi(4,32); k.ldi(5,202); k.ldi(6,276); k.ldi(7,34); k.call('hit_rect'); k.jz(0,'menu_files'); shell_state_base(); k.ldi(8,0); k.st(8,29,SH_MENU); k.call('open_system'); k.ret()
k.label('menu_files'); k.ldi(4,32); k.ldi(5,246); k.ldi(6,132); k.ldi(7,38); k.call('hit_rect'); k.jz(0,'menu_about'); shell_state_base(); k.ldi(8,0); k.st(8,29,SH_MENU); k.call('open_terminal'); k.ret()
k.label('menu_about'); k.ldi(4,176); k.ldi(5,246); k.ldi(6,132); k.ldi(7,38); k.call('hit_rect'); k.jz(0,'menu_outside'); shell_state_base(); k.ldi(8,0); k.st(8,29,SH_MENU); k.call('open_editor'); k.ret()
k.label('menu_outside'); shell_state_base(); k.ldi(8,0); k.st(8,29,SH_MENU)
# desktop navigation rail
k.label('press_desktop_nav')
k.ldi(4,24); k.ldi(5,82); k.ldi(6,122); k.ldi(7,34); k.call('hit_rect'); k.jz(0,'nav_raster'); k.call('open_browser'); k.ret()
k.label('nav_raster'); k.ldi(4,24); k.ldi(5,122); k.ldi(6,122); k.ldi(7,34); k.call('hit_rect'); k.jz(0,'nav_system'); k.call('open_raster'); k.ret()
k.label('nav_system'); k.ldi(4,24); k.ldi(5,162); k.ldi(6,122); k.ldi(7,34); k.call('hit_rect'); k.jz(0,'nav_files'); k.call('open_system'); k.ret()
k.label('nav_files'); k.ldi(4,24); k.ldi(5,202); k.ldi(6,122); k.ldi(7,34); k.call('hit_rect'); k.jz(0,'nav_about'); shell_state_base(); k.ldi(8,1); k.st(8,29,SH_SHELL); k.ret()
k.label('nav_about'); k.ldi(4,24); k.ldi(5,242); k.ldi(6,122); k.ldi(7,34); k.call('hit_rect'); k.jz(0,'press_dock'); shell_state_base(); k.ldi(8,2); k.st(8,29,SH_SHELL); k.ret()
# centered dock
k.label('press_dock')
k.ldi(4,183); k.ldi(5,320); k.ldi(6,38); k.ldi(7,22); k.call('hit_rect'); k.jz(0,'dock_raster'); shell_state_base(); k.ldi(8,1); k.st(8,29,SH_MENU); k.ldi(8,0); k.st(8,29,SH_SHELL); k.ret()
k.label('dock_raster'); k.ldi(4,229); k.ldi(5,320); k.ldi(6,48); k.ldi(7,22); k.call('hit_rect'); k.jz(0,'dock_browser'); k.call('open_raster'); k.ret()
k.label('dock_browser'); k.ldi(4,285); k.ldi(5,320); k.ldi(6,54); k.ldi(7,22); k.call('hit_rect'); k.jz(0,'dock_system'); k.call('open_browser'); k.ret()
k.label('dock_system'); k.ldi(4,347); k.ldi(5,320); k.ldi(6,54); k.ldi(7,22); k.call('hit_rect'); k.jz(0,'dock_files'); k.call('open_system'); k.ret()
k.label('dock_files'); k.ldi(4,409); k.ldi(5,320); k.ldi(6,48); k.ldi(7,22); k.call('hit_rect'); k.jz(0,'press_check_raster'); shell_state_base(); k.ldi(8,1); k.st(8,29,SH_SHELL); k.ldi(8,0); k.st(8,29,SH_MENU); k.ret()
# raster close/minimize/title drag
k.label('press_check_raster')
state_base(); k.ld(8,29,S_ROPEN); k.jz(8,'press_check_system')
k.ld(4,29,S_RX); k.ldi(15,348); k.add(4,15); k.ld(5,29,S_RY); k.addi(5,5); k.ldi(6,14); k.ldi(7,14); k.call('hit_rect'); k.jz(0,'raster_min_check'); state_base(); k.ldi(8,0); k.st(8,29,S_ROPEN); k.st(8,29,S_RRES); k.st(8,29,S_FOCUS); proc_ctl_base(); k.st(8,29,PC_RUN0+4); k.ret()
k.label('raster_min_check'); state_base(); k.ld(4,29,S_RX); k.ldi(15,329); k.add(4,15); k.ld(5,29,S_RY); k.addi(5,5); k.ldi(6,14); k.ldi(7,14); k.call('hit_rect'); k.jz(0,'raster_drag_check'); state_base(); k.ldi(8,0); k.st(8,29,S_ROPEN); k.st(8,29,S_FOCUS); k.ret()
k.label('raster_drag_check'); state_base(); k.ld(4,29,S_RX); k.ld(5,29,S_RY); k.ldi(6,370); k.ldi(7,22); k.call('hit_rect'); k.jz(0,'press_check_system')
state_base(); k.ldi(8,1); k.st(8,29,S_DRAG); k.st(8,29,S_FOCUS); k.ld(9,29,S_RX); k.ld(10,29,S_RY); k.mov(11,1); k.sub(11,9); k.mov(12,2); k.sub(12,10); k.st(11,29,S_DX); k.st(12,29,S_DY); k.ret()
# system close/minimize/title drag
k.label('press_check_system')
state_base(); k.ld(8,29,S_SOPEN); k.jz(8,'press_none')
k.ld(4,29,S_SX); k.ldi(15,208); k.add(4,15); k.ld(5,29,S_SY); k.addi(5,5); k.ldi(6,14); k.ldi(7,14); k.call('hit_rect'); k.jz(0,'system_min_check'); state_base(); k.ldi(8,0); k.st(8,29,S_SOPEN); k.st(8,29,S_SRES); k.st(8,29,S_FOCUS); proc_ctl_base(); k.st(8,29,PC_RUN0+8); k.ret()
k.label('system_min_check'); state_base(); k.ld(4,29,S_SX); k.ldi(15,189); k.add(4,15); k.ld(5,29,S_SY); k.addi(5,5); k.ldi(6,14); k.ldi(7,14); k.call('hit_rect'); k.jz(0,'system_drag_check'); state_base(); k.ldi(8,0); k.st(8,29,S_SOPEN); k.st(8,29,S_FOCUS); k.ret()
k.label('system_drag_check'); state_base(); k.ld(4,29,S_SX); k.ld(5,29,S_SY); k.ldi(6,230); k.ldi(7,22); k.call('hit_rect'); k.jz(0,'press_check_terminal')
state_base(); k.ldi(8,2); k.st(8,29,S_DRAG); k.st(8,29,S_FOCUS); k.ld(9,29,S_SX); k.ld(10,29,S_SY); k.mov(11,1); k.sub(11,9); k.mov(12,2); k.sub(12,10); k.st(11,29,S_DX); k.st(12,29,S_DY); k.ret()
k.label('press_check_terminal'); proc_ctl_base(); k.ld(8,29,PC_TOPEN); k.jz(8,'press_check_editor'); k.ldi(4,55); k.ldi(5,70); k.ldi(6,420); k.ldi(7,220); k.call('hit_rect'); k.jz(0,'press_check_editor'); state_base(); k.ldi(8,4); k.st(8,29,S_FOCUS); k.ret()
k.label('press_check_editor'); proc_ctl_base(); k.ld(8,29,PC_EOPEN); k.jz(8,'press_none'); k.ldi(4,120); k.ldi(5,58); k.ldi(6,430); k.ldi(7,244); k.call('hit_rect'); k.jz(0,'press_none'); state_base(); k.ldi(8,5); k.st(8,29,S_FOCUS); k.ret()
k.label('press_none'); k.ldi(8,0); state_base(); k.st(8,29,S_FOCUS); k.ret()

# App keyboard handling moved into BROWSER.BIN / TERMINAL.BIN / EDITOR.BIN.

# VM/20 process context utilities. Hardware places R0-R31 + interrupted PC in
# TRAP_BASE. The kernel copies that trap frame to/from 0x100-byte PCBs.
k.label('copy33')
# R20=source, R21=destination; clobber R22/R23
k.ldi(22,33)
k.label('copy33_loop'); k.ld(23,20,0); k.st(23,21,0); k.addi(20,4); k.addi(21,4); k.addi(22,-1); k.jnz(22,'copy33_loop'); k.ret()

k.label('zero33')
# R20=destination
k.ldi(22,33); k.ldi(23,0)
k.label('zero33_loop'); k.st(23,20,0); k.addi(20,4); k.addi(22,-1); k.jnz(22,'zero33_loop'); k.ret()

k.label('proc_init')
# R17=PID, R18=entry PC, R19=stack. All six contexts use the same PCB ABI.
k_abs(28,IRQ_BASE); k.ldi(8,0); k.st(8,28,IRQ_ENABLE)
k_abs(20,PCB_BASE); k.mov(21,17); k.shl(21,8); k.add(20,21); k.call('zero33')
k_abs(20,PCB_BASE); k.mov(21,17); k.shl(21,8); k.add(20,21); k.st(19,20,124); k_abs(23,PCB_BASE+128); k.mov(21,17); k.shl(21,8); k.add(23,21); k.st(18,23,0)
proc_ctl_base(); k.mov(21,17); k.shl(21,2); k.addi(21,PC_RUN0); k.add(29,21); k.ldi(22,1); k.st(22,29,0)
k_abs(28,IRQ_BASE); k.ldi(8,1); k.st(8,28,IRQ_ENABLE); k.ret()

# Timer IRQ vector. Trap-frame creation is hardware; selection/context management is guest OS code.
k.label('irq_handler')
k_abs(28,IRQ_BASE); k.ld(8,28,IRQ_CURPID)
k_abs(20,TRAP_BASE+128); k.ld(9,20,0); k.st(9,28,IRQ_LASTPC)
# save hardware trap frame -> current PCB
k_abs(20,TRAP_BASE); k_abs(21,PCB_BASE); k.mov(22,8); k.shl(22,8); k.add(21,22); k.call('copy33')
# account preempted slice
k_abs(20,SLICE_BASE); k.mov(21,8); k.shl(21,2); k.add(20,21); k.ld(22,20,0); k.addi(22,1); k.st(22,20,0)
# Generic round-robin over PID0..PID5. PID0 is permanently runnable.
k.mov(12,8); k.addi(12,1)
k.label('irq_next_wrap'); k.mov(13,12); k.addi(13,-6); k.jnz(13,'irq_check_next'); k.ldi(12,0)
k.label('irq_check_next'); k.jz(12,'irq_chosen')
proc_ctl_base(); k.mov(13,12); k.shl(13,2); k.addi(13,PC_RUN0); k.add(29,13); k.ld(14,29,0); k.jnz(14,'irq_chosen')
k.addi(12,1); k.jmp('irq_next_wrap')
k.label('irq_chosen')
# load selected PCB -> hardware trap frame
k_abs(20,PCB_BASE); k.mov(21,12); k.shl(21,8); k.add(20,21); k_abs(21,TRAP_BASE); k.call('copy33')
# publish selected PID + switch count
k_abs(28,IRQ_BASE); k.st(12,28,IRQ_CURPID); k.ld(13,28,IRQ_SWITCHES); k.addi(13,1); k.st(13,28,IRQ_SWITCHES)
# Restore process-specific draw target. Apps render into private back buffers.
k.ldi(10,DRAW_BASE_PTR); k.mov(14,12); k.jz(14,'irq_draw_front'); k.addi(14,-1); k.jz(14,'irq_draw_raster'); k.addi(14,-1); k.jz(14,'irq_draw_system'); k.addi(14,-1); k.jz(14,'irq_draw_browser'); k.addi(14,-1); k.jz(14,'irq_draw_terminal'); k.jmp('irq_draw_editor')
k.label('irq_draw_front'); k.ldi(15,256); k.shl(15,8); k.st(15,10,0); k.jmp('irq_do_iret')
k.label('irq_draw_raster'); k.ldi(15,0x6000); k.shl(15,8); k.st(15,10,0); k.jmp('irq_do_iret')
k.label('irq_draw_system'); k.ldi(15,0x7000); k.shl(15,8); k.st(15,10,0); k.jmp('irq_do_iret')
k.label('irq_draw_browser'); k.ldi(15,0xA0); k.shl(15,16); k.st(15,10,0); k.jmp('irq_do_iret')
k.label('irq_draw_terminal'); k.ldi(15,0xB0); k.shl(15,16); k.st(15,10,0); k.jmp('irq_do_iret')
k.label('irq_draw_editor'); k.ldi(15,0xC0); k.shl(15,16); k.st(15,10,0)
k.label('irq_do_iret'); k.iret()

# main loop: background -> preemptive processes -> guest cursor -> present -> input
k.label('main_loop')
k.call('service_requests')
k.ldi(10,DRAW_BASE_PTR); k.ldi(11,256); k.shl(11,8); k.st(11,10,0)
k.call('desktop'); k.call('schedule'); k.call('shell_overlay'); k.call('cursor'); k.sys(3)
state_base(); k.ld(8,29,S_TICK); k.addi(8,1); k.st(8,29,S_TICK)
k.sys(4)
k.jz(0,'main_loop')
# mouse motion/press/release codes 10/11/12 remain global
k.mov(8,0); k.addi(8,-10); k.jz(8,'main_motion')
k.mov(8,0); k.addi(8,-11); k.jz(8,'main_press')
k.mov(8,0); k.addi(8,-12); k.jz(8,'main_release')
# Route keyboard events to independently scheduled application mailboxes.
state_base(); k.ld(8,29,S_FOCUS); k.mov(9,8); k.addi(9,-3); k.jz(9,'main_key_browser'); k.addi(9,-1); k.jz(9,'main_key_terminal'); k.addi(9,-1); k.jz(9,'main_key_editor'); k.jmp('main_key_global')
k.label('main_key_browser'); proc_ctl_base(); k.st(0,29,PC_BKEY); k.jmp('main_loop')
k.label('main_key_terminal'); proc_ctl_base(); k.st(0,29,PC_TKEY); k.jmp('main_loop')
k.label('main_key_editor'); proc_ctl_base(); k.st(0,29,PC_EKEY); k.jmp('main_loop')
k.label('main_key_global')
# keyboard Q
k.mov(8,0); k.addi(8,-5); k.jz(8,'poweroff')
# keyboard ENTER opens raster
k.mov(8,0); k.addi(8,-1); k.jz(8,'main_enter')
# A/D commands to raster
k.mov(8,0); k.addi(8,-2); k.jz(8,'main_a')
k.mov(8,0); k.addi(8,-3); k.jz(8,'main_d')
# ESC hides focused app
k.mov(8,0); k.addi(8,-4); k.jz(8,'main_esc')
k.jmp('main_loop')
k.label('main_enter'); k.call('open_raster'); k.jmp('main_loop')
k.label('main_a'); state_base(); k.ldi(8,-1); k.st(8,29,S_CMD); k.jmp('main_loop')
k.label('main_d'); state_base(); k.ldi(8,1); k.st(8,29,S_CMD); k.jmp('main_loop')
k.label('main_esc')
shell_state_base(); k.ld(8,29,SH_MENU); k.jz(8,'esc_check_shell'); k.ldi(8,0); k.st(8,29,SH_MENU); k.jmp('main_loop')
k.label('esc_check_shell'); shell_state_base(); k.ld(8,29,SH_SHELL); k.jz(8,'esc_check_focus'); k.ldi(8,0); k.st(8,29,SH_SHELL); k.jmp('main_loop')
k.label('esc_check_focus'); state_base(); k.ld(8,29,S_FOCUS); k.addi(8,-1); k.jz(8,'esc_r'); k.addi(8,-1); k.jz(8,'esc_s'); k.jmp('main_loop')
k.label('esc_r'); k.ldi(8,0); k.st(8,29,S_ROPEN); k.st(8,29,S_FOCUS); k.jmp('main_loop')
k.label('esc_s'); k.ldi(8,0); k.st(8,29,S_SOPEN); k.st(8,29,S_FOCUS); k.jmp('main_loop')
k.label('main_motion'); k.call('mouse_unpack'); k.call('drag_update'); k.jmp('main_loop')
k.label('main_press')
# Native browser owns address/navigation controls; kernel handles its window buttons and high-level actions.
state_base(); k.ld(8,29,S_BOPEN); k.jz(8,'main_press_normal'); k.call('mouse_unpack')
# close browser: unload process state so next launch re-reads PFS1
k.ldi(4,606); k.ldi(5,43); k.ldi(6,14); k.ldi(7,12); k.call('hit_rect'); k.jz(0,'browser_press_min'); state_base(); k.ldi(8,0); k.st(8,29,S_BOPEN); k.st(8,29,S_BRES); k.st(8,29,S_FOCUS); proc_ctl_base(); k.st(8,29,PC_RUN0+12); k.jmp('main_loop')
# minimize browser: keep resident process + browser RAM
k.label('browser_press_min'); k.ldi(4,586); k.ldi(5,43); k.ldi(6,14); k.ldi(7,12); k.call('hit_rect'); k.jz(0,'browser_press_addr'); state_base(); k.ldi(8,0); k.st(8,29,S_BOPEN); k.st(8,29,S_FOCUS); k.jmp('main_loop')
# address bar click clears current address (action 3)
k.label('browser_press_addr'); k.ldi(4,20); k.ldi(5,69); k.ldi(6,600); k.ldi(7,28); k.call('hit_rect'); k.jz(0,'browser_press_back'); state_base(); k.ldi(8,3); k.st(8,29,S_BACTION); k.jmp('main_loop')
k.label('browser_press_back'); k.ldi(4,20); k.ldi(5,306); k.ldi(6,72); k.ldi(7,24); k.call('hit_rect'); k.jz(0,'browser_press_link'); state_base(); k.ldi(8,1); k.st(8,29,S_BACTION); k.jmp('main_loop')
k.label('browser_press_link'); k.ldi(4,498); k.ldi(5,306); k.ldi(6,122); k.ldi(7,24); k.call('hit_rect'); k.jz(0,'main_loop'); state_base(); k.ldi(8,2); k.st(8,29,S_BACTION); k.jmp('main_loop')
k.label('main_press_normal'); k.call('mouse_press'); k.jmp('main_loop')
k.label('main_release'); k.call('mouse_unpack'); state_base(); k.ldi(8,0); k.st(8,29,S_DRAG); k.jmp('main_loop')
k.label('poweroff'); k.halt()

# kernel data
k.label('palette')
palette=[0x00070D18,0x000B1320,0x000E1928,0x00111F31,0x00142133,0x0018263A,0x001C2C42,0x0022354D,
         0x005D55E8,0x006D66F3,0x007D78FF,0x008F8BFF,0x00101826,0x00172335,0x001E2D42,0x00253A53,
         0x003F7CFF,0x00558EFF,0x002ECF91,0x0044E0A5,0x0025C77A,0x0041D995,0x00697D95,0x007D90A8,
         0x00F3F6FA,0x00DCE5EF,0x00BAC7D6,0x009AA9BA,0x007D8FA4,0x006C7E92,0x00596B80,0x00495B70,
         0x00FF5D73]
k.data_u32(palette)
k.label('pfs_magic_const'); k.data_u32([0x31534650])
strings={
's_pars':'PARS','s_os':'OS DESKTOP','s_vm12':'13','s_net':'NET','s_pfs1':'PFS1','s_welcome':'WELCOME','s_exact':'EXACT BYTE COMPUTER','s_tiny_live':'TINY32 ONLINE',
's_network':'NETWORK','s_dnshttp':'HTTPS READY','s_wasmready':'WASM LOCAL READY','s_storage':'DURABLE STORAGE','s_sixfiles':'PFS1 + PFS2 DISK','s_ready':'READY',
's_runtime':'RUNTIME','s_cpu':'TINY32 CPU','s_vramlive':'VRAM LIVE','s_apps':'DESKTOP','s_threeapps':'6 LIVE PIDS','s_mouse':'MOUSE READY','s_p':'P','s_pf':'PF',
's_3d':'3D','s_web':'WEB','s_sys':'SYS','s_files':'FILES','s_close':'CLOSE','s_places':'PLACES','s_system':'SYSTEM','s_name':'NAME','s_size':'SIZE',
's_readme':'README.TXT','s_rasterbin':'RASTER3D.BIN','s_browserbin':'BROWSER.BIN','s_systembin':'SYSTEM.BIN','s_wasmhtml':'WASM3D.HTML','s_wasmbin':'WASM3D.WASM',
's_1k':'1K','s_2k':'2K','s_7k':'9K','s_about':'ABOUT PARS OS','s_tinycpu':'TINY32 VIRTUAL CPU','s_pfssystem':'PFS1 FILESYSTEM','s_dnsh':'DNS TLS HTTPS','s_wasminterp':'WASM INTERPRETER','s_soft3d':'SOFTWARE 3D RASTER',
's_launcher':'APP LAUNCHER','s_search':'SEARCH APPS','s_webbrowser':'WEB BROWSER','s_3draster':'3D RASTERIZER','s_sysmonitor':'SYSTEM MONITOR','s_aboutshort':'ABOUT',
's_loader':'PARS APPLICATION LOADER','s_path_r3d':'/APPS/RASTER3D.BIN','s_path_sys':'/APPS/SYSTEM.BIN','s_path_web':'/APPS/BROWSER.BIN','s_path_term':'/APPS/TERMINAL.BIN','s_path_edit':'/APPS/EDITOR.BIN','s_pfsread':'PFS1 BLOCK READ','s_launching':'LOAD TO GUEST RAM','s_exec':'READY TO EXECUTE','s_fserr':'PFS1 FILE ERROR',
's_os13':'OS 20','s_wasmchip':'WASM','s_workspace':'WORKSPACE','s_quicklaunch':'QUICK LAUNCH','s_http_pfs':'TLS PFS1','s_guestgpu':'GUEST GPU','s_liveproc':'LIVE PROCESS','s_virtualdisk':'DURABLE HOME','s_machine':'MACHINE INFO','s_welcome13':'PARS PROCESS OS','s_native':'NATIVE 640 X 360','s_online':'ONLINE','s_tcpudp':'TCP TLS TLS','s_activity':'LIVE ACTIVITY','s_live':'LIVE','s_vramlabel':'VIDEO VRAM','s_sched':'IRQ SCHEDULER','s_boundary':'IRQ + GUEST COMPOSITOR','s_diskfooter':'PFS1 VIRTUAL DISK - 7 ENTRIES','s_x11strip':'X11 TRANSPORT - DISPLAY ONLY',
's_terminal':'TERMINAL','s_editor':'EDITOR','s_termhint':'TYPE COMMAND THEN ENTER','s_prompt':'PARS>','s_commands':'COMMANDS: NEW  LS  EDIT  CAT','s_commands18':'NEW LS EDIT CAT PS','s_commands18b':'HANG1 KILL1 RUN1 - PREEMPT TEST','s_created':'CREATED /HOME/HELLO.HTML','s_userhtml':'HOME/HELLO.HTML','s_user':'USER','s_nouser':'NO USER FILES','s_runnew':'NO FILE - RUN NEW','s_cathead':'CAT /HOME/HELLO.HTML','s_saved':'SAVED /HOME/HELLO.HTML','s_termesc':'ESC CLOSES TERMINAL','s_termesc18':'ESC EXIT - PROCESS PID 04','s_editpath':'PFS2 /HOME/HELLO.HTML','s_htmltitle':'HTML DOCUMENT - PARS NOTE','s_editlabel':'BODY TEXT:','s_unsaved':'UNSAVED CHANGES','s_savedstate':'SAVED + FSYNC PFS2','s_editkeys':'TYPE TEXT - ENTER SAVE - ESC CLOSE','s_editkeys18':'TYPE TEXT - ENTER SAVE - ESC EXIT','s_diskfooter15':'PFS1 SYSTEM + PFS2 DURABLE BLOCK DISK','s_htmlprefix':'<HTML><H1>PARS NOTE</H1><P>','s_htmlsuffix':'</P></HTML>','s_pid04':'PID 04 PREEMPTIVE','s_pid05':'PID 05 PREEMPTIVE','s_hang1':'PID 01 FORCED INFINITE LOOP','s_desktopalive':'DESKTOP + OTHER PIDS STILL LIVE','s_kill1':'KILL PID 01 COMPLETE','s_surfacefree':'PCB STOPPED - WINDOW DETACHED  ','s_ps0':'PID0 KERNEL','s_ps1':'PID1 RASTER','s_ps2':'PID2 SYSTEM','s_ps3':'PID3 BROWSER','s_ps4':'PID4 TERMINAL','s_ps5':'PID5 EDITOR','s_run1':'PID 01 SPAWN REQUESTED'
}
for name,s in strings.items(): k.label(name); k.data_str32(s)
# Include app text glyphs too because both disk apps call kernel font routines.
extra='IRQ PREEMPT IRET PCB KERNEL TIMER RASTER3D.BIN PFS1 LIVE A/D ROTATE SYSTEM.BIN PID 01 PID 02 SCHED CPU VRAM RUNNING BROWSER.BIN PARS WEB DNS + TLS CLICK BAR TYPE HOST ENTER QUERY GUEST PACKET TCP CONNECT RESOLVED IP PAGE RENDERED NETWORK OR ERROR BACK OPEN LINK NO ADDRESS CLEARED DEMO.TEST 127.0.0.1 PORT 18080 APP LAUNCHER SEARCH APPS FILES ABOUT TINY32 VIRTUAL FILESYSTEM SOFTWARE READY CLOSE PLACES NAME SIZE README.TXT WASM3D.HTML WASM3D.WASM EXACT BYTE COMPUTER NATIVE X WORKSPACE QUICK LAUNCH TLS PFS1 GUEST GPU LIVE PROCESS VIRTUAL DISK MACHINE INFO ONLINE TCP TLS LIVE ACTIVITY VIDEO VRAM SCHEDULER ALL UI DRAWN BY TINY32 RAW STRIPS ENTRIES TERMINAL EDITOR COMMANDS NEW LS EDIT CAT CREATED HOME HELLO USER BODY TEXT UNSAVED CHANGES SAVED WRITABLE PREEMPTIVE INFINITE LOOP DESKTOP OTHER PIDS STILL PCB STOPPED SURFACE RECLAIMED SPAWN REQUESTED HANG KILL RUN 0123456789 - : / . < >'
used=sorted(set(''.join(strings.values())+extra))
for ch in used:
    if ch not in FONT: raise KeyError(('font',ch))
glyphs=[' '] + [ch for ch in used if ch!=' ']
idx={ch:i for i,ch in enumerate(glyphs)}
k.label('font_map')
for c in range(128): k.data_u32([idx.get(chr(c),0)])
k.label('font_rows')
for ch in glyphs:
    for row in FONT[ch]: k.data_u32([rowbits(row)])

kernel=k.resolve()
assert len(kernel) < STATE, (len(kernel),STATE)

# --- RASTER3D.BIN @ 0x4000: one cooperative frame step per CALL ---
r=G(RASTER_LOAD)
for n,v in k.labels.items(): r.labels['K_'+n]=v

def r_color(reg,label): r.ldi_label(reg,label); r.ld(reg,reg,0)
def r_rect_dyn(xreg,yreg,w,h,color):
    r.mov(0,xreg); r.mov(1,yreg); r.ldi(2,w); r.ldi(3,h); r_color(4,color); r.call('K_fill_rect')
def r_text_dyn(xreg,yreg,label,color):
    r.mov(0,xreg); r.mov(1,yreg); r.ldi_label(2,label); r_color(3,color); r.call('K_draw_text')

r.label('entry')
# VM/20 fault-injection gate: HANG1 forces PID1 into a non-yielding tight loop. Timer IRQ must keep OS responsive.
r.ldi(29,PROC_CTL); r.ld(23,29,PC_RHANG); r.jz(23,'r_not_hung'); r.label('r_hang_loop'); r.jmp('r_hang_loop'); r.label('r_not_hung')
# command and auto rotation. app-local state angle/counter.
r.ldi_label(24,'state_local'); r.ld(30,24,0); r.ld(25,24,4); r.addi(25,1); r.st(25,24,4)
r.ldi(29,STATE); r.ld(26,29,S_CMD); r.jz(26,'r_no_cmd'); r.add(30,26); r.andi(30,31); r.ldi(27,0); r.st(27,29,S_CMD)
r.label('r_no_cmd')
# auto rotate every 6 scheduler calls for smoother visible motion at larger raster size
r.mov(27,25); r.andi(27,7); r.jnz(27,'r_no_auto'); r.addi(30,1); r.andi(30,31)
r.label('r_no_auto'); r.st(30,24,0)
# window x/y to R26/R27
r.ld(26,29,S_RX); r.ld(27,29,S_RY)
# 370x250 modern window
r_rect_dyn(26,27,370,250,'c_border')
r.mov(8,26); r.addi(8,3); r.mov(9,27); r.addi(9,3); r_rect_dyn(8,9,364,244,'c_window')
r.mov(8,26); r.addi(8,3); r.mov(9,27); r.addi(9,3); r_rect_dyn(8,9,364,22,'c_accent')
r.mov(8,26); r.addi(8,12); r.mov(9,27); r.addi(9,30); r_rect_dyn(8,9,346,178,'c_view')
# status strip y+216
r.mov(8,26); r.addi(8,12); r.mov(9,27); r.ldi(10,216); r.add(9,10); r_rect_dyn(8,9,346,26,'c_status')
# title text and real window control glyphs
r.mov(8,26); r.addi(8,12); r.mov(9,27); r.addi(9,10); r_text_dyn(8,9,'a_title','c_text')
r.mov(8,26); r.ldi(10,329); r.add(8,10); r.mov(9,27); r.addi(9,7); r_rect_dyn(8,9,14,12,'c_button')
r.mov(8,26); r.ldi(10,348); r.add(8,10); r.mov(9,27); r.addi(9,7); r_rect_dyn(8,9,14,12,'c_close')
r.mov(8,26); r.ldi(10,333); r.add(8,10); r.mov(9,27); r.addi(9,9); r_text_dyn(8,9,'a_min','c_text')
r.mov(8,26); r.ldi(10,352); r.add(8,10); r.mov(9,27); r.addi(9,9); r_text_dyn(8,9,'a_x','c_text')
# footer text
r.mov(8,26); r.addi(8,18); r.mov(9,27); r.ldi(10,226); r.add(9,10); r_text_dyn(8,9,'a_help','c_muted')
r.mov(8,26); r.ldi(10,300); r.add(8,10); r.mov(9,27); r.ldi(10,226); r.add(9,10); r_text_dyn(8,9,'a_live','c_live')
r.call('transform'); r.call('raster_all'); r.call('K_publish_raster'); r.jmp('entry')

r.label('transform')
r.ldi_label(7,'sincos'); r.mov(8,30); r.shl(8,3); r.add(7,8); r.ld(8,7,0); r.ld(9,7,4)
r.ldi(10,0)
r.label('vert_loop')
r.ldi_label(11,'verts'); r.mov(12,10); r.ldi(13,12); r.mul(12,13); r.add(11,12)
r.ld(12,11,0); r.ld(13,11,4); r.ld(14,11,8)
r.mov(15,12); r.mul(15,9); r.mov(16,14); r.mul(16,8); r.add(15,16); r.sar(15,8)
r.mov(16,14); r.mul(16,9); r.mov(18,12); r.mul(18,8); r.sub(16,18); r.sar(16,8)
# center = window x+185, window y+123
r.ldi(29,STATE); r.ld(18,29,S_RX); r.ldi(19,185); r.add(18,19); r.add(15,18)
r.ldi(18,123); r.ld(19,29,S_RY); r.add(18,19); r.sub(18,13); r.sar(16,3); r.add(18,16)
r.ldi_label(19,'projected'); r.mov(20,10); r.shl(20,3); r.add(19,20); r.st(15,19,0); r.st(18,19,4)
r.addi(10,1); r.mov(20,10); r.addi(20,-8); r.jnz(20,'vert_loop'); r.ret()

r.label('raster_all')
r.ldi(28,0)
r.label('tri_loop')
r.ldi_label(3,'tris'); r.mov(4,28); r.shl(4,4); r.add(3,4)
r.ld(4,3,0); r.ld(5,3,4); r.ld(6,3,8); r.ld(11,3,12)
r.ldi_label(3,'projected'); r.shl(4,3); r.add(3,4); r.ld(5,3,0); r.ld(6,3,4)
r.ldi_label(3,'tris'); r.mov(4,28); r.shl(4,4); r.add(3,4); r.ld(4,3,4)
r.ldi_label(3,'projected'); r.shl(4,3); r.add(3,4); r.ld(7,3,0); r.ld(8,3,4)
r.ldi_label(3,'tris'); r.mov(4,28); r.shl(4,4); r.add(3,4); r.ld(4,3,8)
r.ldi_label(3,'projected'); r.shl(4,3); r.add(3,4); r.ld(9,3,0); r.ld(10,3,4)
r.ldi_label(3,'face_colors'); r.shl(11,2); r.add(3,11); r.ld(11,3,0)
r.mov(12,7); r.sub(12,5); r.mov(13,10); r.sub(13,6); r.mul(12,13)
r.mov(14,8); r.sub(14,6); r.mov(15,9); r.sub(15,5); r.mul(14,15); r.sub(12,14)
r.jz(12,'tri_next'); r.js(12,'tri_next')
r.mov(16,6); r.sub(16,8); r.mov(19,7); r.sub(19,5)
r.mov(17,8); r.sub(17,10); r.mov(20,9); r.sub(20,7)
r.mov(18,10); r.sub(18,6); r.mov(21,5); r.sub(21,9)
# scan start = window x+113, y+67 ; 144x112
r.ldi(29,STATE); r.ld(25,29,S_RX); r.addi(25,113); r.ld(26,29,S_RY); r.addi(26,67)
# E0 at start
r.mov(22,26); r.sub(22,6); r.mul(22,19); r.mov(3,25); r.sub(3,5); r.mov(4,8); r.sub(4,6); r.mul(3,4); r.sub(22,3)
r.mov(23,26); r.sub(23,8); r.mul(23,20); r.mov(3,25); r.sub(3,7); r.mov(4,10); r.sub(4,8); r.mul(3,4); r.sub(23,3)
r.mov(24,26); r.sub(24,10); r.mul(24,21); r.mov(3,25); r.sub(3,9); r.mov(4,6); r.sub(4,10); r.mul(3,4); r.sub(24,3)
# VRAM addr at native 640-wide framebuffer
r.mov(14,26); r.ldi(3,640); r.mul(14,3); r.add(14,25); r.shl(14,2); r.ldi(3,DRAW_BASE_PTR); r.ld(3,3,0); r.add(14,3)
r.ldi(12,112)
r.label('ras_row')
r.mov(0,22); r.mov(1,23); r.mov(2,24); r.ldi(13,144)
r.label('ras_col')
r.js(0,'ras_skip'); r.js(1,'ras_skip'); r.js(2,'ras_skip'); r.st(11,14,0)
r.label('ras_skip')
r.addi(14,4); r.add(0,16); r.add(1,17); r.add(2,18); r.addi(13,-1); r.jnz(13,'ras_col')
r.add(22,19); r.add(23,20); r.add(24,21); r.ldi(3,1984); r.add(14,3); r.addi(12,-1); r.jnz(12,'ras_row')
r.label('tri_next')
r.addi(28,1); r.mov(3,28); r.addi(3,-12); r.jnz(3,'tri_loop'); r.ret()

r.label('c_border'); r.data_u32([0x00233B55])
r.label('c_window'); r.data_u32([0x00070D18])
r.label('c_accent'); r.data_u32([0x00142133])
r.label('c_view'); r.data_u32([0x00050A12])
r.label('c_status'); r.data_u32([0x00101826])
r.label('c_button'); r.data_u32([0x00253A53])
r.label('c_close'); r.data_u32([0x00A83E54])
r.label('c_text'); r.data_u32([0x00E6EDF3])
r.label('c_muted'); r.data_u32([0x0097A9BC])
r.label('c_live'); r.data_u32([0x005EE6A8])
for name,s in {'a_title':'RASTER3D.BIN','a_help':'A/D ROTATE - GUEST SOFTWARE RASTER','a_live':'LIVE','a_min':'-','a_x':'X'}.items(): r.label(name); r.data_str32(s)
r.label('state_local'); r.data_u32([0,0])
r.label('sincos')
for i in range(32):
    th=2*math.pi*i/32; r.data_u32([int(round(math.sin(th)*256)),int(round(math.cos(th)*256))])
r.label('verts')
for v in [(-50,-45,-50),(50,-45,-50),(50,45,-50),(-50,45,-50),(-50,-45,50),(50,-45,50),(50,45,50),(-50,45,50)]: r.data_u32(v)
r.label('tris')
for t in [(0,2,1,0),(0,3,2,0),(4,5,6,1),(4,6,7,1),(0,4,7,2),(0,7,3,2),(1,2,6,3),(1,6,5,3),(3,7,6,4),(3,6,2,4),(0,1,5,5),(0,5,4,5)]: r.data_u32(t)
r.label('face_colors'); r.data_u32([0x005B8DEF,0x004FD199,0x006BA2FF,0x0077B5A6,0x005EE6A8,0x004B6EAA])
r.label('projected'); r.data_u32([0]*16)
raster=r.resolve()

# --- SYSTEM.BIN @ 0x6000: live second process / monitor window ---
# Rebuild SYSTEM with proper dynamic-width helper in a compact second pass.
s=G(SYSTEM_LOAD)
for n,v in k.labels.items(): s.labels['K_'+n]=v

def s_abs(reg,addr):
    lo=addr&0xff; hi=((addr + (0x100 if lo>=128 else 0))>>8)&0xffff
    s.ldi(reg,hi); s.shl(reg,8)
    if lo: s.addi(reg,lo if lo<128 else lo-256)

def s_color(reg,label): s.ldi_label(reg,label); s.ld(reg,reg,0)
def s_rect(xreg,yreg,w,h,color,w_is_reg=False):
    s.mov(0,xreg); s.mov(1,yreg)
    if w_is_reg: s.mov(2,w)
    else: s.ldi(2,w)
    s.ldi(3,h); s_color(4,color); s.call('K_fill_rect')
def s_text(xreg,yreg,label,color): s.mov(0,xreg); s.mov(1,yreg); s.ldi_label(2,label); s_color(3,color); s.call('K_draw_text')

s.label('entry'); s.ldi(29,STATE); s.ld(26,29,S_SX); s.ld(27,29,S_SY); s_abs(24,IRQ_BASE); s.ld(25,24,IRQ_SWITCHES)
# 230x180 system monitor window
s_rect(26,27,230,180,'c_border')
s.mov(8,26); s.addi(8,3); s.mov(9,27); s.addi(9,3); s_rect(8,9,224,174,'c_window')
s.mov(8,26); s.addi(8,3); s.mov(9,27); s.addi(9,3); s_rect(8,9,224,22,'c_accent')
s.mov(8,26); s.addi(8,12); s.mov(9,27); s.addi(9,10); s_text(8,9,'a_title','c_text')
# window controls
s.mov(8,26); s.ldi(10,189); s.add(8,10); s.mov(9,27); s.addi(9,7); s_rect(8,9,14,12,'c_button')
s.mov(8,26); s.ldi(10,208); s.add(8,10); s.mov(9,27); s.addi(9,7); s_rect(8,9,14,12,'c_close')
s.mov(8,26); s.ldi(10,193); s.add(8,10); s.mov(9,27); s.addi(9,9); s_text(8,9,'a_min','c_text')
s.mov(8,26); s.ldi(10,212); s.add(8,10); s.mov(9,27); s.addi(9,9); s_text(8,9,'a_x','c_text')
# six live PID tracks: kernel + all five separately scheduled applications.
pid_rows=[(38,'a_pid0',0,'c_alt'),(58,'a_pid1',1,'c_live'),(78,'a_pid2',2,'c_alt'),(98,'a_pid3',3,'c_live'),(118,'a_pid4',4,'c_alt'),(138,'a_pid5',5,'c_live')]
for dy,label,pid,col in pid_rows:
    s.mov(8,26); s.addi(8,14); s.mov(9,27);
    if dy <= 127: s.addi(9,dy)
    else: s.ldi(10,dy); s.add(9,10)
    s_text(8,9,label,'c_muted')
    s.mov(8,26); s.addi(8,100); s.mov(9,27)
    if dy <= 127: s.addi(9,dy)
    else: s.ldi(10,dy); s.add(9,10)
    s_rect(8,9,108,7,'c_track')
    s_abs(24,SLICE_BASE); s.ld(20,24,pid*4); s.andi(20,63); s.addi(20,14)
    s.mov(8,26); s.addi(8,100); s.mov(9,27)
    if dy <= 127: s.addi(9,dy)
    else: s.ldi(10,dy); s.add(9,10)
    s_rect(8,9,20,7,col,True)
# footer
s.mov(8,26); s.addi(8,14); s.mov(9,27); s.ldi(10,160); s.add(9,10); s_text(8,9,'a_live','c_live')
s.call('K_publish_system'); s.jmp('entry')
s.label('c_border'); s.data_u32([0x00233B55]); s.label('c_window'); s.data_u32([0x00070D18]); s.label('c_accent'); s.data_u32([0x00142133])
s.label('c_button'); s.data_u32([0x00253A53]); s.label('c_close'); s.data_u32([0x00A83E54]); s.label('c_text'); s.data_u32([0x00E6EDF3]); s.label('c_muted'); s.data_u32([0x00B5C4D3]); s.label('c_track'); s.data_u32([0x00233143]); s.label('c_live'); s.data_u32([0x005EE6A8]); s.label('c_alt'); s.data_u32([0x005B8DEF])
for name,txt in {'a_title':'SYSTEM.BIN','a_pid0':'PID0 KERNEL','a_pid1':'PID1 RASTER','a_pid2':'PID2 SYSTEM','a_pid3':'PID3 WEB','a_pid4':'PID4 TERM','a_pid5':'PID5 EDIT','a_live':'IRQ PREEMPTIVE','a_min':'-','a_x':'X'}.items(): s.label(name); s.data_str32(txt)
system=s.resolve()

# --- BROWSER.BIN @ 0x7000: Tiny32 DNS + TLS browser with address bar and link navigation ---
b=G(BROWSER_LOAD)
for n,v in k.labels.items(): b.labels['K_'+n]=v

def b_color(reg,label): b.ldi_label(reg,label); b.ld(reg,reg,0)
def b_rect(x,y,w,h,color):
    b.ldi(0,x); b.ldi(1,y); b.ldi(2,w); b.ldi(3,h); b_color(4,color); b.call('K_fill_rect')
def b_text(x,y,label,color):
    b.ldi(0,x); b.ldi(1,y); b.ldi_label(2,label); b_color(3,color); b.call('K_draw_text')
def b_addr(reg,addr):
    # Numeric guest pointers may live anywhere in the 4 MiB guest RAM.
    b.ldi(reg,(addr>>8)&0xffff); b.shl(reg,8)
    lo=addr&0xff
    if lo: b.addi(reg,lo if lo<128 else lo-256)

def b_abs(reg,addr):
    lo=addr&0xff; hi=((addr + (0x100 if lo>=128 else 0))>>8)&0xffff
    b.ldi(reg,hi); b.shl(reg,8)
    if lo: b.addi(reg,lo if lo<128 else lo-256)

def b_u32(reg,val,tmp=30):
    val &= 0xffffffff
    hi=(val>>16)&0xffff; lo=val&0xffff
    if lo>=0x8000: hi=(hi+1)&0xffff; lo-=0x10000
    b.ldi(reg,hi); b.shl(reg,16)
    if lo:
        b.ldi(tmp,lo); b.add(reg,tmp)

# Keep all local data below 0x8000 so Tiny32 LDI pointers remain positive.
b.jmp('entry_code')
b.label('c_border'); b.data_u32([0x00233B55]); b.label('c_window'); b.data_u32([0x00070D18]); b.label('c_title'); b.data_u32([0x00142133]); b.label('c_bar'); b.data_u32([0x00172335]); b.label('c_content'); b.data_u32([0x00050A12]); b.label('c_text'); b.data_u32([0x00E6EDF3]); b.label('c_muted'); b.data_u32([0x0097A9BC]); b.label('c_live'); b.data_u32([0x005EE6A8]); b.label('c_error'); b.data_u32([0x00FF6B6B]); b.label('c_link'); b.data_u32([0x006BA2FF]); b.label('c_button'); b.data_u32([0x0018263A]); b.label('c_warn'); b.data_u32([0x00F0B44D])
for name,txt in {
    'a_title':'PARS WEB','a_proto':'HTTP + HTTPS + PFS','a_http':'ADDR:','a_hint':'TYPE HOST OR FILE URL - ENTER',
    'a_dns':'DNS QUERY - GUEST PACKET','a_tcp':'TCP CONNECT - RESOLVED IP','a_ok':'HTTP PAGE - GUEST RENDERED',
    'a_local':'PFS1 HTML - LOADING WASM','a_wasm':'LOCAL HTML + WASM - TINY32','a_wasmerr':'WASM MODULE ERROR',
    'a_wasmrun':'WASM CANVAS','a_tick':'TINY32 INTERPRETER','a_error':'NETWORK OR DNS ERROR',
    'a_back':'BACK','a_link':'OPEN LINK','a_nolink':'NO LINK','a_clear':'ADDRESS CLEARED','a_min':'-','a_x':'X','a_wasmnote':'PFS1 WASM EXECUTING ON TINY32','a_user':'PFS2 USER HTML - GUEST FILE','a_usernote':'WRITTEN BY PARS EDITOR - DURABLE PFS2',
    'a_tls':'TLS 1.2 RSA CERT - GUEST HANDSHAKE','a_https':'HTTPS PAGE - CERT VERIFIED','a_tlserr':'TLS CERT VERIFY ERROR'
}.items(): b.label(name); b.data_str32(txt)
b.label('proof_host'); b.data_str32('demo.test')
b.label('proof_tls_host'); b.data_str32('tls20.test')
b.label('local_path'); b.data_str32('file:///web/wasm3d.html')
b.label('user_path'); b.data_str32('file:///home/hello.html')
b.label('http_scheme'); b.data_str32('http://')
b.label('https_scheme'); b.data_str32('https://')
b.label('dns_header'); b.b += b'\xbe\xef\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00'
b.label('dns_tail'); b.b += b'\x00\x01\x00\x01'
b.label('http_get'); b.b += b'GET '
b.label('http_mid'); b.b += b' HTTP/1.0\r\nHost: '
b.label('http_tail'); b.b += b'\r\nConnection: close\r\nUser-Agent: Tiny32/20\r\n\r\n'
b.label('href_pat'); b.b += b'a href="'
b.label('wasm_ref_pat'); b.b += b'WASM3D.WASM'

# Tiny32/20 software-crypto constants. No host crypto primitive is exposed.
SHA_H0=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]
SHA_K=[
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
b.label('sha_h0'); b.data_u32(SHA_H0)
b.label('sha_k'); b.data_u32(SHA_K)
b.label('tls_abc'); b.b += b'abc'
b.label('tls_sha_abc'); b.b += bytes.fromhex('ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
b.label('tls_psk'); b.b += bytes.fromhex('1a2b3c4d5e6f77889900aabbccddeeff')
b.label('tls_identity'); b.b += b'Tiny32'
b.label('tls_hmac_key'); b.b += bytes([0x0b])*20
b.label('tls_hmac_msg'); b.b += b'Hi There'
b.label('tls_hmac_expected'); b.b += bytes.fromhex('b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7')
b.label('tls_prf_secret'); b.b += b'secret'
b.label('tls_prf_seedtest'); b.b += b'test labelseed'
b.label('tls_prf_expected'); b.b += bytes.fromhex('bfc72aea54e12f176b7549dc7d0082fecd2be093284636015f9149017f433669e453c27d2993bfb7cd5abd8c655edc7a7ab65b8e3f9f5272de648904d9fdc247')
AES_SBOX_BYTES=bytes.fromhex('637c777bf26b6fc53001672bfed7ab76ca82c97dfa5947f0add4a2af9ca472c0b7fd9326363ff7cc34a5e5f171d8311504c723c31896059a071280e2eb27b27509832c1a1b6e5aa0523bd6b329e32f8453d100ed20fcb15b6acbbe394a4c58cfd0efaafb434d338545f9027f503c9fa851a3408f929d38f5bcb6da2110fff3d2cd0c13ec5f974417c4a77e3d645d197360814fdc222a908846eeb814de5e0bdbe0323a0a4906245cc2d3ac629195e479e7c8376d8dd54ea96c56f4ea657aae08ba78252e1ca6b4c6e8dd741f4bbd8b8a703eb5664803f60e613557b986c11d9ee1f8981169d98e949b1e87e9ce5528df8ca1890dbfe6426841992d0fb054bb16')
AES_INV_BYTES=bytearray(256)
for _i,_v in enumerate(AES_SBOX_BYTES): AES_INV_BYTES[_v]=_i
b.label('aes_sbox'); b.b += AES_SBOX_BYTES
b.label('aes_invsbox'); b.b += bytes(AES_INV_BYTES)
b.label('aes_test_key'); b.b += bytes.fromhex('000102030405060708090a0b0c0d0e0f')
b.label('aes_test_pt'); b.b += bytes.fromhex('00112233445566778899aabbccddeeff')
b.label('aes_test_ct'); b.b += bytes.fromhex('69c4e0d86a7b0430d8cdb78070b4c55a')
b.label('tls_premaster_const'); b.b += bytes.fromhex('0010' + '00'*16 + '0010' + '1a2b3c4d5e6f77889900aabbccddeeff')
b.label('tls_label_master'); b.b += b'master secret'
b.label('tls_label_keyexp'); b.b += b'key expansion'
b.label('tls_label_cfin'); b.b += b'client finished'
b.label('tls_label_sfin'); b.b += b'server finished'
b.label('tls_test_cr'); b.b += bytes(range(32))
b.label('tls_test_sr'); b.b += bytes.fromhex('8a9fb6f99f68eea7c70b010128a8e6f9a34584b8f2c9675818a3dfd38e1a11dc')
b.label('tls_test_master'); b.b += bytes.fromhex('43c8824a4f1f335501a5495379f2263160daac8cd41955fb451e6a08af1310f837c316197890d6a483cb76e3681c10d9')
b.label('tls_test_keyblock'); b.b += bytes.fromhex('cfc4d2a4d43f9ddc531cf4020ff095bfa455dea22b1b54ddb13430105c380450a51f4c151e9977bad5b6e229599910737684fa9c6bfab6db97449fbbc4cff4583cdef8a522a3a2209c6f934020006972ff7fcc038cbb4f6dfa49180cbc40cdb1')
b.label('tls_test_fin_plain'); b.b += bytes.fromhex('1400000c319503221cfad2aa500b8e26')
b.label('tls_test_fin_protected'); b.b += bytes.fromhex('000102030405060708090a0b0c0d0e0f0f4c189070269e15845d28b3ce01b6dccfa7815adeebbac98517f50fe8b19c4d4aac66f0d3c3af981e54d3a06e7a0a88f30ae6dcb3f1dc717a19e0e304051d54')
# Deterministic VM/20 certificate-authenticated TLS 1.2 RSA ClientHello with SNI tls20.test.
_TLS20_HOST=b'tls20.test'
_TLS20_SNI=(b'\x00\x00'+(2+1+2+len(_TLS20_HOST)).to_bytes(2,'big')+(1+2+len(_TLS20_HOST)).to_bytes(2,'big')+b'\x00'+len(_TLS20_HOST).to_bytes(2,'big')+_TLS20_HOST)
TLS_CH_BODY=bytes.fromhex('0303')+bytes(range(32))+b'\x00'+bytes.fromhex('0002003c0100')+len(_TLS20_SNI).to_bytes(2,'big')+_TLS20_SNI
TLS_CH_HS=b'\x01'+len(TLS_CH_BODY).to_bytes(3,'big')+TLS_CH_BODY
b.label('tls_clienthello_record'); b.b += b'\x16\x03\x03'+len(TLS_CH_HS).to_bytes(2,'big')+TLS_CH_HS
b.label('tls_cke_hdr'); b.b += bytes.fromhex('100000820080')
b.label('tls_ccs_byte'); b.b += b'\x01'
b.label('tls_fin_hdr'); b.b += bytes.fromhex('1400000c')
# Pinned X.509/RSA proof material. Certificate bytes themselves arrive over TLS; guest pins their digest.
b.label('tls20_cert_sha'); b.b += bytes.fromhex('6a17a23e61757ebed0c6d3cb3c7c46cc7c5e51d69dad99f8096ef78bf2c8c4f6')
b.label('tls20_host_ascii'); b.b += b'tls20.test'
b.label('tls20_modulus_expected'); b.data_u32([185525113, 2977491112, 3017698210, 80515770, 2374071510, 2368409917, 1198060904, 29240141, 3734766111, 25691097, 1943478101, 109896222, 826235680, 1050978167, 530250936, 1246426710, 2396941874, 67426483, 650546062, 1093551903, 4169276928, 3396288723, 1768961569, 1085673033, 2216831321, 128389521, 3362000182, 1341010264, 1330711993, 3714349572, 173399982, 3810308297])
b.label('tls20_em_limbs'); b.data_u32([724315438, 656943402, 589571366, 522199330, 454827294, 387455258, 320083222, 252711186, 185339150, 117967114, 50595078, 50528514, 1263291648, 1195919690, 1128547654, 1061175618, 993803582, 926431546, 859059510, 791687474, 724315438, 656943402, 589571366, 522199330, 454827294, 387455258, 320083222, 252711186, 185339150, 117967114, 50595078, 131330])
b.label('tls20_cipher_expected'); b.data_u32([1258140130, 1476661187, 1692588248, 3194733051, 2049117886, 2987587432, 3381778426, 1422234752, 3330047479, 4186229368, 300370101, 982271279, 3212900613, 1378878856, 2826146206, 2620922772, 2459688384, 3036754876, 3719212172, 3986285389, 814315002, 2828544360, 3146558093, 1092240233, 2265453583, 3494876943, 2204039114, 659363840, 3309005780, 104966272, 3075197467, 1764541732])
b.label('tls20_premaster'); b.b += bytes.fromhex('03030102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e')

# raw_copy: R0 raw src, R1 raw dst, R2 bytes. Returns R0/R1 advanced.
b.label('raw_copy')
b.label('raw_copy_loop'); b.jz(2,'raw_copy_done'); b.ld(3,0,0); b.andi(3,255); b.st(3,1,0); b.addi(0,1); b.addi(1,1); b.addi(2,-1); b.jmp('raw_copy_loop')
b.label('raw_copy_done'); b.ret()

# Draw editable address from ADDR_BUF in the native-width browser bar. 40 chars max.
b.label('draw_address')
b_addr(20,ADDR_BUF); b.ldi(21,0); b.ldi(22,72); b.ldi(23,81)
b.label('addr_draw_loop'); b.ld(2,20,0); b.jz(2,'addr_draw_done')
# existing guest font is uppercase-oriented
b.mov(24,2); b.addi(24,-97); b.js(24,'addr_case_done'); b.mov(25,2); b.addi(25,-123); b.js(25,'addr_lower'); b.jmp('addr_case_done')
b.label('addr_lower'); b.addi(2,-32)
b.label('addr_case_done'); b.mov(0,22); b.mov(1,23); b_color(3,'c_text'); b.call('K_draw_char'); b.addi(22,6); b.addi(20,4); b.addi(21,1); b.mov(24,21); b.addi(24,-40); b.jnz(24,'addr_draw_loop')
b.label('addr_draw_done'); b.ret()

# Copy u32-character string R20 -> R21 including zero, max R22 chars; returns copied count (without zero) in R0.
b.label('copy_u32_string'); b.ldi(0,0)
b.label('copy_u32_loop'); b.jz(22,'copy_u32_term'); b.ld(23,20,0); b.st(23,21,0); b.jz(23,'copy_u32_done'); b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.addi(0,1); b.jmp('copy_u32_loop')
b.label('copy_u32_term'); b.ldi(23,0); b.st(23,21,0)
b.label('copy_u32_done'); b.ret()

# Compare ADDR_BUF to the exact local URL file:///web/wasm3d.html. Returns R0=1/0.
b.label('is_local_url'); b_addr(20,ADDR_BUF); b.ldi_label(21,'local_path')
b.label('local_cmp'); b.ld(22,20,0); b.ld(23,21,0); b.mov(24,22); b.sub(24,23); b.jnz(24,'local_no'); b.jz(22,'local_yes'); b.addi(20,4); b.addi(21,4); b.jmp('local_cmp')
b.label('local_yes'); b.ldi(0,1); b.ret(); b.label('local_no'); b.ldi(0,0); b.ret()

# Compare ADDR_BUF to file:///home/hello.html. The content lives in guest-owned PFS2 RAM.
b.label('is_user_url'); b_addr(20,ADDR_BUF); b.ldi_label(21,'user_path')
b.label('user_cmp'); b.ld(22,20,0); b.ld(23,21,0); b.mov(24,22); b.sub(24,23); b.jnz(24,'user_no'); b.jz(22,'user_yes'); b.addi(20,4); b.addi(21,4); b.jmp('user_cmp')
b.label('user_yes'); b.ldi(0,1); b.ret(); b.label('user_no'); b.ldi(0,0); b.ret()

# PFS1 file loader for browser-owned assets.
# Input R17=file_id, R18=guest destination. Return R0=file size or -1.
b.label('pfs_load_asset'); b.ldi(0,0); b.ldi(1,DIRBUF); b.ldi(2,1); b.sys(5); b.ldi(20,DIRBUF); b.ld(21,20,4); b.addi(20,16)
b.label('pfs_asset_scan'); b.jz(21,'pfs_asset_fail'); b.ld(22,20,0); b.mov(23,22); b.sub(23,17); b.jz(23,'pfs_asset_found'); b.addi(20,64); b.addi(21,-1); b.jmp('pfs_asset_scan')
b.label('pfs_asset_found'); b.ld(24,20,8); b.ld(25,20,12); b.ld(26,20,16); b.mov(0,24); b.mov(1,18); b.mov(2,25); b.sys(5); b.mov(0,26); b.ret()
b.label('pfs_asset_fail'); b.ldi(0,-1); b.ret()

# Validate the local WebAssembly module and locate function 0's instruction stream.
# VM/20 deliberately implements a compact real WASM subset: standard magic/version,
# one-byte section sizes/ULEBs, code section, global.get/set, i32.const/add/and, end.
b.label('wasm_init'); b_addr(20,WASM_BUF)
for off,val,lab in [(0,0,'wm0'),(1,97,'wm1'),(2,115,'wm2'),(3,109,'wm3'),(4,1,'wm4')]:
    b.ld(21,20,off); b.andi(21,255); b.addi(21,-val); b.jnz(21,'wasm_fail')
b_addr(28,WASM_META); b.ldi(21,0); b.st(21,28,16); b.st(21,28,20); b.st(21,28,24)
b.ldi(20,8); b_addr(21,WASM_BUF); b.add(20,21); b.ld(27,28,4); b.add(27,21)
b.label('wasm_sec_loop'); b.mov(22,27); b.sub(22,20); b.jz(22,'wasm_fail'); b.js(22,'wasm_fail')
b.ld(22,20,0); b.andi(22,255); b.addi(20,1); b.ld(23,20,0); b.andi(23,255); b.mov(24,23); b.andi(24,128); b.jnz(24,'wasm_fail'); b.addi(20,1)
b.mov(24,22); b.addi(24,-10); b.jz(24,'wasm_code_section'); b.add(20,23); b.jmp('wasm_sec_loop')
b.label('wasm_code_section'); b.ld(24,20,0); b.andi(24,255); b.jz(24,'wasm_fail'); b.addi(20,1); b.ld(24,20,0); b.andi(24,255); b.mov(25,24); b.andi(25,128); b.jnz(25,'wasm_fail'); b.addi(20,1); b.ld(24,20,0); b.andi(24,255); b.jnz(24,'wasm_fail'); b.addi(20,1); b.st(20,28,12); b.ldi(24,1); b.st(24,28,8); b.ldi(0,0); b.ret()
b.label('wasm_fail'); b_addr(28,WASM_META); b.ldi(24,-1); b.st(24,28,8); b.st(24,28,24); b.ldi(0,-1); b.ret()

# Execute WASM export function 0 (step) from its parsed code pointer.
# Operand stack is guest RAM at WASM_STACK; instruction budget prevents runaway modules.
b.label('wasm_step'); b_addr(28,WASM_META); b.ld(27,28,8); b.addi(27,-1); b.jnz(27,'wasm_step_fail'); b.ld(20,28,12); b_addr(21,WASM_STACK); b.ldi(22,0); b.ldi(27,64)
b.label('wi_loop'); b.addi(27,-1); b.jz(27,'wasm_step_fail'); b.ld(23,20,0); b.andi(23,255); b.addi(20,1)
# dispatch
b.mov(24,23); b.addi(24,-0x23); b.jz(24,'wi_gget'); b.mov(24,23); b.addi(24,-0x24); b.jz(24,'wi_gset'); b.mov(24,23); b.addi(24,-0x41); b.jz(24,'wi_const'); b.mov(24,23); b.addi(24,-0x6a); b.jz(24,'wi_add'); b.mov(24,23); b.addi(24,-0x71); b.jz(24,'wi_and'); b.mov(24,23); b.addi(24,-0x0b); b.jz(24,'wi_end'); b.jmp('wasm_step_fail')
# push global.get index
b.label('wi_gget'); b.ld(23,20,0); b.andi(23,255); b.addi(20,1); b.shl(23,2); b_addr(24,WASM_META); b.addi(24,16); b.add(24,23); b.ld(25,24,0); b.st(25,21,0); b.addi(21,4); b.addi(22,1); b.jmp('wi_loop')
# global.set index = pop
b.label('wi_gset'); b.ld(23,20,0); b.andi(23,255); b.addi(20,1); b.addi(21,-4); b.addi(22,-1); b.ld(25,21,0); b.shl(23,2); b_addr(24,WASM_META); b.addi(24,16); b.add(24,23); b.st(25,24,0); b.jmp('wi_loop')
# positive single-byte i32.const used by exact 144-byte module
b.label('wi_const'); b.ld(25,20,0); b.andi(25,127); b.addi(20,1); b.st(25,21,0); b.addi(21,4); b.addi(22,1); b.jmp('wi_loop')
# i32.add
b.label('wi_add'); b.addi(21,-4); b.ld(25,21,0); b.addi(21,-4); b.ld(26,21,0); b.add(26,25); b.st(26,21,0); b.addi(21,4); b.addi(22,-1); b.jmp('wi_loop')
# i32.and; this milestone accepts the module's 0x1f mask explicitly.
b.label('wi_and'); b.addi(21,-4); b.ld(25,21,0); b.addi(21,-4); b.ld(26,21,0); b.mov(24,25); b.addi(24,-31); b.jnz(24,'wasm_step_fail'); b.andi(26,31); b.st(26,21,0); b.addi(21,4); b.addi(22,-1); b.jmp('wi_loop')
b.label('wi_end'); b.ldi(0,0); b.ret()
b.label('wasm_step_fail'); b_addr(28,WASM_META); b.ldi(24,-1); b.st(24,28,8); b.st(24,28,24); b.ldi(0,-1); b.ret()

# Scan loaded HTML for the referenced WASM filename. Returns R0=1/0.
b.label('html_has_wasm'); b_addr(20,HTML_BUF); b_addr(28,WASM_META); b.ld(21,28,0)
b.label('hwasm_outer'); b.mov(22,21); b.addi(22,-11); b.js(22,'hwasm_no'); b.mov(23,20); b.ldi_label(24,'wasm_ref_pat'); b.ldi(25,11)
b.label('hwasm_cmp'); b.jz(25,'hwasm_yes'); b.ld(26,23,0); b.andi(26,255); b.ld(27,24,0); b.andi(27,255); b.sub(26,27); b.jnz(26,'hwasm_next'); b.addi(23,1); b.addi(24,1); b.addi(25,-1); b.jmp('hwasm_cmp')
b.label('hwasm_next'); b.addi(20,1); b.addi(21,-1); b.jmp('hwasm_outer')
b.label('hwasm_yes'); b.ldi(0,1); b.ret(); b.label('hwasm_no'); b.ldi(0,0); b.ret()

# Load local HTML and its referenced WASM from PFS1 into guest RAM, then initialize interpreter.
b.label('load_local_wasm'); b.ldi(17,0x7701); b_addr(18,HTML_BUF); b.call('pfs_load_asset'); b.js(0,'local_load_fail'); b_addr(28,WASM_META); b.st(0,28,0); b.call('html_has_wasm'); b.jz(0,'local_load_fail'); b.ldi(17,0x7702); b_addr(18,WASM_BUF); b.call('pfs_load_asset'); b.js(0,'local_load_fail'); b_addr(28,WASM_META); b.st(0,28,4); b.call('wasm_init'); b.ret()
b.label('local_load_fail'); b.ldi(0,-1); b.ret()

# Minimal HTML text renderer for local PFS1 documents; strips tags and renders raw text.
b.label('render_local_html'); b_addr(28,WASM_META); b.ld(21,28,0); b_addr(20,HTML_BUF); b.ldi(22,0); b.ldi(23,0); b.ldi(24,0)
b.label('lh_loop'); b.jz(21,'lh_done'); b.mov(25,23); b.addi(25,-14); b.jz(25,'lh_done'); b.ld(26,20,0); b.andi(26,255); b.addi(20,1); b.addi(21,-1); b.mov(25,26); b.addi(25,-60); b.jz(25,'lh_tag_on'); b.mov(25,26); b.addi(25,-62); b.jz(25,'lh_tag_off'); b.jnz(24,'lh_loop'); b.mov(25,26); b.addi(25,-10); b.jz(25,'lh_newline'); b.mov(25,26); b.addi(25,-32); b.js(25,'lh_loop')
# uppercase lowercase characters for kernel font
b.mov(25,26); b.addi(25,-97); b.js(25,'lh_case_done'); b.mov(27,26); b.addi(27,-123); b.js(27,'lh_lower'); b.jmp('lh_case_done'); b.label('lh_lower'); b.addi(26,-32)
b.label('lh_case_done'); b.mov(0,22); b.ldi(25,6); b.mul(0,25); b.addi(0,28); b.mov(1,23); b.ldi(25,9); b.mul(1,25); b.ldi(27,130); b.add(1,27); b.mov(2,26); b_color(3,'c_text'); b.call('K_draw_char'); b.addi(22,1); b.mov(25,22); b.addi(25,-72); b.jz(25,'lh_newline'); b.jmp('lh_loop')
b.label('lh_tag_on'); b.ldi(24,1); b.jmp('lh_loop'); b.label('lh_tag_off'); b.ldi(24,0); b.jmp('lh_loop'); b.label('lh_newline'); b.ldi(22,0); b.addi(23,1); b.jmp('lh_loop'); b.label('lh_done'); b.ret()

# Render the user-created PFS2 HTML file. The file is stored as u32 characters in guest RAM.
b.label('render_user_html'); b_abs(28,PFS2_BASE); b.ld(21,28,P2_FILELEN); b_abs(20,PFS2_FILE); b.ldi(22,0); b.ldi(23,0); b.ldi(24,0)
b.label('uh_loop'); b.jz(21,'uh_done'); b.mov(25,23); b.addi(25,-14); b.jz(25,'uh_done'); b.ld(26,20,0); b.addi(20,4); b.addi(21,-1); b.mov(25,26); b.addi(25,-60); b.jz(25,'uh_tag_on'); b.mov(25,26); b.addi(25,-62); b.jz(25,'uh_tag_off'); b.jnz(24,'uh_loop'); b.mov(25,26); b.addi(25,-10); b.jz(25,'uh_newline'); b.mov(25,26); b.addi(25,-32); b.js(25,'uh_loop')
b.mov(25,26); b.addi(25,-97); b.js(25,'uh_case_done'); b.mov(27,26); b.addi(27,-123); b.js(27,'uh_lower'); b.jmp('uh_case_done'); b.label('uh_lower'); b.addi(26,-32)
b.label('uh_case_done'); b.mov(0,22); b.ldi(25,6); b.mul(0,25); b.addi(0,28); b.mov(1,23); b.ldi(25,9); b.mul(1,25); b.ldi(27,130); b.add(1,27); b.mov(2,26); b_color(3,'c_text'); b.call('K_draw_char'); b.addi(22,1); b.mov(25,22); b.addi(25,-88); b.jz(25,'uh_newline'); b.jmp('uh_loop')
b.label('uh_tag_on'); b.ldi(24,1); b.jmp('uh_loop'); b.label('uh_tag_off'); b.ldi(24,0); b.jmp('uh_loop'); b.label('uh_newline'); b.ldi(22,0); b.addi(23,1); b.jmp('uh_loop'); b.label('uh_done'); b_text(28,278,'a_usernote','c_muted'); b.ret()

# Animated WASM canvas. The browser executes step() in the guest interpreter every frame;
# WASM global 1 is the 0..31 angle that directly controls this guest-rendered scene.
b.label('draw_wasm_canvas'); b.ldi(29,STATE); b.ld(27,29,S_TICK); b.andi(27,31); b.jnz(27,'wc_draw'); b.call('wasm_step'); b.js(0,'wc_fail')
b.label('wc_draw')
# guest-rendered WASM panel in the right side of page content
b_rect(394,146,210,122,'c_bar'); b_rect(400,152,198,110,'c_content'); b_text(410,160,'a_wasmrun','c_live'); b_text(410,174,'a_tick','c_muted')
b_addr(28,WASM_META); b.ld(20,28,20); b.andi(20,31); b.mov(21,20); b.andi(21,15); b.mov(22,21); b.addi(22,-8); b.js(22,'wc_phase_ok'); b.ldi(22,15); b.sub(22,21); b.mov(21,22)
b.label('wc_phase_ok')
# horizontal animated bar
b.mov(22,21); b.ldi(23,8); b.mul(22,23); b.addi(22,32); b.ldi(0,430); b.ldi(1,204); b.mov(2,22); b.ldi(3,22); b_color(4,'c_title'); b.call('K_fill_rect')
# moving cursor marker
b.ldi(0,420); b.mov(23,21); b.ldi(24,8); b.mul(23,24); b.add(0,23); b.ldi(1,198); b.ldi(2,10); b.ldi(3,34); b_color(4,'c_live'); b.call('K_fill_rect')
b_text(410,242,'a_wasmnote','c_muted'); b.ret()
b.label('wc_fail'); b.ret()

# Browser navigation actions signaled by guest kernel mouse hit-testing.
b.label('handle_action')
b.ldi(29,STATE); b.ld(25,29,S_BACTION); b.jz(25,'action_done'); b.ldi(26,0); b.st(26,29,S_BACTION)
b.addi(25,-1); b.jz(25,'action_back'); b.addi(25,-1); b.jz(25,'action_link'); b.addi(25,-1); b.jz(25,'action_clear'); b.ret()
b.label('action_clear'); b.ldi(26,0); b.st(26,29,S_BLEN); b.st(26,29,S_BSTATUS); b.st(26,29,S_BLINKLEN); b_addr(20,ADDR_BUF); b.st(26,20,0); b.ret()
b.label('action_back'); b.ld(26,29,S_BPREVLEN); b.jz(26,'action_done'); b_addr(20,PREV_BUF); b_addr(21,ADDR_BUF); b.mov(22,26); b.addi(22,1); b.call('copy_u32_string'); b.ldi(29,STATE); b.st(26,29,S_BLEN); b.ldi(27,0); b.st(27,29,S_BPREVLEN); b.st(27,29,S_BSTATUS); b.ldi(27,1); b.st(27,29,S_BFETCH); b.ret()
b.label('action_link'); b.ld(26,29,S_BLINKLEN); b.jz(26,'action_done')
# current address -> previous history
b.ld(27,29,S_BLEN); b_addr(20,ADDR_BUF); b_addr(21,PREV_BUF); b.mov(22,27); b.addi(22,1); b.call('copy_u32_string'); b.ldi(29,STATE); b.st(27,29,S_BPREVLEN)
# relative href begins '/': prefix current host[:port] then href. Otherwise copy href as address.
b_addr(20,LINK_BUF); b.ld(24,20,0); b.mov(25,24); b.addi(25,-47); b.jz(25,'nav_relative')
# absolute links are copied verbatim; parse_address understands http:// and https://.
b_addr(20,LINK_BUF); b_addr(21,ADDR_BUF); b.ldi(22,40); b.call('copy_u32_string'); b.ldi(29,STATE); b.st(0,29,S_BLEN); b.jmp('nav_fetch')
b.label('nav_relative')
# source href R20. prefix comes from PREV_BUF before the slash.
b.ld(27,29,S_BPREFIXLEN); b_addr(29,TLS_META2); b.ld(25,29,TM_SCHEMELEN); b.add(27,25); b_addr(21,ADDR_BUF); b_addr(28,PREV_BUF); b.ldi(24,0)
b.label('prefix_copy'); b.mov(25,24); b.sub(25,27); b.jz(25,'prefix_done'); b.ld(23,28,0); b.st(23,21,0); b.addi(28,4); b.addi(21,4); b.addi(24,1); b.jmp('prefix_copy')
b.label('prefix_done'); b.ldi(22,40); b.sub(22,27); b.call('copy_u32_string'); b.add(0,27); b.ldi(29,STATE); b.st(0,29,S_BLEN)
b.label('nav_fetch'); b.ldi(27,0); b.st(27,29,S_BSTATUS); b.ldi(27,1); b.st(27,29,S_BFETCH)
b.label('action_done'); b.ret()

# Scheme detectors for browser addresses. Return R0=1/0.
b.label('is_https_scheme'); b_addr(20,ADDR_BUF); b.ldi_label(21,'https_scheme')
b.label('https_scheme_cmp'); b.ld(22,21,0); b.jz(22,'https_scheme_yes'); b.ld(23,20,0); b.mov(24,23); b.sub(24,22); b.jnz(24,'https_scheme_no'); b.addi(20,4); b.addi(21,4); b.jmp('https_scheme_cmp')
b.label('https_scheme_yes'); b.ldi(0,1); b.ret(); b.label('https_scheme_no'); b.ldi(0,0); b.ret()
b.label('is_http_scheme'); b_addr(20,ADDR_BUF); b.ldi_label(21,'http_scheme')
b.label('http_scheme_cmp'); b.ld(22,21,0); b.jz(22,'http_scheme_yes'); b.ld(23,20,0); b.mov(24,23); b.sub(24,22); b.jnz(24,'http_scheme_no'); b.addi(20,4); b.addi(21,4); b.jmp('http_scheme_cmp')
b.label('http_scheme_yes'); b.ldi(0,1); b.ret(); b.label('http_scheme_no'); b.ldi(0,0); b.ret()

# Parse ADDR_BUF syntax [http[s]://]host[:port][/path]. Stores HOST_BUF, PATH_BUF, port, lengths, prefix length.
b.label('parse_address')
# Default mode HTTP/no scheme.
b_addr(29,TLS_META2); b.ldi(26,0); b.st(26,29,TM_TLS_MODE); b.st(26,29,TM_SCHEMELEN)
b.call('is_https_scheme'); b.jz(0,'parse_check_http'); b_addr(20,ADDR_BUF); b.addi(20,32); b_addr(29,TLS_META2); b.ldi(26,1); b.st(26,29,TM_TLS_MODE); b.ldi(26,8); b.st(26,29,TM_SCHEMELEN); b.ldi(25,443); b.jmp('parse_scheme_done')
b.label('parse_check_http'); b.call('is_http_scheme'); b.jz(0,'parse_no_scheme'); b_addr(20,ADDR_BUF); b.addi(20,28); b_addr(29,TLS_META2); b.ldi(26,7); b.st(26,29,TM_SCHEMELEN); b.ldi(25,80); b.jmp('parse_scheme_done')
b.label('parse_no_scheme'); b_addr(20,ADDR_BUF); b.ldi(25,80)
b.label('parse_scheme_done'); b_addr(21,HOST_BUF); b_addr(22,PATH_BUF); b.ldi(23,0); b.ldi(24,0)
b.label('parse_host'); b.ld(26,20,0); b.jz(26,'parse_no_path'); b.mov(27,26); b.addi(27,-58); b.jz(27,'parse_port_start'); b.mov(27,26); b.addi(27,-47); b.jz(27,'parse_path_start'); b.st(26,21,0); b.addi(21,4); b.addi(20,4); b.addi(23,1); b.addi(24,1); b.jmp('parse_host')
b.label('parse_port_start'); b.addi(20,4); b.addi(24,1); b.ldi(25,0)
b.label('parse_port'); b.ld(26,20,0); b.jz(26,'parse_no_path'); b.mov(27,26); b.addi(27,-47); b.jz(27,'parse_path_start'); b.addi(26,-48); b.js(26,'parse_fail'); b.mov(27,26); b.addi(27,-10); b.js(27,'port_digit_ok'); b.jmp('parse_fail')
b.label('port_digit_ok'); b.mov(27,25); b.ldi(28,10); b.mul(27,28); b.add(27,26); b.mov(25,27); b.addi(20,4); b.addi(24,1); b.jmp('parse_port')
b.label('parse_path_start'); b.ldi(27,0)
b.label('parse_path_copy'); b.ld(26,20,0); b.st(26,22,0); b.jz(26,'parse_done'); b.addi(20,4); b.addi(22,4); b.addi(27,1); b.jmp('parse_path_copy')
b.label('parse_no_path'); b.ldi(26,0); b.st(26,21,0); b.ldi(26,47); b.st(26,22,0); b.ldi(26,0); b.st(26,22,4); b.ldi(27,1); b.mov(24,23)
b.label('parse_done'); b.ldi(26,0); b.st(26,21,0); b.mov(26,23); b.jz(26,'parse_fail'); b.ldi(29,STATE); b.st(23,29,S_BHLEN); b.st(27,29,S_BPLEN); b.st(24,29,S_BPREFIXLEN); b.st(25,29,S_BPORT); b.ldi(0,0); b.ret()
b.label('parse_fail'); b.ldi(0,-1); b.ret()

# Is HOST_BUF one of the deterministic proof hosts demo.test/tls.test? Returns R0=1/0.
b.label('is_proof_host'); b_addr(20,HOST_BUF); b.ldi_label(21,'proof_host')
b.label('proof_cmp'); b.ld(22,20,0); b.ld(23,21,0); b.mov(24,22); b.sub(24,23); b.jnz(24,'proof_try_tls'); b.jz(22,'proof_yes'); b.addi(20,4); b.addi(21,4); b.jmp('proof_cmp')
b.label('proof_try_tls'); b_addr(20,HOST_BUF); b.ldi_label(21,'proof_tls_host')
b.label('proof_tls_cmp'); b.ld(22,20,0); b.ld(23,21,0); b.mov(24,22); b.sub(24,23); b.jnz(24,'proof_no'); b.jz(22,'proof_yes'); b.addi(20,4); b.addi(21,4); b.jmp('proof_tls_cmp')
b.label('proof_yes'); b.ldi(0,1); b.ret(); b.label('proof_no'); b.ldi(0,0); b.ret()

# Build DNS A query into DNS_BUF from HOST_BUF. Returns packet length R0.
b.label('build_dns')
b.ldi_label(0,'dns_header'); b_addr(1,DNS_BUF); b.ldi(2,12); b.call('raw_copy'); b.mov(20,1); b_addr(21,HOST_BUF)
# Tiny32 only has ST32, so count each DNS label before writing its one-byte length;
# subsequent character stores overwrite the harmless zero padding from the length store.
b.label('dns_label_start'); b.mov(26,21); b.ldi(23,0)
b.label('dns_count_label'); b.ld(24,26,0); b.jz(24,'dns_count_done'); b.mov(25,24); b.addi(25,-46); b.jz(25,'dns_count_done'); b.addi(23,1); b.addi(26,4); b.jmp('dns_count_label')
b.label('dns_count_done'); b.st(23,20,0); b.addi(20,1); b.mov(27,23)
b.label('dns_copy_label'); b.jz(27,'dns_after_label'); b.ld(24,21,0); b.st(24,20,0); b.addi(20,1); b.addi(21,4); b.addi(27,-1); b.jmp('dns_copy_label')
b.label('dns_after_label'); b.ld(24,21,0); b.jz(24,'dns_name_end'); b.addi(21,4); b.jmp('dns_label_start')
b.label('dns_name_end'); b.ldi(24,0); b.st(24,20,0); b.addi(20,1); b.ldi_label(0,'dns_tail'); b.mov(1,20); b.ldi(2,4); b.call('raw_copy'); b.mov(20,1); b_addr(21,DNS_BUF); b.sub(20,21); b.mov(0,20); b.ret()

# Parse first IPv4 A record from DNS_RESP. Returns R0 canonical IPv4 or -1.
b.label('parse_dns')
b_addr(20,DNS_RESP); b.ld(21,20,7); b.andi(21,255); b.jz(21,'dns_parse_fail'); b.addi(20,12)
# skip question qname
b.label('skip_question'); b.ld(22,20,0); b.andi(22,255); b.jz(22,'question_end'); b.addi(20,1); b.jmp('skip_question')
b.label('question_end'); b.addi(20,5)
b.label('answer_loop'); b.jz(21,'dns_parse_fail')
# skip answer NAME, including compression pointer
b.ld(22,20,0); b.andi(22,255); b.mov(23,22); b.addi(23,-192); b.js(23,'answer_name_labels'); b.addi(20,2); b.jmp('answer_fields')
b.label('answer_name_labels')
b.label('answer_name_scan'); b.ld(22,20,0); b.andi(22,255); b.jz(22,'answer_name_zero'); b.addi(20,1); b.add(20,22); b.jmp('answer_name_scan')
b.label('answer_name_zero'); b.addi(20,1)
b.label('answer_fields')
# A/IN/RDLENGTH4 checks by individual network-order bytes.
b.ld(22,20,0); b.andi(22,255); b.jnz(22,'answer_skip'); b.ld(22,20,1); b.andi(22,255); b.addi(22,-1); b.jnz(22,'answer_skip')
b.ld(22,20,2); b.andi(22,255); b.jnz(22,'answer_skip'); b.ld(22,20,3); b.andi(22,255); b.addi(22,-1); b.jnz(22,'answer_skip')
b.ld(22,20,8); b.andi(22,255); b.jnz(22,'answer_skip'); b.ld(22,20,9); b.andi(22,255); b.addi(22,-4); b.jnz(22,'answer_skip')
# assemble network-order RDATA to canonical integer
b.ld(22,20,10); b.andi(22,255); b.shl(22,24); b.ld(23,20,11); b.andi(23,255); b.shl(23,16); b.add(22,23); b.ld(23,20,12); b.andi(23,255); b.shl(23,8); b.add(22,23); b.ld(23,20,13); b.andi(23,255); b.add(22,23); b.mov(0,22); b.ret()
b.label('answer_skip')
# rdlength = byte8*256 + byte9; advance 10+rdlength
b.ld(22,20,8); b.andi(22,255); b.shl(22,8); b.ld(23,20,9); b.andi(23,255); b.add(22,23); b.addi(20,10); b.add(20,22); b.addi(21,-1); b.jmp('answer_loop')
b.label('dns_parse_fail'); b.ldi(0,-1); b.ret()

# Resolve host. demo.test uses deterministic local DNS :15353; every other host uses 1.1.1.1:53.
b.label('resolve_dns'); b.call('build_dns'); b.mov(27,0); b.ldi(29,STATE); b.st(27,29,S_BDNSLEN); b.call('is_proof_host'); b.jz(0,'dns_public')
# 127.0.0.1
b.ldi(0,0x7f00); b.shl(0,16); b.addi(0,1); b.ldi(1,15353); b.jmp('dns_open')
b.label('dns_public'); b.ldi(0,0x0101); b.shl(0,16); b.ldi(28,0x0101); b.add(0,28); b.ldi(1,53)
b.label('dns_open'); b.sys(10); b.js(0,'resolve_fail'); b.mov(25,0); b.mov(0,25); b_addr(1,DNS_BUF); b.mov(2,27); b.sys(7); b.js(0,'resolve_close_fail'); b.mov(0,25); b_addr(1,DNS_RESP); b.ldi(2,512); b.sys(8); b.js(0,'resolve_close_fail'); b.mov(26,0); b.mov(0,25); b.sys(9); b.ldi(29,STATE); b.st(26,29,S_BDNSLEN); b.call('parse_dns'); b.js(0,'resolve_fail'); b.st(0,29,S_BIP); b_addr(28,TLS_META2); b.ld(26,28,TM_TLS_MODE); b.jz(26,'resolve_http_next'); b.ldi(26,9); b.st(26,29,S_BSTATUS); b.ldi(26,5); b.st(26,29,S_BFETCH); b.ldi(26,40); b.st(26,29,S_BREQ); b.ldi(0,0); b.ret(); b.label('resolve_http_next'); b.ldi(26,2); b.st(26,29,S_BSTATUS); b.ldi(26,3); b.st(26,29,S_BFETCH); b.ldi(26,80); b.st(26,29,S_BREQ); b.ldi(0,0); b.ret()
b.label('resolve_close_fail'); b.mov(0,25); b.sys(9)
b.label('resolve_fail'); b.ldi(29,STATE); b.ldi(26,4); b.st(26,29,S_BSTATUS); b.ldi(26,0); b.st(26,29,S_BFETCH); b.ldi(0,-1); b.ret()

# Build raw HTTP/1.0 request entirely in guest RAM. Returns length R0.
b.label('build_request')
b.ldi_label(0,'http_get'); b_addr(1,REQ_BUF); b.ldi(2,4); b.call('raw_copy'); b.mov(20,1)
# PATH_BUF u32 chars -> raw bytes
b_addr(21,PATH_BUF)
b.label('req_path'); b.ld(22,21,0); b.jz(22,'req_mid'); b.st(22,20,0); b.addi(20,1); b.addi(21,4); b.jmp('req_path')
b.label('req_mid'); b.ldi_label(0,'http_mid'); b.mov(1,20); b.ldi(2,len(b' HTTP/1.0\r\nHost: ')); b.call('raw_copy'); b.mov(20,1)
# Host header uses the original host[:port] prefix from ADDR_BUF.
b_addr(21,ADDR_BUF); b_addr(28,TLS_META2); b.ld(26,28,TM_SCHEMELEN); b.shl(26,2); b.add(21,26); b.ldi(29,STATE); b.ld(23,29,S_BPREFIXLEN); b.ldi(24,0)
b.label('req_host'); b.mov(22,24); b.sub(22,23); b.jz(22,'req_tail'); b.ld(22,21,0); b.st(22,20,0); b.addi(20,1); b.addi(21,4); b.addi(24,1); b.jmp('req_host')
b.label('req_tail'); b.ldi_label(0,'http_tail'); b.mov(1,20); b.ldi(2,len(b'\r\nConnection: close\r\nUser-Agent: Tiny32/20\r\n\r\n')); b.call('raw_copy'); b.mov(20,1); b_addr(21,REQ_BUF); b.sub(20,21); b.ldi(29,STATE); b.st(20,29,S_BREQ); b.mov(0,20); b.ret()

# TCP/HTTP stage using DNS-resolved S_BIP and parsed S_BPORT.
b.label('http_fetch'); b.call('build_request'); b.mov(27,0); b.ldi(29,STATE); b.ld(0,29,S_BIP); b.ld(1,29,S_BPORT); b.sys(6); b.js(0,'http_fail'); b.mov(25,0); b.mov(0,25); b_addr(1,REQ_BUF); b.mov(2,27); b.sys(7); b.js(0,'http_close_fail')
# recv up to 7168 bytes into RESP_BUF
b_addr(26,RESP_BUF); b.ldi(27,0)
b.label('http_recv'); b.mov(0,25); b.mov(1,26); b.ldi(2,1024); b.sys(8); b.js(0,'http_close_fail'); b.jz(0,'http_done'); b.add(26,0); b.add(27,0); b.mov(28,27); b.ldi(24,28); b.shl(24,8); b.sub(28,24); b.js(28,'http_recv')
b.label('http_done'); b.mov(0,25); b.sys(9); b.ldi(29,STATE); b.st(27,29,S_BRESP)
# parse numeric status code from bytes 9..11
b_addr(20,RESP_BUF); b.ld(21,20,9); b.andi(21,255); b.addi(21,-48); b.ldi(22,100); b.mul(21,22); b.ld(23,20,10); b.andi(23,255); b.addi(23,-48); b.ldi(22,10); b.mul(23,22); b.add(21,23); b.ld(23,20,11); b.andi(23,255); b.addi(23,-48); b.add(21,23); b.ldi(24,3); b.st(24,29,S_BSTATUS); b.ldi(24,0); b.st(24,29,S_BFETCH); b.ret()
b.label('http_close_fail'); b.mov(0,25); b.sys(9)
b.label('http_fail'); b.ldi(29,STATE); b.ldi(24,4); b.st(24,29,S_BSTATUS); b.ldi(24,0); b.st(24,29,S_BFETCH); b.ret()

# Capture first href when body parser enters an <a href="..."> tag. R20 points immediately after '<'.
b.label('capture_href')
b.ldi(29,STATE); b.ld(27,29,S_BLINKLEN); b.jnz(27,'href_done'); b.ldi_label(27,'href_pat'); b.mov(28,20); b.ldi(26,8)
b.label('href_cmp'); b.jz(26,'href_match'); b.ld(24,28,0); b.andi(24,255); b.ld(25,27,0); b.andi(25,255); b.sub(24,25); b.jnz(24,'href_done'); b.addi(28,1); b.addi(27,1); b.addi(26,-1); b.jmp('href_cmp')
b.label('href_match'); b.mov(28,20); b.addi(28,8); b_addr(27,LINK_BUF); b.ldi(26,0)
b.label('href_copy'); b.ld(24,28,0); b.andi(24,255); b.mov(25,24); b.addi(25,-34); b.jz(25,'href_term'); b.mov(25,26); b.addi(25,-40); b.jz(25,'href_term'); b.st(24,27,0); b.addi(27,4); b.addi(28,1); b.addi(26,1); b.jmp('href_copy')
b.label('href_term'); b.ldi(24,0); b.st(24,27,0); b.ldi(29,STATE); b.st(26,29,S_BLINKLEN)
b.label('href_done'); b.ret()

# Render HTTP body, strip tags, uppercase lowercase glyphs, capture first href and color link text.
b.label('render_response')
b.ldi(29,STATE); b.ldi(27,0); b.st(27,29,S_BLINKLEN); b_addr(27,LINK_BUF); b.ldi(28,0); b.st(28,27,0)
b_addr(20,RESP_BUF); b.ld(21,29,S_BRESP); b.ldi(22,0x0a0d); b.shl(22,16); b.ldi(23,0x0a0d); b.add(22,23)
b.label('hdr_scan'); b.jz(21,'render_done'); b.ld(24,20,0); b.mov(25,24); b.sub(25,22); b.jz(25,'body_found'); b.addi(20,1); b.addi(21,-1); b.jmp('hdr_scan')
b.label('body_found'); b.addi(20,4); b.addi(21,-4); b.ldi(22,0); b.ldi(23,0); b.ldi(24,0); b.ldi(30,0)
b.label('body_loop'); b.jz(21,'render_done'); b.mov(25,23); b.addi(25,-17); b.jz(25,'render_done'); b.ld(26,20,0); b.andi(26,255); b.addi(20,1); b.addi(21,-1)
# < starts a tag. Inspect opening/closing anchor before hiding tag bytes.
b.mov(25,26); b.addi(25,-60); b.jz(25,'tag_open')
# > closes tag syntax only
b.mov(25,26); b.addi(25,-62); b.jz(25,'tag_close'); b.jnz(24,'body_loop')
b.mov(25,26); b.addi(25,-13); b.jz(25,'body_loop'); b.mov(25,26); b.addi(25,-10); b.jz(25,'newline'); b.mov(25,26); b.addi(25,-32); b.js(25,'body_loop')
b.mov(25,26); b.addi(25,-97); b.js(25,'body_case_done'); b.mov(28,26); b.addi(28,-123); b.js(28,'body_lower'); b.jmp('body_case_done'); b.label('body_lower'); b.addi(26,-32)
b.label('body_case_done'); b.mov(0,22); b.ldi(25,6); b.mul(0,25); b.addi(0,28); b.mov(1,23); b.ldi(25,9); b.mul(1,25); b.ldi(27,130); b.add(1,27); b.mov(2,26); b.jz(30,'body_normal_color'); b_color(3,'c_link'); b.jmp('body_color_done'); b.label('body_normal_color'); b_color(3,'c_text'); b.label('body_color_done'); b.call('K_draw_char'); b.addi(22,1); b.mov(25,22); b.addi(25,-88); b.jz(25,'newline'); b.jmp('body_loop')
b.label('tag_open')
# R20 points after '<'. Capture href, and update link-mode by looking at first bytes.
b.call('capture_href'); b.ld(27,20,0); b.andi(27,255); b.mov(28,27); b.addi(28,-97); b.jz(28,'link_mode_on'); b.mov(28,27); b.addi(28,-47); b.jnz(28,'tag_open_finish'); b.ld(27,20,1); b.andi(27,255); b.addi(27,-97); b.jz(27,'link_mode_off'); b.jmp('tag_open_finish')
b.label('link_mode_on'); b.ldi(30,1); b.jmp('tag_open_finish'); b.label('link_mode_off'); b.ldi(30,0)
b.label('tag_open_finish'); b.ldi(24,1); b.jmp('body_loop')
b.label('tag_close'); b.ldi(24,0); b.jmp('body_loop')
b.label('newline'); b.ldi(22,0); b.addi(23,1); b.jmp('body_loop')
b.label('render_done'); b.ret()


# ---------------------------------------------------------------------------
# Tiny32/20 software SHA-256 + HMAC-SHA256. These routines execute entirely as
# Tiny32 guest instructions using the VM/20 bitwise ISA additions above.
# ---------------------------------------------------------------------------
b.label('sha256_do')
# Copy input to padding workspace.
b_addr(29,TLS_META2); b.ld(0,29,TM_SHA_IN); b_addr(1,TLS_WORK); b.ld(2,29,TM_SHA_LEN); b.call('raw_copy')
# append 0x80 then zero pad until total length mod 64 == 56
b_addr(29,TLS_META2); b.ld(20,29,TM_SHA_LEN); b_addr(21,TLS_WORK); b.add(21,20); b.ldi(22,0x80); b.st(22,21,0); b.addi(20,1); b.addi(21,1)
b.label('sha_pad_loop'); b.mov(23,20); b.andi(23,63); b.addi(23,-56); b.jz(23,'sha_pad_done'); b.ldi(22,0); b.st(22,21,0); b.addi(20,1); b.addi(21,1); b.jmp('sha_pad_loop')
b.label('sha_pad_done')
# high 32 bits of bit-length are zero; low 32 bits big-endian.
b.ldi(22,0); b.st(22,21,0); b.addi(21,4); b.ld(22,29,TM_SHA_LEN); b.shl(22,3); b.bswap(22); b.st(22,21,0); b.addi(20,8)
# block count and H initialization.
b.shr(20,6); b.st(20,29,TM_SHA_BLOCKS); b_addr(22,TLS_WORK); b.st(22,29,TM_SHA_BLOCK)
b.ldi_label(0,'sha_h0'); b_addr(1,TLS_H); b.ldi(2,32); b.call('raw_copy')
b.label('sha_block_loop'); b_addr(29,TLS_META2); b.ld(19,29,TM_SHA_BLOCKS); b.jz(19,'sha_finish')
# W[0..15] = big-endian message words.
b.ld(20,29,TM_SHA_BLOCK); b_addr(21,TLS_W); b.ldi(19,16)
b.label('sha_w16'); b.ld(22,20,0); b.bswap(22); b.st(22,21,0); b.addi(20,4); b.addi(21,4); b.addi(19,-1); b.jnz(19,'sha_w16')
# W[16..63]
b.ldi(19,48)
b.label('sha_wext');
b.ld(22,21,-60); b.mov(23,22); b.ror(23,7); b.mov(24,22); b.ror(24,18); b.xor(23,24); b.mov(24,22); b.shr(24,3); b.xor(23,24)
b.ld(22,21,-8); b.mov(25,22); b.ror(25,17); b.mov(24,22); b.ror(24,19); b.xor(25,24); b.mov(24,22); b.shr(24,10); b.xor(25,24)
b.ld(26,21,-64); b.add(26,23); b.ld(27,21,-28); b.add(26,27); b.add(26,25); b.st(26,21,0); b.addi(21,4); b.addi(19,-1); b.jnz(19,'sha_wext')
# working state a..h in R8..R15
b_addr(20,TLS_H)
for _i,_r in enumerate(range(8,16)): b.ld(_r,20,_i*4)
b.ldi_label(20,'sha_k'); b_addr(21,TLS_W); b.ldi(22,64); b.ldi(23,-1)
b.label('sha_round')
# S1(e)
b.mov(16,12); b.ror(16,6); b.mov(18,12); b.ror(18,11); b.xor(16,18); b.mov(18,12); b.ror(18,25); b.xor(16,18)
# Ch(e,f,g)
b.mov(18,12); b.andr(18,13); b.mov(19,12); b.xor(19,23); b.andr(19,14); b.xor(18,19)
# temp1=h+S1+Ch+K+W
b.add(16,15); b.add(16,18); b.ld(18,20,0); b.add(16,18); b.ld(18,21,0); b.add(16,18)
# S0(a)
b.mov(17,8); b.ror(17,2); b.mov(18,8); b.ror(18,13); b.xor(17,18); b.mov(18,8); b.ror(18,22); b.xor(17,18)
# Maj(a,b,c)
b.mov(18,8); b.andr(18,9); b.mov(19,8); b.andr(19,10); b.xor(18,19); b.mov(19,9); b.andr(19,10); b.xor(18,19); b.add(17,18)
# rotate state
b.mov(15,14); b.mov(14,13); b.mov(13,12); b.mov(12,11); b.add(12,16); b.mov(11,10); b.mov(10,9); b.mov(9,8); b.mov(8,16); b.add(8,17)
b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'sha_round')
# add working state into H
b_addr(20,TLS_H)
for _i,_r in enumerate(range(8,16)):
    b.ld(18,20,_i*4); b.add(18,_r); b.st(18,20,_i*4)
# next block
b_addr(29,TLS_META2); b.ld(20,29,TM_SHA_BLOCK); b.addi(20,64); b.st(20,29,TM_SHA_BLOCK); b.ld(19,29,TM_SHA_BLOCKS); b.addi(19,-1); b.st(19,29,TM_SHA_BLOCKS); b.jmp('sha_block_loop')
b.label('sha_finish')
# output big-endian digest
b_addr(20,TLS_H); b.ld(21,29,TM_SHA_OUT)
for _i in range(8):
    b.ld(22,20,_i*4); b.bswap(22); b.st(22,21,_i*4)
b.ret()

# HMAC-SHA256 parameters live in TLS_META2.
b.label('hmac_do')
b_addr(29,TLS_META2)
# inner pad: 64 bytes (key xor 0x36), then message.
b_addr(20,TLS_HMAC_WORK); b.ldi(21,0); b.ldi(22,64); b.ld(24,29,TM_HKEY); b.ld(25,29,TM_HKEYLEN)
b.label('hmac_inner_pad'); b.mov(26,21); b.sub(26,25); b.js(26,'hmac_inner_key'); b.ldi(23,0); b.jmp('hmac_inner_have')
b.label('hmac_inner_key'); b.ld(23,24,0); b.andi(23,255); b.addi(24,1)
b.label('hmac_inner_have'); b.ldi(27,0x36); b.xor(23,27); b.st(23,20,0); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'hmac_inner_pad')
# append message
b.ld(0,29,TM_HMSG); b.mov(1,20); b.ld(2,29,TM_HMSGLEN); b.call('raw_copy')
# sha(inner)
b_addr(29,TLS_META2); b_addr(20,TLS_HMAC_WORK); b.st(20,29,TM_SHA_IN); b.ld(21,29,TM_HMSGLEN); b.addi(21,64); b.st(21,29,TM_SHA_LEN); b_addr(20,TLS_INNER); b.st(20,29,TM_SHA_OUT); b.call('sha256_do')
# outer pad into TLS_WORK, append inner digest.
b_addr(29,TLS_META2); b_addr(20,TLS_HMAC_WORK); b.ldi(21,0); b.ldi(22,64); b.ld(24,29,TM_HKEY); b.ld(25,29,TM_HKEYLEN)
b.label('hmac_outer_pad'); b.mov(26,21); b.sub(26,25); b.js(26,'hmac_outer_key'); b.ldi(23,0); b.jmp('hmac_outer_have')
b.label('hmac_outer_key'); b.ld(23,24,0); b.andi(23,255); b.addi(24,1)
b.label('hmac_outer_have'); b.ldi(27,0x5c); b.xor(23,27); b.st(23,20,0); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'hmac_outer_pad')
b_addr(0,TLS_INNER); b.mov(1,20); b.ldi(2,32); b.call('raw_copy')
b_addr(29,TLS_META2); b_addr(20,TLS_HMAC_WORK); b.st(20,29,TM_SHA_IN); b.ldi(21,96); b.st(21,29,TM_SHA_LEN); b.ld(20,29,TM_HOUT); b.st(20,29,TM_SHA_OUT); b.call('sha256_do'); b.ret()


# TLS 1.2 P_hash/HMAC-SHA256 PRF. Seed already includes label || seed bytes.
b.label('prf_do')
b_addr(29,TLS_META2)
# A(1)=HMAC(secret, seed)
b.ld(20,29,TM_PRF_SECRET); b.st(20,29,TM_HKEY); b.ld(20,29,TM_PRF_SECLEN); b.st(20,29,TM_HKEYLEN); b.ld(20,29,TM_PRF_SEED); b.st(20,29,TM_HMSG); b.ld(20,29,TM_PRF_SEEDLEN); b.st(20,29,TM_HMSGLEN); b_addr(20,TLS_A); b.st(20,29,TM_HOUT); b.call('hmac_do')
b.label('prf_loop'); b_addr(29,TLS_META2); b.ld(28,29,TM_PRF_OUTLEN); b.jz(28,'prf_done')
# PRF_MSG = A || seed
b_addr(0,TLS_A); b_addr(1,TLS_PRF_MSG); b.ldi(2,32); b.call('raw_copy'); b_addr(29,TLS_META2); b.ld(0,29,TM_PRF_SEED); b.mov(1,1); b.ld(2,29,TM_PRF_SEEDLEN); b.call('raw_copy')
# T = HMAC(secret, PRF_MSG)
b_addr(29,TLS_META2); b.ld(20,29,TM_PRF_SECRET); b.st(20,29,TM_HKEY); b.ld(20,29,TM_PRF_SECLEN); b.st(20,29,TM_HKEYLEN); b_addr(20,TLS_PRF_MSG); b.st(20,29,TM_HMSG); b.ld(20,29,TM_PRF_SEEDLEN); b.addi(20,32); b.st(20,29,TM_HMSGLEN); b_addr(20,TLS_T); b.st(20,29,TM_HOUT); b.call('hmac_do')
# chunk=min(32, remaining)
b_addr(29,TLS_META2); b.ld(28,29,TM_PRF_OUTLEN); b.mov(27,28); b.addi(27,-32); b.js(27,'prf_short'); b.ldi(27,32); b.jmp('prf_chunk')
b.label('prf_short'); b.mov(27,28)
b.label('prf_chunk'); b_addr(0,TLS_T); b.ld(1,29,TM_PRF_OUT); b.mov(2,27); b.call('raw_copy'); b_addr(29,TLS_META2); b.ld(20,29,TM_PRF_OUT); b.add(20,27); b.st(20,29,TM_PRF_OUT); b.ld(20,29,TM_PRF_OUTLEN); b.sub(20,27); b.st(20,29,TM_PRF_OUTLEN); b.jz(20,'prf_done')
# A(i+1)=HMAC(secret,A(i))
b.ld(20,29,TM_PRF_SECRET); b.st(20,29,TM_HKEY); b.ld(20,29,TM_PRF_SECLEN); b.st(20,29,TM_HKEYLEN); b_addr(20,TLS_A); b.st(20,29,TM_HMSG); b.ldi(20,32); b.st(20,29,TM_HMSGLEN); b_addr(20,TLS_A); b.st(20,29,TM_HOUT); b.call('hmac_do'); b.jmp('prf_loop')
b.label('prf_done'); b.ret()


# ---------------------------------------------------------------------------
# Tiny32/20 AES-128 software implementation (table S-box, 176-byte key schedule).
# ---------------------------------------------------------------------------
b.label('aes_sbox_byte'); b.ldi_label(27,'aes_sbox'); b.add(27,0); b.ld(0,27,0); b.andi(0,255); b.ret()
b.label('aes_invsbox_byte'); b.ldi_label(27,'aes_invsbox'); b.add(27,0); b.ld(0,27,0); b.andi(0,255); b.ret()
b.label('aes_xtime'); b.mov(27,0); b.andi(27,128); b.shl(0,1); b.andi(0,255); b.jz(27,'aes_xtime_done'); b.ldi(27,0x1b); b.xor(0,27); b.label('aes_xtime_done'); b.ret()
# GF(2^8) multiply: R0=x,R1=small multiplier -> R0=result.
b.label('aes_gmul'); b.ldi(2,0); b.ldi(3,8)
b.label('aes_gmul_loop'); b.mov(4,1); b.andi(4,1); b.jz(4,'aes_gmul_skip'); b.xor(2,0); b.label('aes_gmul_skip'); b.mov(4,0); b.andi(4,128); b.shl(0,1); b.andi(0,255); b.jz(4,'aes_gmul_red_done'); b.ldi(4,0x1b); b.xor(0,4); b.label('aes_gmul_red_done'); b.shr(1,1); b.addi(3,-1); b.jnz(3,'aes_gmul_loop'); b.mov(0,2); b.ret()

# Expand AES-128 key from TM_AES_KEY into TM_AES_EXP.
b.label('aes_expand'); b_addr(29,TLS_META2); b.ld(0,29,TM_AES_KEY); b.ld(1,29,TM_AES_EXP); b.ldi(2,16); b.call('raw_copy'); b_addr(29,TLS_META2); b.ld(20,29,TM_AES_EXP); b.addi(20,16); b.ldi(21,16); b.ldi(26,1)
b.label('aes_exp_loop'); b.mov(27,21); b.ldi(25,176); b.sub(27,25); b.jz(27,'aes_exp_done')
# temp = previous 4 bytes R8..R11
b.ld(8,20,-4); b.andi(8,255); b.ld(9,20,-3); b.andi(9,255); b.ld(10,20,-2); b.andi(10,255); b.ld(11,20,-1); b.andi(11,255)
b.mov(27,21); b.andi(27,15); b.jnz(27,'aes_exp_nocore')
# RotWord + SubWord
b.mov(12,8); b.mov(0,9); b.call('aes_sbox_byte'); b.mov(8,0); b.mov(0,10); b.call('aes_sbox_byte'); b.mov(9,0); b.mov(0,11); b.call('aes_sbox_byte'); b.mov(10,0); b.mov(0,12); b.call('aes_sbox_byte'); b.mov(11,0); b.xor(8,26)
# next rcon
b.mov(0,26); b.call('aes_xtime'); b.mov(26,0)
b.label('aes_exp_nocore')
# 4 generated bytes
for _j,_r in enumerate([8,9,10,11]):
    b.ld(12,20,-16); b.andi(12,255); b.xor(12,_r); b.st(12,20,0); b.addi(20,1); b.addi(21,1)
b.jmp('aes_exp_loop'); b.label('aes_exp_done'); b.ret()

# SubBytes A -> B
b.label('aes_sub_ab'); b_addr(20,TLS_AES_A); b_addr(21,TLS_AES_B); b.ldi(22,16)
b.label('aes_sub_loop'); b.ld(0,20,0); b.andi(0,255); b.call('aes_sbox_byte'); b.st(0,21,0); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'aes_sub_loop'); b.ret()
# InvSubBytes A -> B
b.label('aes_invsub_ab'); b_addr(20,TLS_AES_A); b_addr(21,TLS_AES_B); b.ldi(22,16)
b.label('aes_invsub_loop'); b.ld(0,20,0); b.andi(0,255); b.call('aes_invsbox_byte'); b.st(0,21,0); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'aes_invsub_loop'); b.ret()
# ShiftRows B -> A mapping
b.label('aes_shift_ba'); b_addr(20,TLS_AES_B); b_addr(21,TLS_AES_A)
for _out,_inp in enumerate([0,5,10,15,4,9,14,3,8,13,2,7,12,1,6,11]):
    b.ld(22,20,_inp); b.andi(22,255); b.st(22,21,_out)
b.ret()
# InvShiftRows B -> A
b.label('aes_invshift_ba'); b_addr(20,TLS_AES_B); b_addr(21,TLS_AES_A)
for _out,_inp in enumerate([0,13,10,7,4,1,14,11,8,5,2,15,12,9,6,3]):
    b.ld(22,20,_inp); b.andi(22,255); b.st(22,21,_out)
b.ret()
# MixColumns A -> B
b.label('aes_mix_ab'); b_addr(20,TLS_AES_A); b_addr(21,TLS_AES_B); b.ldi(22,4)
b.label('aes_mix_col');
for _i,_r in enumerate([8,9,10,11]): b.ld(_r,20,_i); b.andi(_r,255)
b.mov(12,8); b.xor(12,9); b.xor(12,10); b.xor(12,11); b.mov(13,8)
# new0
b.mov(0,8); b.xor(0,9); b.call('aes_xtime'); b.xor(0,8); b.xor(0,12); b.st(0,21,0)
# new1
b.mov(0,9); b.xor(0,10); b.call('aes_xtime'); b.xor(0,9); b.xor(0,12); b.st(0,21,1)
# new2
b.mov(0,10); b.xor(0,11); b.call('aes_xtime'); b.xor(0,10); b.xor(0,12); b.st(0,21,2)
# new3 = a3 ^ t ^ xtime(a3 ^ u)
b.mov(0,11); b.xor(0,13); b.call('aes_xtime'); b.xor(0,11); b.xor(0,12); b.st(0,21,3)
b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'aes_mix_col'); b.ret()
# AddRoundKey B -> A using TM_AES_RK
b.label('aes_addkey_ba'); b_addr(29,TLS_META2); b.ld(20,29,TM_AES_RK); b_addr(21,TLS_AES_B); b_addr(22,TLS_AES_A); b.ldi(23,16)
b.label('aes_ak_ba_loop'); b.ld(24,21,0); b.andi(24,255); b.ld(25,20,0); b.andi(25,255); b.xor(24,25); b.st(24,22,0); b.addi(20,1); b.addi(21,1); b.addi(22,1); b.addi(23,-1); b.jnz(23,'aes_ak_ba_loop'); b.ret()
# AddRoundKey A -> B using TM_AES_RK
b.label('aes_addkey_ab'); b_addr(29,TLS_META2); b.ld(20,29,TM_AES_RK); b_addr(21,TLS_AES_A); b_addr(22,TLS_AES_B); b.ldi(23,16)
b.label('aes_ak_ab_loop'); b.ld(24,21,0); b.andi(24,255); b.ld(25,20,0); b.andi(25,255); b.xor(24,25); b.st(24,22,0); b.addi(20,1); b.addi(21,1); b.addi(22,1); b.addi(23,-1); b.jnz(23,'aes_ak_ab_loop'); b.ret()

# AES-128 encrypt one block, params TM_AES_IN/TM_AES_OUT/TM_AES_EXP.
b.label('aes_encrypt'); b_addr(29,TLS_META2); b.ld(0,29,TM_AES_IN); b_addr(1,TLS_AES_A); b.ldi(2,16); b.call('raw_copy'); b_addr(29,TLS_META2); b.ld(20,29,TM_AES_EXP); b.st(20,29,TM_AES_RK); b.call('aes_addkey_ab')
# current in B after initial key; shift it back through a no-op mapping using inv? copy B->A raw
b_addr(0,TLS_AES_B); b_addr(1,TLS_AES_A); b.ldi(2,16); b.call('raw_copy'); b.ldi(28,1)
b.label('aes_enc_round'); b.call('aes_sub_ab'); b.call('aes_shift_ba'); b.call('aes_mix_ab'); b_addr(29,TLS_META2); b.ld(20,29,TM_AES_EXP); b.mov(21,28); b.shl(21,4); b.add(20,21); b.st(20,29,TM_AES_RK); b.call('aes_addkey_ba'); b.addi(28,1); b.mov(26,28); b.addi(26,-10); b.jnz(26,'aes_enc_round')
# round 10
b.call('aes_sub_ab'); b.call('aes_shift_ba'); b_addr(29,TLS_META2); b.ld(20,29,TM_AES_EXP); b.ldi(24,160); b.add(20,24); b.st(20,29,TM_AES_RK); b.call('aes_addkey_ab'); b_addr(29,TLS_META2); b_addr(0,TLS_AES_B); b.ld(1,29,TM_AES_OUT); b.ldi(2,16); b.call('raw_copy'); b.ret()

# Inverse MixColumns A -> B, generic GF multipliers.
b.label('aes_invmix_ab'); b_addr(20,TLS_AES_A); b_addr(21,TLS_AES_B); b.ldi(22,4)
b.label('aes_invmix_col')
# output0 14*a0 ^ 11*a1 ^ 13*a2 ^ 9*a3
for _out,_spec in enumerate([(14,11,13,9),(9,14,11,13),(13,9,14,11),(11,13,9,14)]):
    b.ldi(26,0)
    for _idx,_mul in enumerate(_spec):
        b.ld(0,20,_idx); b.andi(0,255); b.ldi(1,_mul); b.call('aes_gmul'); b.xor(26,0)
    b.st(26,21,_out)
b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'aes_invmix_col'); b.ret()

# AES-128 decrypt one block.
b.label('aes_decrypt'); b_addr(29,TLS_META2); b.ld(0,29,TM_AES_IN); b_addr(1,TLS_AES_A); b.ldi(2,16); b.call('raw_copy'); b_addr(29,TLS_META2); b.ld(20,29,TM_AES_EXP); b.ldi(24,160); b.add(20,24); b.st(20,29,TM_AES_RK); b.call('aes_addkey_ab'); b.ldi(28,9)
b.label('aes_dec_round')
# current B -> invshift requires B->A
b.call('aes_invshift_ba'); b.call('aes_invsub_ab'); b_addr(29,TLS_META2); b.ld(20,29,TM_AES_EXP); b.mov(21,28); b.shl(21,4); b.add(20,21); b.st(20,29,TM_AES_RK); b.call('aes_addkey_ba'); b.call('aes_invmix_ab'); b.addi(28,-1); b.jnz(28,'aes_dec_round')
# current B -> final invshift/invsub/key0
b.call('aes_invshift_ba'); b.call('aes_invsub_ab'); b_addr(29,TLS_META2); b.ld(20,29,TM_AES_EXP); b.st(20,29,TM_AES_RK); b.call('aes_addkey_ba'); b_addr(29,TLS_META2); b_addr(0,TLS_AES_A); b.ld(1,29,TM_AES_OUT); b.ldi(2,16); b.call('raw_copy'); b.ret()


# Derive TLS 1.2 PSK master secret + CBC key block from current client/server randoms.
b.label('tls_derive_keys')
# premaster constant
b.ldi_label(0,'tls_premaster_const'); b_addr(1,TLS_PREMASTER); b.ldi(2,36); b.call('raw_copy')
# seed = "master secret" || client_random || server_random
b.ldi_label(0,'tls_label_master'); b_addr(1,TLS_SEED); b.ldi(2,13); b.call('raw_copy'); b_addr(0,TLS_CLIENT_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_SERVER_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy')
b_addr(29,TLS_META2); b_addr(20,TLS_PREMASTER); b.st(20,29,TM_PRF_SECRET); b.ldi(20,36); b.st(20,29,TM_PRF_SECLEN); b_addr(20,TLS_SEED); b.st(20,29,TM_PRF_SEED); b.ldi(20,77); b.st(20,29,TM_PRF_SEEDLEN); b_addr(20,TLS_MASTER); b.st(20,29,TM_PRF_OUT); b.ldi(20,48); b.st(20,29,TM_PRF_OUTLEN); b.call('prf_do')
# seed = "key expansion" || server_random || client_random
b.ldi_label(0,'tls_label_keyexp'); b_addr(1,TLS_SEED); b.ldi(2,13); b.call('raw_copy'); b_addr(0,TLS_SERVER_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_CLIENT_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy')
b_addr(29,TLS_META2); b_addr(20,TLS_MASTER); b.st(20,29,TM_PRF_SECRET); b.ldi(20,48); b.st(20,29,TM_PRF_SECLEN); b_addr(20,TLS_SEED); b.st(20,29,TM_PRF_SEED); b.ldi(20,77); b.st(20,29,TM_PRF_SEEDLEN); b_addr(20,TLS_KEYBLOCK); b.st(20,29,TM_PRF_OUT); b.ldi(20,96); b.st(20,29,TM_PRF_OUTLEN); b.call('prf_do')
# split key block
b_addr(0,TLS_KEYBLOCK); b_addr(1,TLS_CMAC); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_KEYBLOCK+32); b_addr(1,TLS_SMAC); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_KEYBLOCK+64); b_addr(1,TLS_CKEY); b.ldi(2,16); b.call('raw_copy'); b_addr(0,TLS_KEYBLOCK+80); b_addr(1,TLS_SKEY); b.ldi(2,16); b.call('raw_copy')
# AES schedules
b_addr(29,TLS_META2); b_addr(20,TLS_CKEY); b.st(20,29,TM_AES_KEY); b_addr(20,TLS_CKEYEXP); b.st(20,29,TM_AES_EXP); b.call('aes_expand'); b_addr(29,TLS_META2); b_addr(20,TLS_SKEY); b.st(20,29,TM_AES_KEY); b_addr(20,TLS_SKEYEXP); b.st(20,29,TM_AES_EXP); b.call('aes_expand'); b.ret()


# Derive TLS 1.2 master secret/key block from VM/20 RSA premaster.
b.label('tls_derive_rsa_keys'); b.addr_label(0,'tls20_premaster'); b_addr(1,TLS_PREMASTER); b.ldi(2,48); b.call('raw_copy')
# master secret seed
b.ldi_label(0,'tls_label_master'); b_addr(1,TLS_SEED); b.ldi(2,13); b.call('raw_copy'); b_addr(0,TLS_CLIENT_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_SERVER_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy')
b_addr(29,TLS_META2); b_addr(20,TLS_PREMASTER); b.st(20,29,TM_PRF_SECRET); b.ldi(20,48); b.st(20,29,TM_PRF_SECLEN); b_addr(20,TLS_SEED); b.st(20,29,TM_PRF_SEED); b.ldi(20,77); b.st(20,29,TM_PRF_SEEDLEN); b_addr(20,TLS_MASTER); b.st(20,29,TM_PRF_OUT); b.ldi(20,48); b.st(20,29,TM_PRF_OUTLEN); b.call('prf_do')
# key expansion seed
b.ldi_label(0,'tls_label_keyexp'); b_addr(1,TLS_SEED); b.ldi(2,13); b.call('raw_copy'); b_addr(0,TLS_SERVER_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_CLIENT_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy')
b_addr(29,TLS_META2); b_addr(20,TLS_MASTER); b.st(20,29,TM_PRF_SECRET); b.ldi(20,48); b.st(20,29,TM_PRF_SECLEN); b_addr(20,TLS_SEED); b.st(20,29,TM_PRF_SEED); b.ldi(20,77); b.st(20,29,TM_PRF_SEEDLEN); b_addr(20,TLS_KEYBLOCK); b.st(20,29,TM_PRF_OUT); b.ldi(20,96); b.st(20,29,TM_PRF_OUTLEN); b.call('prf_do')
b_addr(0,TLS_KEYBLOCK); b_addr(1,TLS_CMAC); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_KEYBLOCK+32); b_addr(1,TLS_SMAC); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_KEYBLOCK+64); b_addr(1,TLS_CKEY); b.ldi(2,16); b.call('raw_copy'); b_addr(0,TLS_KEYBLOCK+80); b_addr(1,TLS_SKEY); b.ldi(2,16); b.call('raw_copy')
b_addr(29,TLS_META2); b_addr(20,TLS_CKEY); b.st(20,29,TM_AES_KEY); b_addr(20,TLS_CKEYEXP); b.st(20,29,TM_AES_EXP); b.call('aes_expand'); b_addr(29,TLS_META2); b_addr(20,TLS_SKEY); b.st(20,29,TM_AES_KEY); b_addr(20,TLS_SKEYEXP); b.st(20,29,TM_AES_EXP); b.call('aes_expand'); b.ret()

# Build TLS 1.2 CBC record MAC into TLS_INNER from TLS_REC_META.
b.label('tls_record_mac')
b_addr(30,TLS_REC_META); b_addr(20,TLS_MACMSG)
# seq_num as 64-bit big-endian; VM/20 proof uses low 32 bits only.
b.ldi(21,0); b.st(21,20,0); b.ld(21,30,RM_SEQ); b.bswap(21); b.st(21,20,4)
# type, version 03 03, length u16 big-endian.
b.ld(21,30,RM_TYPE); b.st(21,20,8); b.ldi(21,3); b.st(21,20,9); b.st(21,20,10); b.ld(21,30,RM_INLEN); b.mov(22,21); b.shr(22,8); b.andi(22,255); b.st(22,20,11); b.andi(21,255); b.st(21,20,12)
# plaintext after 13-byte header.
b.ld(0,30,RM_IN); b_addr(1,TLS_MACMSG+13); b.ld(2,30,RM_INLEN); b.call('raw_copy')
# HMAC(record_mac, header||plain). Save record values before HMAC clobbers registers.
b_addr(30,TLS_REC_META); b.ld(24,30,RM_MAC); b.ld(25,30,RM_INLEN)
b_addr(29,TLS_META2); b.st(24,29,TM_HKEY); b.ldi(20,32); b.st(20,29,TM_HKEYLEN); b_addr(20,TLS_MACMSG); b.st(20,29,TM_HMSG); b.mov(20,25); b.addi(20,13); b.st(20,29,TM_HMSGLEN); b_addr(20,TLS_INNER); b.st(20,29,TM_HOUT); b.call('hmac_do'); b.ret()

# TLS 1.2 AES-CBC protect. Output is record payload (explicit IV || ciphertext).
b.label('tls_protect'); b.call('tls_record_mac'); b_addr(30,TLS_REC_META)
# TLS_PLAIN = plaintext || MAC.
b.ld(0,30,RM_IN); b_addr(1,TLS_PLAIN); b.ld(2,30,RM_INLEN); b.call('raw_copy'); b_addr(30,TLS_REC_META); b_addr(0,TLS_INNER); b_addr(1,TLS_PLAIN); b.ld(20,30,RM_INLEN); b.add(1,20); b.ldi(2,32); b.call('raw_copy')
# padlen 0..15 so (plain+mac+padlen+1)%16==0.
b_addr(30,TLS_REC_META); b.ld(20,30,RM_INLEN); b.addi(20,32); b.ldi(21,0)
b.label('tls_pad_find'); b.mov(22,20); b.add(22,21); b.addi(22,1); b.andi(22,15); b.jz(22,'tls_pad_ready'); b.addi(21,1); b.jmp('tls_pad_find')
b.label('tls_pad_ready'); b_addr(23,TLS_PLAIN); b.add(23,20); b.ldi(22,1); b.add(22,21)
b.label('tls_pad_write'); b.st(21,23,0); b.addi(23,1); b.addi(22,-1); b.jnz(22,'tls_pad_write'); b.add(20,21); b.addi(20,1)
# Store qlen/block count in record metadata; AES routines freely clobber working regs.
b_addr(30,TLS_REC_META); b.st(20,30,RM_QLEN); b.mov(21,20); b.shr(21,4); b.st(21,30,RM_BLOCKS); b.ldi(21,0); b.st(21,30,RM_BLOCKIDX)
# explicit IV = seq*16 + byte_index.
b.ld(24,30,RM_OUT); b.ld(25,30,RM_SEQ); b.shl(25,4); b.ldi(26,0); b.ldi(27,16)
b.label('tls_iv_write'); b.mov(28,25); b.add(28,26); b.andi(28,255); b.st(28,24,0); b.addi(24,1); b.addi(26,1); b.addi(27,-1); b.jnz(27,'tls_iv_write')
# CBC block loop. All pointers are recomputed from block index after AES calls.
b.label('tls_enc_block'); b_addr(30,TLS_REC_META); b.ld(27,30,RM_BLOCKIDX); b.ld(22,30,RM_BLOCKS); b.mov(23,27); b.sub(23,22); b.jz(23,'tls_enc_done')
# plain = TLS_PLAIN + idx*16; prev = out + idx*16; blockin = XOR.
b.mov(21,27); b.shl(21,4); b_addr(26,TLS_PLAIN); b.add(26,21); b.ld(25,30,RM_OUT); b.add(25,21); b_addr(28,TLS_BLOCK_IN); b.ldi(22,16)
b.label('tls_enc_xor'); b.ld(8,26,0); b.andi(8,255); b.ld(9,25,0); b.andi(9,255); b.xor(8,9); b.st(8,28,0); b.addi(26,1); b.addi(25,1); b.addi(28,1); b.addi(22,-1); b.jnz(22,'tls_enc_xor')
# encrypt block using selected expanded key.
b_addr(30,TLS_REC_META); b_addr(29,TLS_META2); b_addr(20,TLS_BLOCK_IN); b.st(20,29,TM_AES_IN); b_addr(20,TLS_BLOCK_OUT); b.st(20,29,TM_AES_OUT); b.ld(20,30,RM_KEYEXP); b.st(20,29,TM_AES_EXP); b.call('aes_encrypt')
# Recompute destination = out + 16 + idx*16 and copy cipher.
b_addr(30,TLS_REC_META); b.ld(27,30,RM_BLOCKIDX); b.mov(21,27); b.shl(21,4); b.ld(24,30,RM_OUT); b.addi(24,16); b.add(24,21); b_addr(0,TLS_BLOCK_OUT); b.mov(1,24); b.ldi(2,16); b.call('raw_copy'); b_addr(30,TLS_REC_META); b.ld(27,30,RM_BLOCKIDX); b.addi(27,1); b.st(27,30,RM_BLOCKIDX); b.jmp('tls_enc_block')
b.label('tls_enc_done'); b_addr(30,TLS_REC_META); b.ld(20,30,RM_QLEN); b.addi(20,16); b.st(20,30,RM_OUTLEN); b.ret()

# TLS 1.2 AES-CBC unprotect + MAC/padding verification. Returns R0=plaintext length or -1.
b.label('tls_unprotect'); b_addr(30,TLS_REC_META); b.ld(20,30,RM_INLEN); b.addi(20,-16); b.js(20,'tls_unprotect_fail'); b.mov(21,20); b.andi(21,15); b.jnz(21,'tls_unprotect_fail'); b.jz(20,'tls_unprotect_fail'); b.st(20,30,RM_QLEN); b.mov(21,20); b.shr(21,4); b.st(21,30,RM_BLOCKS); b.ldi(21,0); b.st(21,30,RM_BLOCKIDX)
# CBC decrypt loop; recompute every pointer from block index around AES calls.
b.label('tls_dec_block'); b_addr(30,TLS_REC_META); b.ld(27,30,RM_BLOCKIDX); b.ld(22,30,RM_BLOCKS); b.mov(23,27); b.sub(23,22); b.jz(23,'tls_dec_done'); b.mov(21,27); b.shl(21,4)
# current cipher = input+16+idx*16; prev = input+idx*16.
b.ld(26,30,RM_IN); b.addi(26,16); b.add(26,21); b.ld(25,30,RM_IN); b.add(25,21)
# decrypt current cipher block.
b_addr(29,TLS_META2); b.st(26,29,TM_AES_IN); b_addr(22,TLS_BLOCK_OUT); b.st(22,29,TM_AES_OUT); b.ld(22,30,RM_KEYEXP); b.st(22,29,TM_AES_EXP); b.call('aes_decrypt')
# Recompute prev/output after AES; xor decrypted block with previous cipher/IV into TLS_PLAIN.
b_addr(30,TLS_REC_META); b.ld(27,30,RM_BLOCKIDX); b.mov(21,27); b.shl(21,4); b.ld(25,30,RM_IN); b.add(25,21); b_addr(24,TLS_PLAIN); b.add(24,21); b_addr(28,TLS_BLOCK_OUT); b.ldi(22,16)
b.label('tls_dec_xor'); b.ld(8,28,0); b.andi(8,255); b.ld(9,25,0); b.andi(9,255); b.xor(8,9); b.st(8,24,0); b.addi(28,1); b.addi(25,1); b.addi(24,1); b.addi(22,-1); b.jnz(22,'tls_dec_xor')
b_addr(30,TLS_REC_META); b.ld(27,30,RM_BLOCKIDX); b.addi(27,1); b.st(27,30,RM_BLOCKIDX); b.jmp('tls_dec_block')
b.label('tls_dec_done')
# qlen=cipher bytes; last byte is padlen.
b_addr(30,TLS_REC_META); b.ld(20,30,RM_QLEN); b_addr(24,TLS_PLAIN); b.mov(23,24); b.add(23,20); b.addi(23,-1); b.ld(21,23,0); b.andi(21,255); b.mov(22,21); b.addi(22,1); b.mov(27,20); b.sub(27,22); b.addi(27,-32); b.js(27,'tls_unprotect_fail')
# verify padding bytes.
b.mov(26,23); b.ldi(22,1); b.add(22,21)
b.label('tls_pad_check'); b.ld(8,26,0); b.andi(8,255); b.sub(8,21); b.jnz(8,'tls_unprotect_fail'); b.addi(26,-1); b.addi(22,-1); b.jnz(22,'tls_pad_check')
# Save caller output + plaintext length across HMAC, then calculate expected MAC.
b_addr(30,TLS_REC_META); b.ld(20,30,RM_OUT); b.st(20,30,RM_SAVEDOUT); b.st(27,30,RM_PLAINLEN); b_addr(20,TLS_PLAIN); b.st(20,30,RM_IN); b.st(27,30,RM_INLEN); b.call('tls_record_mac')
# reload plaintext len and compare stored MAC at TLS_PLAIN+plainlen with TLS_INNER.
b_addr(30,TLS_REC_META); b.ld(27,30,RM_PLAINLEN); b_addr(20,TLS_PLAIN); b.add(20,27); b_addr(21,TLS_INNER); b.ldi(22,32)
b.label('tls_mac_check'); b.ld(8,20,0); b.andi(8,255); b.ld(9,21,0); b.andi(9,255); b.sub(8,9); b.jnz(8,'tls_unprotect_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'tls_mac_check')
# copy plaintext to caller output; restore output length.
b_addr(30,TLS_REC_META); b.ld(27,30,RM_PLAINLEN); b.ld(1,30,RM_SAVEDOUT); b_addr(0,TLS_PLAIN); b.mov(2,27); b.call('raw_copy'); b_addr(30,TLS_REC_META); b.ld(27,30,RM_PLAINLEN); b.st(27,30,RM_OUTLEN); b.mov(0,27); b.ret()
b.label('tls_unprotect_fail'); b.ldi(0,-1); b.ret()

# --- Tiny32/20 1024-bit unsigned arithmetic and RSA public operation. ---
# big_copy32(R20=src,R21=dst): 32 u32 limbs.
b.label('big_copy32'); b.ldi(22,32)
b.label('big_copy32_loop'); b.ld(23,20,0); b.st(23,21,0); b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'big_copy32_loop'); b.ret()
# big_zero32(R20=dst)
b.label('big_zero32'); b.ldi(22,32); b.ldi(23,0)
b.label('big_zero32_loop'); b.st(23,20,0); b.addi(20,4); b.addi(22,-1); b.jnz(22,'big_zero32_loop'); b.ret()
# big_ge_n(R20=value) -> R0=1 if value >= RSA_N unsigned.
b.label('big_ge_n'); b.addi(20,124); b_addr(21,RSA_N+124); b.ldi(22,32)
b.label('big_ge_loop'); b.ld(23,20,0); b.ld(24,21,0); b.mov(25,23); b.sub(25,24); b.jz(25,'big_ge_next'); b.mov(25,23); b.ult(25,24); b.jnz(25,'big_ge_no'); b.ldi(0,1); b.ret()
b.label('big_ge_next'); b.addi(20,-4); b.addi(21,-4); b.addi(22,-1); b.jnz(22,'big_ge_loop'); b.ldi(0,1); b.ret()
b.label('big_ge_no'); b.ldi(0,0); b.ret()
# big_sub_n(R20=in/out): subtract RSA_N with borrow.
b.label('big_sub_n'); b_addr(21,RSA_N); b.ldi(22,32); b.ldi(27,0)
b.label('big_sub_loop'); b.ld(8,20,0); b.ld(9,21,0); b.mov(10,8); b.sub(10,9); b.mov(11,8); b.ult(11,9); b.mov(12,10); b.ult(12,27); b.sub(10,27); b.mov(27,11); b.add(27,12); b.st(10,20,0); b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'big_sub_loop'); b.ret()
# big_add_mod(R20=x,R21=y,R22=out): (x+y) mod RSA_N, supports out aliasing x/y.
b.label('big_add_mod'); b.mov(26,22); b.mov(28,20); b.mov(29,21); b.mov(30,22); b.ldi(24,32); b.ldi(27,0)
b.label('big_add_loop'); b.ld(8,28,0); b.ld(9,29,0); b.mov(10,8); b.add(10,9); b.mov(11,10); b.ult(11,8); b.mov(12,10); b.add(12,27); b.mov(13,12); b.ult(13,10); b.mov(27,11); b.add(27,13); b.st(12,30,0); b.addi(28,4); b.addi(29,4); b.addi(30,4); b.addi(24,-1); b.jnz(24,'big_add_loop')
# If carry, actual sum >= 2^1024 > N, so subtract N once. Otherwise compare. R26 preserves output across compare.
b.mov(20,26); b.jnz(27,'big_add_reduce'); b.call('big_ge_n'); b.jz(0,'big_add_done'); b.mov(20,26)
b.label('big_add_reduce'); b.call('big_sub_n')
b.label('big_add_done'); b.ret()
# rsa_modmul(R20=A,R21=B,R22=OUT): bit-serial modular multiplication, modulus fixed RSA_N.
# Loop state lives in RSA_META because arithmetic subroutines intentionally clobber working registers.
b.label('rsa_modmul'); b_addr(29,RSA_META); b.st(21,29,RM_BPTR2); b.st(22,29,RM_OUTPTR2); b.ldi(23,0); b.st(23,29,RM_LIMB2); b.mov(20,20); b_addr(21,RSA_TMP); b.call('big_copy32'); b_addr(20,RSA_SUM); b.call('big_zero32')
b.label('rsa_mul_limb'); b_addr(29,RSA_META); b.ld(23,29,RM_LIMB2); b.mov(22,23); b.addi(22,-32); b.jz(22,'rsa_mul_done'); b.ld(24,29,RM_BPTR2); b.mov(25,23); b.shl(25,2); b.add(24,25); b.ld(18,24,0); b.st(18,29,RM_WORD2); b.ldi(19,0); b.st(19,29,RM_BIT2)
b.label('rsa_mul_bit'); b_addr(29,RSA_META); b.ld(19,29,RM_BIT2); b.mov(17,19); b.addi(17,-32); b.jz(17,'rsa_mul_next_limb'); b.ld(18,29,RM_WORD2); b.mov(17,18); b.andi(17,1); b.jz(17,'rsa_mul_noadd'); b_addr(20,RSA_SUM); b_addr(21,RSA_TMP); b_addr(22,RSA_SUM); b.call('big_add_mod')
b.label('rsa_mul_noadd'); b_addr(20,RSA_TMP); b_addr(21,RSA_TMP); b_addr(22,RSA_TMP); b.call('big_add_mod'); b_addr(29,RSA_META); b.ld(18,29,RM_WORD2); b.shr(18,1); b.st(18,29,RM_WORD2); b.ld(19,29,RM_BIT2); b.addi(19,1); b.st(19,29,RM_BIT2); b.jmp('rsa_mul_bit')
b.label('rsa_mul_next_limb'); b_addr(29,RSA_META); b.ld(23,29,RM_LIMB2); b.addi(23,1); b.st(23,29,RM_LIMB2); b.jmp('rsa_mul_limb')
b.label('rsa_mul_done'); b_addr(29,RSA_META); b.ld(21,29,RM_OUTPTR2); b_addr(20,RSA_SUM); b.call('big_copy32'); b.ret()
# rsa_exp3(): RSA_R = tls20_em^3 mod RSA_N. e=3 is read/validated from the pinned cert profile.
b.label('rsa_exp3'); b.addr_label(20,'tls20_em_limbs'); b_addr(21,RSA_A); b.call('big_copy32'); b_addr(20,RSA_A); b_addr(21,RSA_A); b_addr(22,RSA_B); b.call('rsa_modmul'); b_addr(20,RSA_B); b_addr(21,RSA_A); b_addr(22,RSA_R); b.call('rsa_modmul'); b.ret()
# rsa_emit_be(R20=128-byte raw dst): serialize RSA_R big-endian.
b.label('rsa_emit_be'); b.mov(28,20); b_addr(21,RSA_R+124); b.ldi(22,32)
b.label('rsa_emit_limb'); b.ld(23,21,0); b.mov(24,23); b.shr(24,24); b.andi(24,255); b.st(24,28,0); b.mov(24,23); b.shr(24,16); b.andi(24,255); b.st(24,28,1); b.mov(24,23); b.shr(24,8); b.andi(24,255); b.st(24,28,2); b.andi(23,255); b.st(23,28,3); b.addi(28,4); b.addi(21,-4); b.addi(22,-1); b.jnz(22,'rsa_emit_limb'); b.ret()
# tls20_cert_verify(R20=DER ptr,R21=len) -> R0=0/-1. Pins SHA-256, hostname bytes, extracts/validates modulus.
b.label('tls20_cert_verify'); b.mov(26,20); b.mov(27,21); b_addr(29,RSA_META); b.st(26,29,RM_MODPTR2); b.st(27,29,RM_CERTLEN2); b.ldi(0,0); b.st(0,29,RM_CERTOK2); b.st(0,29,RM_HOSTOK2); b.st(0,29,RM_RSAOK2)
# SHA256(DER) and compare pinned digest.
b_addr(29,TLS_META2); b.st(26,29,TM_SHA_IN); b.st(27,29,TM_SHA_LEN); b_addr(20,RSA_CERT_SHA); b.st(20,29,TM_SHA_OUT); b.call('sha256_do'); b_addr(20,RSA_CERT_SHA); b.ldi_label(21,'tls20_cert_sha'); b.ldi(22,32)
b.label('cert_sha_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'cert_verify_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'cert_sha_cmp'); b_addr(29,RSA_META); b.ldi(23,1); b.st(23,29,RM_CERTOK2)
# Scan DER for ASCII hostname tls20.test.
b_addr(29,RSA_META); b.ld(20,29,RM_MODPTR2); b.ld(22,29,RM_CERTLEN2); b.addi(22,-10)
b.label('cert_host_outer'); b.js(22,'cert_verify_fail'); b.mov(24,20); b.ldi_label(25,'tls20_host_ascii'); b.ldi(23,10)
b.label('cert_host_inner'); b.ld(8,24,0); b.andi(8,255); b.ld(9,25,0); b.andi(9,255); b.sub(8,9); b.jnz(8,'cert_host_next'); b.addi(24,1); b.addi(25,1); b.addi(23,-1); b.jnz(23,'cert_host_inner'); b_addr(29,RSA_META); b.ldi(23,1); b.st(23,29,RM_HOSTOK2); b.jmp('cert_find_mod')
b.label('cert_host_next'); b.addi(20,1); b.addi(22,-1); b.jmp('cert_host_outer')
# Locate DER INTEGER encoding 02 81 81 00 used by this 1024-bit RSA modulus.
b.label('cert_find_mod'); b_addr(29,RSA_META); b.ld(20,29,RM_MODPTR2); b.ld(22,29,RM_CERTLEN2); b.addi(22,-132)
b.label('cert_mod_scan'); b.js(22,'cert_verify_fail'); b.ld(8,20,0); b.andi(8,255); b.addi(8,-2); b.jnz(8,'cert_mod_next'); b.ld(8,20,1); b.andi(8,255); b.ldi(7,129); b.sub(8,7); b.jnz(8,'cert_mod_next'); b.ld(8,20,2); b.andi(8,255); b.ldi(7,129); b.sub(8,7); b.jnz(8,'cert_mod_next'); b.ld(8,20,3); b.andi(8,255); b.jnz(8,'cert_mod_next'); b.addi(20,4); b.jmp('cert_mod_found')
b.label('cert_mod_next'); b.addi(20,1); b.addi(22,-1); b.jmp('cert_mod_scan')
# Convert 128 big-endian modulus bytes into 32 little-endian u32 limbs.
b.label('cert_mod_found'); b.addi(20,124); b_addr(21,RSA_N); b.ldi(22,32)
b.label('cert_mod_limb'); b.ld(8,20,0); b.andi(8,255); b.shl(8,24); b.ld(9,20,1); b.andi(9,255); b.shl(9,16); b.add(8,9); b.ld(9,20,2); b.andi(9,255); b.shl(9,8); b.add(8,9); b.ld(9,20,3); b.andi(9,255); b.add(8,9); b.st(8,21,0); b.addi(20,-4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'cert_mod_limb')
# Compare extracted modulus with the public key pinned to the certificate fingerprint.
b_addr(20,RSA_N); b.ldi_label(21,'tls20_modulus_expected'); b.ldi(22,32)
b.label('cert_mod_cmp'); b.ld(8,20,0); b.ld(9,21,0); b.sub(8,9); b.jnz(8,'cert_verify_fail'); b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'cert_mod_cmp'); b_addr(29,RSA_META); b.ldi(23,1); b.st(23,29,RM_RSAOK2); b.ldi(0,0); b.ret()
b.label('cert_verify_fail'); b.ldi(0,-1); b.ret()

# One-time SHA-256 known-answer self-test ("abc").
b.label('crypto_selftest_once'); b_addr(29,TLS_META2); b.ld(20,29,TM_CRYPTO_OK); b.jnz(20,'crypto_selftest_done')
b.ldi_label(20,'tls_abc'); b.st(20,29,TM_SHA_IN); b.ldi(20,3); b.st(20,29,TM_SHA_LEN); b_addr(20,TLS_TEST_OUT); b.st(20,29,TM_SHA_OUT); b.call('sha256_do')
b_addr(20,TLS_TEST_OUT); b.ldi_label(21,'tls_sha_abc'); b.ldi(22,32)
b.label('crypto_test_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'crypto_selftest_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'crypto_test_cmp')
# HMAC-SHA256 RFC 4231 test case 1.
b_addr(29,TLS_META2); b.ldi_label(20,'tls_hmac_key'); b.st(20,29,TM_HKEY); b.ldi(20,20); b.st(20,29,TM_HKEYLEN); b.ldi_label(20,'tls_hmac_msg'); b.st(20,29,TM_HMSG); b.ldi(20,8); b.st(20,29,TM_HMSGLEN); b_addr(20,TLS_TEST_OUT); b.st(20,29,TM_HOUT); b.call('hmac_do')
b_addr(20,TLS_TEST_OUT); b.ldi_label(21,'tls_hmac_expected'); b.ldi(22,32)
b.label('crypto_hmac_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'crypto_selftest_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'crypto_hmac_cmp')
# TLS PRF known-answer test, 64 bytes.
b_addr(29,TLS_META2); b.ldi_label(20,'tls_prf_secret'); b.st(20,29,TM_PRF_SECRET); b.ldi(20,6); b.st(20,29,TM_PRF_SECLEN); b.ldi_label(20,'tls_prf_seedtest'); b.st(20,29,TM_PRF_SEED); b.ldi(20,14); b.st(20,29,TM_PRF_SEEDLEN); b_addr(20,TLS_TEST_OUT); b.st(20,29,TM_PRF_OUT); b.ldi(20,64); b.st(20,29,TM_PRF_OUTLEN); b.call('prf_do')
b_addr(20,TLS_TEST_OUT); b.ldi_label(21,'tls_prf_expected'); b.ldi(22,64)
b.label('crypto_prf_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'crypto_selftest_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'crypto_prf_cmp')
# AES-128 FIPS-197 known-answer encrypt/decrypt.
b_addr(29,TLS_META2); b.ldi_label(20,'aes_test_key'); b.st(20,29,TM_AES_KEY); b_addr(20,TLS_CKEYEXP); b.st(20,29,TM_AES_EXP); b.call('aes_expand'); b_addr(29,TLS_META2); b.ldi_label(20,'aes_test_pt'); b.st(20,29,TM_AES_IN); b_addr(20,TLS_TEST_OUT); b.st(20,29,TM_AES_OUT); b.call('aes_encrypt')
b_addr(20,TLS_TEST_OUT); b.ldi_label(21,'aes_test_ct'); b.ldi(22,16)
b.label('crypto_aesenc_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'crypto_selftest_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'crypto_aesenc_cmp')
# decrypt generated ciphertext back to plaintext
b_addr(29,TLS_META2); b_addr(20,TLS_TEST_OUT); b.st(20,29,TM_AES_IN); b_addr(20,TLS_TEST_OUT+32); b.st(20,29,TM_AES_OUT); b.call('aes_decrypt'); b_addr(20,TLS_TEST_OUT+32); b.ldi_label(21,'aes_test_pt'); b.ldi(22,16)
b.label('crypto_aesdec_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'crypto_selftest_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'crypto_aesdec_cmp')
# TLS PSK master/key-block derivation reference vector (legacy crypto KAT) from a deterministic TLS 1.2 transcript.
b.ldi_label(0,'tls_test_cr'); b_addr(1,TLS_CLIENT_RANDOM); b.ldi(2,32); b.call('raw_copy'); b.ldi_label(0,'tls_test_sr'); b_addr(1,TLS_SERVER_RANDOM); b.ldi(2,32); b.call('raw_copy'); b.call('tls_derive_keys')
b_addr(20,TLS_MASTER); b.ldi_label(21,'tls_test_master'); b.ldi(22,48)
b.label('crypto_master_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'crypto_selftest_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'crypto_master_cmp')
b_addr(20,TLS_KEYBLOCK); b.ldi_label(21,'tls_test_keyblock'); b.ldi(22,96)
b.label('crypto_keyblock_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'crypto_selftest_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'crypto_keyblock_cmp')
# TLS CBC record known-answer: client Finished from the same reference transcript.
b_addr(29,TLS_REC_META); b_addr(20,TLS_CKEYEXP); b.st(20,29,RM_KEYEXP); b_addr(20,TLS_CMAC); b.st(20,29,RM_MAC); b.ldi(20,0); b.st(20,29,RM_SEQ); b.ldi(20,22); b.st(20,29,RM_TYPE); b.ldi_label(20,'tls_test_fin_plain'); b.st(20,29,RM_IN); b.ldi(20,16); b.st(20,29,RM_INLEN); b_addr(20,TLS_TEST_OUT); b.st(20,29,RM_OUT); b.call('tls_protect')
b_addr(20,TLS_TEST_OUT); b.ldi_label(21,'tls_test_fin_protected'); b.ldi(22,80)
b.label('crypto_record_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'crypto_selftest_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'crypto_record_cmp')
# decrypt the same payload and recover Finished plaintext
b_addr(29,TLS_REC_META); b_addr(20,TLS_CKEYEXP); b.st(20,29,RM_KEYEXP); b_addr(20,TLS_CMAC); b.st(20,29,RM_MAC); b.ldi(20,0); b.st(20,29,RM_SEQ); b.ldi(20,22); b.st(20,29,RM_TYPE); b_addr(20,TLS_TEST_OUT); b.st(20,29,RM_IN); b.ldi(20,80); b.st(20,29,RM_INLEN); b_addr(20,TLS_TEST_OUT+128); b.st(20,29,RM_OUT); b.call('tls_unprotect'); b.addi(0,-16); b.jnz(0,'crypto_selftest_fail')
b_addr(20,TLS_TEST_OUT+128); b.ldi_label(21,'tls_test_fin_plain'); b.ldi(22,16)
b.label('crypto_record_plain_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'crypto_selftest_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'crypto_record_plain_cmp')
# RSA e=3 known-answer using the pinned VM/20 modulus; all bignum work executes as Tiny32 instructions.
b.ldi_label(20,'tls20_modulus_expected'); b_addr(21,RSA_N); b.call('big_copy32'); b.call('rsa_exp3'); b_addr(20,RSA_R); b.addr_label(21,'tls20_cipher_expected'); b.ldi(22,32)
b.label('crypto_rsa_cmp'); b.ld(23,20,0); b.ld(24,21,0); b.sub(23,24); b.jnz(23,'crypto_selftest_fail'); b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'crypto_rsa_cmp')
b_addr(29,TLS_META2); b.ldi(20,8); b.st(20,29,TM_CRYPTO_OK); b.ret()
b.label('crypto_selftest_fail'); b_addr(29,TLS_META2); b.ldi(20,-1); b.st(20,29,TM_CRYPTO_OK)
b.label('crypto_selftest_done'); b.ret()

# Browser-owned keyboard mailbox. This is process code, not kernel UI logic.

# --- Tiny32/20 TLS 1.2 PSK protocol engine. Host supplies only raw connected sockets. ---
# send_all(R0=fd,R1=raw guest ptr,R2=len) -> R0=0/-1.
b.label('sock_send_all'); b.mov(20,0); b.mov(21,1); b.mov(22,2)
b.label('sock_send_loop'); b.jz(22,'sock_send_done'); b.mov(0,20); b.mov(1,21); b.mov(2,22); b.sys(7); b.js(0,'sock_send_fail'); b.jz(0,'sock_send_fail'); b.add(21,0); b.sub(22,0); b.jmp('sock_send_loop')
b.label('sock_send_done'); b.ldi(0,0); b.ret(); b.label('sock_send_fail'); b.ldi(0,-1); b.ret()

# recv_exact(R0=fd,R1=raw guest ptr,R2=len) -> R0=0/-1.
b.label('sock_recv_exact'); b.mov(20,0); b.mov(21,1); b.mov(22,2)
b.label('sock_recv_loop'); b.jz(22,'sock_recv_done'); b.mov(0,20); b.mov(1,21); b.mov(2,22); b.sys(8); b.js(0,'sock_recv_fail'); b.jz(0,'sock_recv_fail'); b.add(21,0); b.sub(22,0); b.jmp('sock_recv_loop')
b.label('sock_recv_done'); b.ldi(0,0); b.ret(); b.label('sock_recv_fail'); b.ldi(0,-1); b.ret()

# Append raw handshake bytes R0/R1 to the guest-owned transcript.
b.label('tls_transcript_append'); b.mov(24,0); b.mov(25,1); b_addr(29,TLS_META2); b.ld(26,29,TM_TLS_TLEN); b_addr(1,TLS_TRANSCRIPT); b.add(1,26); b.mov(0,24); b.mov(2,25); b.call('raw_copy'); b_addr(29,TLS_META2); b.ld(26,29,TM_TLS_TLEN); b.add(26,25); b.st(26,29,TM_TLS_TLEN); b.ret()

# Send unencrypted TLS 1.2 record: R0=type,R1=payload,R2=len.
b.label('tls_send_plain_record'); b.mov(23,0); b.mov(24,1); b.mov(25,2); b_addr(20,TLS_TX); b.st(23,20,0); b.ldi(26,3); b.st(26,20,1); b.st(26,20,2); b.mov(26,25); b.shr(26,8); b.andi(26,255); b.st(26,20,3); b.mov(26,25); b.andi(26,255); b.st(26,20,4); b.mov(0,24); b_addr(1,TLS_TX+5); b.mov(2,25); b.call('raw_copy'); b_addr(29,TLS_META2); b.ld(0,29,TM_TLS_FD); b_addr(1,TLS_TX); b.mov(2,25); b.addi(2,5); b.call('sock_send_all'); b.ret()

# Receive one TLS record into TLS_RX. Returns R0=type,R1=payload length or R0=-1.
b.label('tls_recv_record'); b_addr(29,TLS_META2); b.ld(0,29,TM_TLS_FD); b_addr(1,TLS_RX); b.ldi(2,5); b.call('sock_recv_exact'); b.js(0,'tls_recv_record_fail'); b_addr(20,TLS_RX); b.ld(23,20,0); b.andi(23,255); b.ld(21,20,3); b.andi(21,255); b.shl(21,8); b.ld(22,20,4); b.andi(22,255); b.add(21,22); b.mov(22,21); b.ldi(24,4096); b.sub(22,24); b.js(22,'tls_recv_len_ok'); b.jz(22,'tls_recv_len_ok'); b.jmp('tls_recv_record_fail')
b.label('tls_recv_len_ok'); b.mov(25,21); b_addr(29,TLS_META2); b.ld(0,29,TM_TLS_FD); b_addr(1,TLS_RX+5); b.mov(2,25); b.call('sock_recv_exact'); b.js(0,'tls_recv_record_fail'); b.mov(0,23); b.mov(1,25); b.ret()
b.label('tls_recv_record_fail'); b.ldi(0,-1); b.ldi(1,0); b.ret()

# Send MAC+AES-CBC protected record using client write keys. R0=type,R1=plain,R2=len.
b.label('tls_send_protected'); b.mov(23,0); b.mov(24,1); b.mov(25,2); b_addr(29,TLS_META2); b.ld(26,29,TM_TLS_CSEQ); b_addr(30,TLS_REC_META); b_addr(20,TLS_CKEYEXP); b.st(20,30,RM_KEYEXP); b_addr(20,TLS_CMAC); b.st(20,30,RM_MAC); b.st(26,30,RM_SEQ); b.st(23,30,RM_TYPE); b.st(24,30,RM_IN); b.st(25,30,RM_INLEN); b_addr(20,TLS_TEST_OUT); b.st(20,30,RM_OUT); b.call('tls_protect')
# Build header first, then copy protected payload after it. Tiny32 ST32 is a 4-byte store, so this ordering prevents header writes from zeroing the first IV bytes.
b_addr(30,TLS_REC_META); b.ld(25,30,RM_OUTLEN); b.ld(23,30,RM_TYPE); b_addr(20,TLS_TX); b.st(23,20,0); b.ldi(26,3); b.st(26,20,1); b.st(26,20,2); b.mov(26,25); b.shr(26,8); b.andi(26,255); b.st(26,20,3); b.mov(26,25); b.andi(26,255); b.st(26,20,4); b_addr(0,TLS_TEST_OUT); b_addr(1,TLS_TX+5); b.mov(2,25); b.call('raw_copy'); b_addr(29,TLS_META2); b.ld(0,29,TM_TLS_FD); b_addr(1,TLS_TX); b.mov(2,25); b.addi(2,5); b.call('sock_send_all'); b.js(0,'tls_send_protected_done'); b_addr(29,TLS_META2); b.ld(26,29,TM_TLS_CSEQ); b.addi(26,1); b.st(26,29,TM_TLS_CSEQ)
b.label('tls_send_protected_done'); b.ret()

# Decrypt+authenticate server record already in TLS_RX+5. R0=type,R1=len,R2=output -> R0=plainlen/-1.
b.label('tls_unprotect_server'); b.mov(23,0); b.mov(24,1); b.mov(25,2); b_addr(29,TLS_META2); b.ld(26,29,TM_TLS_SSEQ); b_addr(30,TLS_REC_META); b_addr(20,TLS_SKEYEXP); b.st(20,30,RM_KEYEXP); b_addr(20,TLS_SMAC); b.st(20,30,RM_MAC); b.st(26,30,RM_SEQ); b.st(23,30,RM_TYPE); b_addr(20,TLS_RX+5); b.st(20,30,RM_IN); b.st(24,30,RM_INLEN); b.st(25,30,RM_OUT); b.call('tls_unprotect'); b.js(0,'tls_unprotect_server_done'); b.mov(27,0); b_addr(29,TLS_META2); b.ld(26,29,TM_TLS_SSEQ); b.addi(26,1); b.st(26,29,TM_TLS_SSEQ); b.mov(0,27)
b.label('tls_unprotect_server_done'); b.ret()

# Close TLS TCP fd if open.
b.label('tls_close_fd'); b_addr(29,TLS_META2); b.ld(0,29,TM_TLS_FD); b.js(0,'tls_close_done'); b.sys(9); b_addr(29,TLS_META2); b.ldi(20,-1); b.st(20,29,TM_TLS_FD)
b.label('tls_close_done'); b.ret()

# Full pinned-certificate TLS 1.2 RSA handshake + HTTPS fetch using only Tiny32 guest crypto.
b.label('tls_fetch')
# Require all software crypto + RSA KAT stages.
b_addr(29,TLS_META2); b.ld(20,29,TM_CRYPTO_OK); b.addi(20,-8); b.jnz(20,'tls_fetch_fail_nofd')
# Reset session and certificate status, then open DNS-resolved raw TCP endpoint.
b.ldi(20,0); b.st(20,29,TM_TLS_TLEN); b.st(20,29,TM_TLS_CSEQ); b.st(20,29,TM_TLS_SSEQ); b.st(20,29,TM_TLS_APPRESP); b.st(20,29,TM_TLS_PEEROK); b.ldi(20,-1); b.st(20,29,TM_TLS_FD); b_addr(28,RSA_META); b.ldi(20,0); b.st(20,28,RM_CERTOK2); b.st(20,28,RM_HOSTOK2); b.st(20,28,RM_RSAOK2)
b.ldi(29,STATE); b.ld(0,29,S_BIP); b.ld(1,29,S_BPORT); b.sys(6); b.js(0,'tls_fetch_fail_nofd'); b_addr(29,TLS_META2); b.st(0,29,TM_TLS_FD)
# Deterministic client random for proof reproducibility.
b.ldi_label(0,'tls_test_cr'); b_addr(1,TLS_CLIENT_RANDOM); b.ldi(2,32); b.call('raw_copy')
# ClientHello includes SNI=tls20.test and RSA_WITH_AES_128_CBC_SHA256.
b_addr(29,TLS_META2); b.ld(0,29,TM_TLS_FD); b.ldi_label(1,'tls_clienthello_record'); b.ldi_label(20,'tls_cke_hdr'); b.ldi_label(21,'tls_clienthello_record'); b.sub(20,21); b.mov(2,20); b.call('sock_send_all'); b.js(0,'tls_fetch_fail'); b.ldi_label(0,'tls_clienthello_record'); b.addi(0,5); b.ldi_label(20,'tls_cke_hdr'); b.ldi_label(21,'tls_clienthello_record'); b.sub(20,21); b.addi(20,-5); b.mov(1,20); b.call('tls_transcript_append')
# ServerHello.
b.call('tls_recv_record'); b.js(0,'tls_fetch_fail'); b.mov(22,0); b.addi(22,-22); b.jnz(22,'tls_fetch_fail'); b.mov(24,1); b.mov(22,24); b.addi(22,-38); b.js(22,'tls_fetch_fail'); b_addr(20,TLS_RX+5); b.ld(22,20,0); b.andi(22,255); b.addi(22,-2); b.jnz(22,'tls_fetch_fail'); b_addr(0,TLS_RX+5); b.mov(1,24); b.call('tls_transcript_append'); b_addr(0,TLS_RX+11); b_addr(1,TLS_SERVER_RANDOM); b.ldi(2,32); b.call('raw_copy')
# Certificate handshake record: append transcript, pin SHA256, require hostname, extract/validate RSA modulus.
b.call('tls_recv_record'); b.js(0,'tls_fetch_fail'); b.mov(22,0); b.addi(22,-22); b.jnz(22,'tls_fetch_fail'); b.mov(24,1); b_addr(20,TLS_RX+5); b.ld(22,20,0); b.andi(22,255); b.addi(22,-11); b.jnz(22,'tls_fetch_fail'); b_addr(0,TLS_RX+5); b.mov(1,24); b.call('tls_transcript_append')
# Certificate DER begins at handshake payload+10; decode fixed three-byte certificate length.
b_addr(20,TLS_RX+12); b.ld(21,20,0); b.andi(21,255); b.shl(21,16); b.ld(22,20,1); b.andi(22,255); b.shl(22,8); b.add(21,22); b.ld(22,20,2); b.andi(22,255); b.add(21,22); b_addr(20,TLS_RX+15); b.call('tls20_cert_verify'); b.js(0,'tls_fetch_fail')
# ServerHelloDone.
b.call('tls_recv_record'); b.js(0,'tls_fetch_fail'); b.mov(22,0); b.addi(22,-22); b.jnz(22,'tls_fetch_fail'); b.mov(24,1); b_addr(20,TLS_RX+5); b.ld(22,20,0); b.andi(22,255); b.addi(22,-14); b.jnz(22,'tls_fetch_fail'); b_addr(0,TLS_RX+5); b.mov(1,24); b.call('tls_transcript_append')
# Guest RSA public operation creates the encrypted premaster using the modulus extracted from the certificate.
b.call('rsa_exp3'); b.ldi_label(0,'tls_cke_hdr'); b_addr(1,RSA_CKE); b.ldi(2,6); b.call('raw_copy'); b_addr(20,RSA_CKE+6); b.call('rsa_emit_be')
# Derive keys from 48-byte RSA premaster, then send/append ClientKeyExchange.
b.call('tls_derive_rsa_keys'); b.ldi(0,22); b_addr(1,RSA_CKE); b.ldi(2,134); b.call('tls_send_plain_record'); b.js(0,'tls_fetch_fail'); b_addr(0,RSA_CKE); b.ldi(1,134); b.call('tls_transcript_append')
# ChangeCipherSpec.
b.ldi(0,20); b.ldi_label(1,'tls_ccs_byte'); b.ldi(2,1); b.call('tls_send_plain_record'); b.js(0,'tls_fetch_fail')
# client Finished verify_data = PRF(master,"client finished",SHA256(transcript))[12].
b_addr(29,TLS_META2); b_addr(20,TLS_TRANSCRIPT); b.st(20,29,TM_SHA_IN); b.ld(20,29,TM_TLS_TLEN); b.st(20,29,TM_SHA_LEN); b_addr(20,TLS_TEST_OUT); b.st(20,29,TM_SHA_OUT); b.call('sha256_do'); b.ldi_label(0,'tls_label_cfin'); b_addr(1,TLS_SEED); b.ldi(2,15); b.call('raw_copy'); b_addr(0,TLS_TEST_OUT); b_addr(1,TLS_SEED+15); b.ldi(2,32); b.call('raw_copy'); b.ldi_label(0,'tls_fin_hdr'); b_addr(1,TLS_HSBUF); b.ldi(2,4); b.call('raw_copy'); b_addr(29,TLS_META2); b_addr(20,TLS_MASTER); b.st(20,29,TM_PRF_SECRET); b.ldi(20,48); b.st(20,29,TM_PRF_SECLEN); b_addr(20,TLS_SEED); b.st(20,29,TM_PRF_SEED); b.ldi(20,47); b.st(20,29,TM_PRF_SEEDLEN); b_addr(20,TLS_HSBUF+4); b.st(20,29,TM_PRF_OUT); b.ldi(20,12); b.st(20,29,TM_PRF_OUTLEN); b.call('prf_do')
# Send protected Finished seq=0; then append plaintext Finished to transcript.
b.ldi(0,22); b_addr(1,TLS_HSBUF); b.ldi(2,16); b.call('tls_send_protected'); b.js(0,'tls_fetch_fail'); b_addr(0,TLS_HSBUF); b.ldi(1,16); b.call('tls_transcript_append')
# Receive server ChangeCipherSpec.
b.call('tls_recv_record'); b.js(0,'tls_fetch_fail'); b.mov(22,0); b.addi(22,-20); b.jnz(22,'tls_fetch_fail')
# Receive and authenticate server Finished (server protected seq=0).
b.call('tls_recv_record'); b.js(0,'tls_fetch_fail'); b.mov(23,0); b.addi(23,-22); b.jnz(23,'tls_fetch_fail'); b.mov(24,1); b.ldi(0,22); b.mov(1,24); b_addr(2,TLS_HSBUF+64); b.call('tls_unprotect_server'); b.js(0,'tls_fetch_fail'); b.addi(0,-16); b.jnz(0,'tls_fetch_fail')
# Validate Finished handshake header.
b_addr(20,TLS_HSBUF+64); b.ld(21,20,0); b.andi(21,255); b.addi(21,-20); b.jnz(21,'tls_fetch_fail'); b.ld(21,20,3); b.andi(21,255); b.addi(21,-12); b.jnz(21,'tls_fetch_fail')
# expected server Finished over transcript including client Finished.
b_addr(29,TLS_META2); b_addr(20,TLS_TRANSCRIPT); b.st(20,29,TM_SHA_IN); b.ld(20,29,TM_TLS_TLEN); b.st(20,29,TM_SHA_LEN); b_addr(20,TLS_TEST_OUT); b.st(20,29,TM_SHA_OUT); b.call('sha256_do'); b.ldi_label(0,'tls_label_sfin'); b_addr(1,TLS_SEED); b.ldi(2,15); b.call('raw_copy'); b_addr(0,TLS_TEST_OUT); b_addr(1,TLS_SEED+15); b.ldi(2,32); b.call('raw_copy'); b_addr(29,TLS_META2); b_addr(20,TLS_MASTER); b.st(20,29,TM_PRF_SECRET); b.ldi(20,48); b.st(20,29,TM_PRF_SECLEN); b_addr(20,TLS_SEED); b.st(20,29,TM_PRF_SEED); b.ldi(20,47); b.st(20,29,TM_PRF_SEEDLEN); b_addr(20,TLS_TEST_OUT+64); b.st(20,29,TM_PRF_OUT); b.ldi(20,12); b.st(20,29,TM_PRF_OUTLEN); b.call('prf_do')
# compare peer verify_data bytes.
b_addr(20,TLS_HSBUF+68); b_addr(21,TLS_TEST_OUT+64); b.ldi(22,12)
b.label('tls_server_fin_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'tls_fetch_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'tls_server_fin_cmp'); b_addr(29,TLS_META2); b.ldi(20,1); b.st(20,29,TM_TLS_PEEROK)
# Build HTTP/1.0 request entirely in guest RAM, protect as application record seq=1.
b.call('build_request'); b.mov(2,0); b.ldi(0,23); b_addr(1,REQ_BUF); b.call('tls_send_protected'); b.js(0,'tls_fetch_fail')
# Receive protected application data / close_notify. Accumulate decrypted HTTP bytes in RESP_BUF.
b_addr(29,TLS_META2); b.ldi(20,0); b.st(20,29,TM_TLS_APPRESP)
b.label('tls_app_recv'); b.call('tls_recv_record'); b.js(0,'tls_app_eof'); b.mov(23,0); b.mov(24,1); b.mov(25,23); b.addi(25,-23); b.jz(25,'tls_app_data'); b.mov(25,23); b.addi(25,-21); b.jz(25,'tls_app_alert'); b.mov(25,23); b.addi(25,-22); b.jz(25,'tls_app_ignore_hs'); b.jmp('tls_app_recv')
b.label('tls_app_data'); b.ldi(0,23); b.mov(1,24); b_addr(2,TLS_HSBUF); b.call('tls_unprotect_server'); b.js(0,'tls_fetch_fail'); b.mov(26,0); b_addr(29,TLS_META2); b.ld(27,29,TM_TLS_APPRESP); b.mov(25,27); b.add(25,26); b.ldi(22,7168); b.sub(25,22); b.js(25,'tls_app_copy_ok'); b.jz(25,'tls_app_copy_ok'); b.jmp('tls_fetch_fail')
b.label('tls_app_copy_ok'); b_addr(1,RESP_BUF); b.add(1,27); b_addr(0,TLS_HSBUF); b.mov(2,26); b.call('raw_copy'); b_addr(29,TLS_META2); b.ld(27,29,TM_TLS_APPRESP); b.add(27,26); b.st(27,29,TM_TLS_APPRESP); b.jmp('tls_app_recv')
b.label('tls_app_ignore_hs'); b.ldi(0,22); b.mov(1,24); b_addr(2,TLS_HSBUF); b.call('tls_unprotect_server'); b.js(0,'tls_fetch_fail'); b.jmp('tls_app_recv')
b.label('tls_app_alert'); b.ldi(0,21); b.mov(1,24); b_addr(2,TLS_HSBUF); b.call('tls_unprotect_server'); b.js(0,'tls_fetch_fail'); b.jmp('tls_app_done')
b.label('tls_app_eof'); b_addr(29,TLS_META2); b.ld(20,29,TM_TLS_APPRESP); b.jz(20,'tls_fetch_fail'); b.jmp('tls_app_done')
b.label('tls_app_done'); b.call('tls_close_fd'); b_addr(29,TLS_META2); b.ld(27,29,TM_TLS_APPRESP); b.ldi(29,STATE); b.st(27,29,S_BRESP); b.ldi(26,10); b.st(26,29,S_BSTATUS); b.ldi(26,0); b.st(26,29,S_BFETCH); b.ret()

b.label('tls_fetch_fail'); b.call('tls_close_fd')
b.label('tls_fetch_fail_nofd'); b.ldi(29,STATE); b.ldi(26,11); b.st(26,29,S_BSTATUS); b.ldi(26,0); b.st(26,29,S_BFETCH); b.ret()

b.label('browser_key')
b.mov(8,0); b.addi(8,-4); b.jz(8,'browser_exit')
b.mov(8,0); b.addi(8,-1); b.jz(8,'browser_fetch_key')
b.mov(8,0); b.addi(8,-13); b.jz(8,'browser_backspace_key')
b.mov(8,0); b.addi(8,-2); b.jz(8,'browser_a_key')
b.mov(8,0); b.addi(8,-3); b.jz(8,'browser_d_key')
b.mov(8,0); b.addi(8,-5); b.jz(8,'browser_q_key')
b.mov(9,0); b.addi(9,-32); b.js(9,'browser_key_done'); b.mov(9,0); b.addi(9,-127); b.js(9,'browser_append_key'); b.ret()
b.label('browser_a_key'); b.ldi(0,97); b.jmp('browser_append_key')
b.label('browser_d_key'); b.ldi(0,100); b.jmp('browser_append_key')
b.label('browser_q_key'); b.ldi(0,113); b.jmp('browser_append_key')
b.label('browser_append_key'); b.ldi(29,STATE); b.ld(9,29,S_BLEN); b.mov(10,9); b.addi(10,-40); b.js(10,'browser_append_key_ok'); b.ret()
b.label('browser_append_key_ok'); b_addr(11,ADDR_BUF); b.mov(12,9); b.shl(12,2); b.add(11,12); b.st(0,11,0); b.ldi(13,0); b.st(13,11,4); b.addi(9,1); b.st(9,29,S_BLEN); b.st(13,29,S_BSTATUS); b.st(13,29,S_BLINKLEN); b.ret()
b.label('browser_backspace_key'); b.ldi(29,STATE); b.ld(9,29,S_BLEN); b.jz(9,'browser_key_done'); b.addi(9,-1); b.st(9,29,S_BLEN); b_addr(11,ADDR_BUF); b.mov(12,9); b.shl(12,2); b.add(11,12); b.ldi(13,0); b.st(13,11,0); b.st(13,29,S_BSTATUS); b.st(13,29,S_BLINKLEN); b.ret()
b.label('browser_fetch_key'); b.ldi(29,STATE); b.ld(9,29,S_BLEN); b.jz(9,'browser_key_done'); b.ldi(10,1); b.st(10,29,S_BFETCH); b.ldi(10,0); b.st(10,29,S_BSTATUS); b.ret()
b.label('browser_exit')
b.ldi(29,STATE); b.ldi(8,0); b.st(8,29,S_BOPEN); b.st(8,29,S_BRES); b.st(8,29,S_FOCUS); b_abs(29,PROC_CTL); b.st(8,29,PC_RUN0+12)
b.label('browser_exit_spin'); b.jmp('browser_exit_spin')
b.label('browser_key_done'); b.ret()

# Main browser frame. Fetch pipeline deliberately spans frames so DNS and TCP stages are visible.
b.label('entry_code'); b.call('crypto_selftest_once'); b_abs(28,PROC_CTL); b.ld(0,28,PC_BKEY); b.jz(0,'entry_no_key'); b.ldi(1,0); b.st(1,28,PC_BKEY); b.call('browser_key'); b.label('entry_no_key'); b.call('handle_action'); b.ldi(29,STATE); b.ld(25,29,S_BFETCH); b.jz(25,'draw_ui'); b.addi(25,-1); b.jz(25,'mark_dns'); b.addi(25,-1); b.jz(25,'dns_wait'); b.addi(25,-1); b.jz(25,'http_wait'); b.addi(25,-1); b.jz(25,'local_wait'); b.addi(25,-1); b.jz(25,'tls_wait'); b.jmp('draw_ui')
b.label('mark_dns'); b.call('is_local_url'); b.jnz(0,'mark_local'); b.call('is_user_url'); b.jnz(0,'mark_user'); b.call('parse_address'); b.js(0,'mark_error'); b.ldi(29,STATE); b.ldi(26,1); b.st(26,29,S_BSTATUS); b.ldi(26,2); b.st(26,29,S_BFETCH); b.ldi(26,80); b.st(26,29,S_BDNSLEN); b.jmp('draw_ui')
b.label('mark_local'); b.ldi(29,STATE); b.ldi(26,5); b.st(26,29,S_BSTATUS); b.ldi(26,4); b.st(26,29,S_BFETCH); b.ldi(26,50); b.st(26,29,S_BREQ); b.jmp('draw_ui')
b.label('mark_user'); b_abs(28,PFS2_BASE); b.ld(26,28,P2_EXISTS); b.jz(26,'mark_wasm_error'); b.ldi(29,STATE); b.ldi(26,8); b.st(26,29,S_BSTATUS); b.ldi(26,0); b.st(26,29,S_BFETCH); b.jmp('draw_ui')
b.label('dns_wait'); b.ldi(29,STATE); b.ld(26,29,S_BDNSLEN); b.jz(26,'do_dns'); b.addi(26,-1); b.st(26,29,S_BDNSLEN); b.jmp('draw_ui')
b.label('do_dns'); b.call('resolve_dns'); b.jmp('draw_ui')
b.label('http_wait'); b.ldi(29,STATE); b.ld(26,29,S_BREQ); b.jz(26,'do_http'); b.addi(26,-1); b.st(26,29,S_BREQ); b.jmp('draw_ui')
b.label('do_http'); b.call('http_fetch'); b.jmp('draw_ui')
b.label('local_wait'); b.ldi(29,STATE); b.ld(26,29,S_BREQ); b.jz(26,'do_local'); b.addi(26,-1); b.st(26,29,S_BREQ); b.jmp('draw_ui')
b.label('tls_wait'); b.ldi(29,STATE); b.ld(26,29,S_BREQ); b.jz(26,'do_tls'); b.addi(26,-1); b.st(26,29,S_BREQ); b.jmp('draw_ui')
b.label('do_tls'); b.call('tls_fetch'); b.jmp('draw_ui')
b.label('do_local'); b.call('load_local_wasm'); b.js(0,'mark_wasm_error'); b.ldi(29,STATE); b.ldi(26,6); b.st(26,29,S_BSTATUS); b.ldi(26,0); b.st(26,29,S_BFETCH); b.jmp('draw_ui')
b.label('mark_wasm_error'); b.ldi(29,STATE); b.ldi(26,7); b.st(26,29,S_BSTATUS); b.ldi(26,0); b.st(26,29,S_BFETCH); b.jmp('draw_ui')
b.label('mark_error'); b.ldi(29,STATE); b.ldi(26,4); b.st(26,29,S_BSTATUS); b.ldi(26,0); b.st(26,29,S_BFETCH)

b.label('draw_ui')
# 620x310 native browser window
b_rect(10,34,620,310,'c_border'); b_rect(13,37,614,304,'c_window'); b_rect(13,37,614,24,'c_title')
# titlebar controls and identity
b_rect(21,45,8,8,'c_error'); b_rect(34,45,8,8,'c_warn'); b_rect(47,45,8,8,'c_live')
b_text(68,45,'a_title','c_text'); b_text(474,45,'a_proto','c_live')
b_rect(586,43,14,12,'c_button'); b_rect(606,43,14,12,'c_error'); b_text(590,45,'a_min','c_text'); b_text(610,45,'a_x','c_text')
# toolbar and address
b_rect(20,69,600,28,'c_bar'); b_text(28,81,'a_http','c_muted'); b.call('draw_address')
# status line
b.ldi(29,STATE); b.ld(25,29,S_BSTATUS); b.jz(25,'status_idle'); b.addi(25,-1); b.jz(25,'status_dns'); b.addi(25,-1); b.jz(25,'status_tcp'); b.addi(25,-1); b.jz(25,'status_ok'); b.addi(25,-1); b.jz(25,'status_neterr'); b.addi(25,-1); b.jz(25,'status_local'); b.addi(25,-1); b.jz(25,'status_wasm'); b.addi(25,-1); b.jz(25,'status_wasmerr'); b.addi(25,-1); b.jz(25,'status_user'); b.addi(25,-1); b.jz(25,'status_tls'); b.addi(25,-1); b.jz(25,'status_https'); b.addi(25,-1); b.jz(25,'status_tlserr'); b_text(28,106,'a_error','c_error'); b.jmp('status_done')
b.label('status_idle'); b_text(28,106,'a_hint','c_muted'); b.jmp('status_done'); b.label('status_dns'); b_text(28,106,'a_dns','c_live'); b.jmp('status_done'); b.label('status_tcp'); b_text(28,106,'a_tcp','c_live'); b.jmp('status_done'); b.label('status_ok'); b_text(28,106,'a_ok','c_live'); b.jmp('status_done'); b.label('status_neterr'); b_text(28,106,'a_error','c_error'); b.jmp('status_done'); b.label('status_local'); b_text(28,106,'a_local','c_live'); b.jmp('status_done'); b.label('status_wasm'); b_text(28,106,'a_wasm','c_live'); b.jmp('status_done'); b.label('status_wasmerr'); b_text(28,106,'a_wasmerr','c_error'); b.jmp('status_done'); b.label('status_user'); b_text(28,106,'a_user','c_live'); b.jmp('status_done'); b.label('status_tls'); b_text(28,106,'a_tls','c_warn'); b.jmp('status_done'); b.label('status_https'); b_text(28,106,'a_https','c_live'); b.jmp('status_done'); b.label('status_tlserr'); b_text(28,106,'a_tlserr','c_error')
b.label('status_done')
# page viewport
b_rect(20,122,600,174,'c_content'); b.ldi(29,STATE); b.ld(25,29,S_BSTATUS); b.mov(26,25); b.addi(26,-3); b.jz(26,'draw_net_page'); b.mov(26,25); b.addi(26,-10); b.jz(26,'draw_net_page'); b.jmp('check_local_page'); b.label('draw_net_page'); b.call('render_response'); b.jmp('no_page')
b.label('check_local_page'); b.mov(26,25); b.addi(26,-6); b.jz(26,'draw_wasm_page'); b.addi(25,-8); b.jnz(25,'no_page'); b.call('render_user_html'); b.jmp('no_page'); b.label('draw_wasm_page'); b.call('render_local_html'); b.call('draw_wasm_canvas')
b.label('no_page')
# navigation/footer controls
b_rect(20,306,72,24,'c_button'); b_text(43,315,'a_back','c_text'); b_rect(498,306,122,24,'c_button'); b.ldi(29,STATE); b.ld(25,29,S_BLINKLEN); b.jz(25,'draw_no_link'); b_text(526,315,'a_link','c_link'); b.jmp('draw_nav_done'); b.label('draw_no_link'); b_text(536,315,'a_nolink','c_muted'); b.label('draw_nav_done'); b.call('K_publish_browser'); b.jmp('entry_code')

browser=b.resolve()

# --- TERMINAL.BIN @ 0x9000: separately loaded preemptive shell process ---
t=G(TERMINAL_LOAD)
for n,v in k.labels.items(): t.labels['K_'+n]=v

def t_abs(reg,addr):
    lo=addr&0xff; hi=((addr + (0x100 if lo>=128 else 0))>>8)&0xffff
    t.ldi(reg,hi); t.shl(reg,8)
    if lo: t.addi(reg,lo if lo<128 else lo-256)
def t_color(reg,off): t.ldi_label(reg,'K_palette'); t.ld(reg,reg,off)
def t_rect(x,y,w,h,coff): t.ldi(0,x); t.ldi(1,y); t.ldi(2,w); t.ldi(3,h); t_color(4,coff); t.call('K_fill_rect')
def t_text(x,y,label,coff): t.ldi(0,x); t.ldi(1,y); t.ldi_label(2,'K_'+label); t_color(3,coff); t.call('K_draw_text')

def t_cmd_exact(chars, fail):
    t_abs(20,PFS2_TERM)
    for i,ch in enumerate(chars):
        t.ld(11,20,i*4); t.addi(11,-ord(ch)); t.jnz(11,fail)

t.label('entry')
# mailbox input first
t.ldi(29,PROC_CTL); t.ld(0,29,PC_TKEY); t.jz(0,'draw')
t.ldi(1,0); t.st(1,29,PC_TKEY); t.call('key')
t.label('draw')
# 420x220 process-owned window
t_rect(55,70,420,220,32); t_rect(58,73,414,214,0); t_rect(58,73,414,24,64)
t_text(74,82,'s_terminal',96); t_text(350,82,'s_pid04',80); t_text(74,111,'s_termhint',112); t_text(74,136,'s_prompt',80)
t.ldi(0,116); t.ldi(1,136); t_abs(2,PFS2_TERM); t_color(3,96); t.call('K_draw_text')
# status area
t_rect(72,160,386,90,12); t_abs(28,PFS2_BASE); t.ld(8,28,P2_TERMSTATUS)
t.jz(8,'st_help'); t.addi(8,-1); t.jz(8,'st_created'); t.addi(8,-1); t.jz(8,'st_ls'); t.addi(8,-1); t.jz(8,'st_missing'); t.addi(8,-1); t.jz(8,'st_cat'); t.addi(8,-1); t.jz(8,'st_saved'); t.addi(8,-1); t.jz(8,'st_hang'); t.addi(8,-1); t.jz(8,'st_killed'); t.addi(8,-1); t.jz(8,'st_ps'); t.jmp('st_run')
t.label('st_help'); t_text(82,174,'s_commands18',112); t_text(82,190,'s_commands18b',112); t.jmp('st_done')
t.label('st_created'); t_text(82,174,'s_created',80); t.jmp('st_done')
t.label('st_ls'); t_abs(28,PFS2_BASE); t.ld(8,28,P2_EXISTS); t.jz(8,'st_ls_empty'); t_text(82,174,'s_userhtml',96); t.jmp('st_done')
t.label('st_ls_empty'); t_text(82,174,'s_nouser',112); t.jmp('st_done')
t.label('st_missing'); t_text(82,174,'s_runnew',128); t.jmp('st_done')
t.label('st_cat'); t_text(82,174,'s_cathead',112); t.ldi(0,82); t.ldi(1,194); t_abs(2,PFS2_EDIT); t_color(3,96); t.call('K_draw_text'); t.jmp('st_done')
t.label('st_saved'); t_text(82,174,'s_saved',80); t.jmp('st_done')
t.label('st_hang'); t_text(82,174,'s_hang1',128); t_text(82,190,'s_desktopalive',80); t.jmp('st_done')
t.label('st_killed'); t_text(82,174,'s_kill1',80); t_text(82,190,'s_surfacefree',112); t.jmp('st_done')
t.label('st_ps'); t_text(82,169,'s_ps0',112); t_text(82,183,'s_ps1',112); t_text(82,197,'s_ps2',112); t_text(260,169,'s_ps3',112); t_text(260,183,'s_ps4',112); t_text(260,197,'s_ps5',112); t.jmp('st_done')
t.label('st_run'); t_text(82,174,'s_run1',80)
t.label('st_done'); t_text(82,265,'s_termesc18',112); t.call('K_publish_terminal'); t.jmp('entry')

# input handler
t.label('key')
t.mov(8,0); t.addi(8,-4); t.jz(8,'exit')
t.mov(8,0); t.addi(8,-1); t.jz(8,'exec')
t.mov(8,0); t.addi(8,-13); t.jz(8,'backspace')
t.mov(8,0); t.addi(8,-2); t.jz(8,'key_a'); t.mov(8,0); t.addi(8,-3); t.jz(8,'key_d'); t.mov(8,0); t.addi(8,-5); t.jz(8,'key_q')
t.mov(9,0); t.addi(9,-32); t.js(9,'key_done'); t.mov(9,0); t.addi(9,-127); t.js(9,'append'); t.ret()
t.label('key_a'); t.ldi(0,65); t.jmp('append'); t.label('key_d'); t.ldi(0,68); t.jmp('append'); t.label('key_q'); t.ldi(0,81); t.jmp('append')
t.label('append'); t.mov(9,0); t.addi(9,-97); t.js(9,'norm_done'); t.mov(10,0); t.addi(10,-123); t.js(10,'lower'); t.jmp('norm_done'); t.label('lower'); t.addi(0,-32)
t.label('norm_done'); t_abs(28,PFS2_BASE); t.ld(9,28,P2_TERMLEN); t.mov(10,9); t.addi(10,-28); t.js(10,'append_ok'); t.ret()
t.label('append_ok'); t_abs(11,PFS2_TERM); t.mov(12,9); t.shl(12,2); t.add(11,12); t.st(0,11,0); t.ldi(13,0); t.st(13,11,4); t.addi(9,1); t.st(9,28,P2_TERMLEN); t.ret()
t.label('backspace'); t_abs(28,PFS2_BASE); t.ld(9,28,P2_TERMLEN); t.jz(9,'key_done'); t.addi(9,-1); t.st(9,28,P2_TERMLEN); t_abs(11,PFS2_TERM); t.mov(12,9); t.shl(12,2); t.add(11,12); t.ldi(13,0); t.st(13,11,0); t.ret()

# command parser
t.label('exec'); t_abs(28,PFS2_BASE); t.ld(9,28,P2_TERMLEN)
# NEW
t.mov(10,9); t.addi(10,-3); t.jnz(10,'ck_ls'); t_cmd_exact('NEW','ck_ls'); t.ldi(12,1); t.st(12,28,P2_EXISTS); t.ldi(12,0); t.st(12,28,P2_EDITLEN); t.st(12,28,P2_DIRTY); t.ldi(12,1); t.st(12,28,P2_TERMSTATUS); t_abs(21,PFS2_EDIT); t.ldi(12,0); t.st(12,21,0); t.jmp('clear')
# LS
t.label('ck_ls'); t.mov(10,9); t.addi(10,-2); t.jnz(10,'ck_edit'); t_cmd_exact('LS','ck_edit'); t.ldi(12,2); t.st(12,28,P2_TERMSTATUS); t.jmp('clear')
# EDIT
t.label('ck_edit'); t.mov(10,9); t.addi(10,-4); t.jnz(10,'ck_cat'); t_cmd_exact('EDIT','ck_cat'); t.ld(12,28,P2_EXISTS); t.jz(12,'missing'); t.ldi(29,PROC_CTL); t.ldi(12,2); t.st(12,29,PC_REQ); t.jmp('clear')
# CAT
t.label('ck_cat'); t.mov(10,9); t.addi(10,-3); t.jnz(10,'ck_ps'); t_cmd_exact('CAT','ck_ps'); t.ld(12,28,P2_EXISTS); t.jz(12,'missing'); t.ldi(12,4); t.st(12,28,P2_TERMSTATUS); t.jmp('clear')
# PS
t.label('ck_ps'); t.mov(10,9); t.addi(10,-2); t.jnz(10,'ck_hang'); t_cmd_exact('PS','ck_hang'); t.ldi(12,8); t.st(12,28,P2_TERMSTATUS); t.jmp('clear')
# HANG1
t.label('ck_hang'); t.mov(10,9); t.addi(10,-5); t.jnz(10,'ck_kill'); t_cmd_exact('HANG1','ck_kill'); t.ldi(29,PROC_CTL); t.ldi(12,1); t.st(12,29,PC_RHANG); t_abs(28,PFS2_BASE); t.ldi(12,6); t.st(12,28,P2_TERMSTATUS); t.jmp('clear')
# KILL1
t.label('ck_kill'); t.mov(10,9); t.addi(10,-5); t.jnz(10,'ck_run'); t_cmd_exact('KILL1','ck_run'); t.ldi(29,PROC_CTL); t.ldi(12,1); t.st(12,29,PC_REQ); t_abs(28,PFS2_BASE); t.ldi(12,7); t.st(12,28,P2_TERMSTATUS); t.jmp('clear')
# RUN1
t.label('ck_run'); t.mov(10,9); t.addi(10,-4); t.jnz(10,'help'); t_cmd_exact('RUN1','help'); t.ldi(29,PROC_CTL); t.ldi(12,3); t.st(12,29,PC_REQ); t_abs(28,PFS2_BASE); t.ldi(12,9); t.st(12,28,P2_TERMSTATUS); t.jmp('clear')
t.label('missing'); t.ldi(12,3); t.st(12,28,P2_TERMSTATUS); t.jmp('clear')
t.label('help'); t.ldi(12,0); t.st(12,28,P2_TERMSTATUS)
t.label('clear'); t.ldi(12,0); t.st(12,28,P2_TERMLEN); t_abs(21,PFS2_TERM); t.st(12,21,0); t.ret()
t.label('exit'); t.ldi(29,PROC_CTL); t.ldi(8,0); t.st(8,29,PC_TOPEN); t.st(8,29,PC_TRES); t.st(8,29,PC_RUN0+16); t.ldi(29,STATE); t.st(8,29,S_FOCUS)
t.label('exit_spin'); t.jmp('exit_spin')
t.label('key_done'); t.ret()
terminal=t.resolve()

# --- EDITOR.BIN @ 0xE000: separately loaded preemptive persistent editor process ---
e=G(EDITOR_LOAD)
for n,v in k.labels.items(): e.labels['K_'+n]=v

def e_abs(reg,addr):
    lo=addr&0xff; hi=((addr + (0x100 if lo>=128 else 0))>>8)&0xffff
    e.ldi(reg,hi); e.shl(reg,8)
    if lo: e.addi(reg,lo if lo<128 else lo-256)
def e_color(reg,off): e.ldi_label(reg,'K_palette'); e.ld(reg,reg,off)
def e_rect(x,y,w,h,coff): e.ldi(0,x); e.ldi(1,y); e.ldi(2,w); e.ldi(3,h); e_color(4,coff); e.call('K_fill_rect')
def e_text(x,y,label,coff): e.ldi(0,x); e.ldi(1,y); e.ldi_label(2,'K_'+label); e_color(3,coff); e.call('K_draw_text')

e.label('entry'); e.ldi(29,PROC_CTL); e.ld(0,29,PC_EKEY); e.jz(0,'draw'); e.ldi(1,0); e.st(1,29,PC_EKEY); e.call('key')
e.label('draw')
e_rect(120,58,430,244,32); e_rect(123,61,424,238,0); e_rect(123,61,424,24,80)
e_text(139,70,'s_editor',96); e_text(442,70,'s_pid05',80); e_text(139,101,'s_editpath',112); e_rect(138,119,394,122,12); e_text(150,132,'s_htmltitle',80); e_text(150,151,'s_editlabel',112)
e.ldi(0,150); e.ldi(1,174); e_abs(2,PFS2_EDIT); e_color(3,96); e.call('K_draw_text')
e_abs(28,PFS2_BASE); e.ld(8,28,P2_DIRTY); e.jz(8,'clean'); e_text(150,214,'s_unsaved',128); e.jmp('footer'); e.label('clean'); e_text(150,214,'s_savedstate',80)
e.label('footer'); e_text(139,258,'s_editkeys18',112); e.call('K_publish_editor'); e.jmp('entry')

# keyboard/editor logic
e.label('key'); e.mov(8,0); e.addi(8,-4); e.jz(8,'exit'); e.mov(8,0); e.addi(8,-1); e.jz(8,'save'); e.mov(8,0); e.addi(8,-13); e.jz(8,'backspace'); e.mov(8,0); e.addi(8,-2); e.jz(8,'key_a'); e.mov(8,0); e.addi(8,-3); e.jz(8,'key_d'); e.mov(8,0); e.addi(8,-5); e.jz(8,'key_q')
e.mov(9,0); e.addi(9,-32); e.js(9,'key_done'); e.mov(9,0); e.addi(9,-127); e.js(9,'append'); e.ret()
e.label('key_a'); e.ldi(0,65); e.jmp('append'); e.label('key_d'); e.ldi(0,68); e.jmp('append'); e.label('key_q'); e.ldi(0,81); e.jmp('append')
e.label('append'); e.mov(9,0); e.addi(9,-97); e.js(9,'norm_done'); e.mov(10,0); e.addi(10,-123); e.js(10,'lower'); e.jmp('norm_done'); e.label('lower'); e.addi(0,-32)
e.label('norm_done'); e_abs(28,PFS2_BASE); e.ld(9,28,P2_EDITLEN); e.mov(10,9); e.addi(10,-42); e.js(10,'append_ok'); e.ret()
e.label('append_ok'); e_abs(11,PFS2_EDIT); e.mov(12,9); e.shl(12,2); e.add(11,12); e.st(0,11,0); e.ldi(13,0); e.st(13,11,4); e.addi(9,1); e.st(9,28,P2_EDITLEN); e.ldi(13,1); e.st(13,28,P2_DIRTY); e.ret()
e.label('backspace'); e_abs(28,PFS2_BASE); e.ld(9,28,P2_EDITLEN); e.jz(9,'key_done'); e.addi(9,-1); e.st(9,28,P2_EDITLEN); e_abs(11,PFS2_EDIT); e.mov(12,9); e.shl(12,2); e.add(11,12); e.ldi(13,0); e.st(13,11,0); e.ldi(13,1); e.st(13,28,P2_DIRTY); e.ret()
# copy NUL-terminated u32 string: R20 src, R21 dest
e.label('copy_u32'); e.ldi(0,0); e.label('copy_loop'); e.ld(22,20,0); e.st(22,21,0); e.jz(22,'copy_done'); e.addi(20,4); e.addi(21,4); e.addi(0,1); e.jmp('copy_loop'); e.label('copy_done'); e.ret()
e.label('save'); e_abs(28,PFS2_BASE); e.ldi(12,1); e.st(12,28,P2_EXISTS); e_abs(21,PFS2_FILE); e.ldi_label(20,'K_s_htmlprefix'); e.call('copy_u32'); e.ldi(22,10); e.st(22,21,0); e.addi(21,4); e.ldi(22,0); e.st(22,21,0); e_abs(20,PFS2_EDIT); e.call('copy_u32'); e.ldi_label(20,'K_s_htmlsuffix'); e.call('copy_u32')
e_abs(23,PFS2_FILE); e.mov(24,21); e.sub(24,23); e.sar(24,2); e.st(24,28,P2_FILELEN); e.ld(25,28,P2_VERSION); e.addi(25,1); e.st(25,28,P2_VERSION); e.ldi(25,0); e.st(25,28,P2_DIRTY); e.ldi(25,5); e.st(25,28,P2_TERMSTATUS)
e.ldi(0,0); e_abs(1,PFS2_BASE); e.ldi(2,8); e.sys(12); e_abs(28,PFS2_BASE); e.ldi(25,2); e.st(25,28,P2_DISKSTATUS); e.ret()
e.label('exit'); e.ldi(29,PROC_CTL); e.ldi(8,0); e.st(8,29,PC_EOPEN); e.st(8,29,PC_ERES); e.st(8,29,PC_RUN0+20); e.ldi(29,STATE); e.st(8,29,S_FOCUS)
e.label('exit_spin'); e.jmp('exit_spin')
e.label('key_done'); e.ret()
editor=e.resolve()

# PFS1: seven entries fit exactly in the single 512-byte directory block:
# five executable processes plus local HTML + WASM assets.
def padded_blocks(data):
    n=(len(data)+511)//512; return n, data+bytes(n*512-len(data))
r_blocks,r_pad=padded_blocks(raster); s_blocks,s_pad=padded_blocks(system); b_blocks,b_pad=padded_blocks(browser)
t_blocks,t_pad=padded_blocks(terminal); e_blocks,e_pad=padded_blocks(editor)
wasm_asset=bytes.fromhex('0061736d010000000109026000017f60017f00030504000001000503010001060b027f0141000b7f0141000b073505066d656d6f7279020004737465700000096765745f616e676c650001097365745f616e676c650002096765745f7469636b7300030a2b041500230041016a2400230141016a411f71240123000b040023010b09002000411f7124010b040023000b')
html_asset=(b'<html>\n<h1>PARS WASM LAB</h1>\n<p>LOCAL PFS1 HTML PAGE</p>\n<p>TINY32 RUNS WASM3D.WASM</p>\n<wasm src="/WEB/WASM3D.WASM"></wasm>\n</html>\n')
h_blocks,h_pad=padded_blocks(html_asset); w_blocks,w_pad=padded_blocks(wasm_asset)
blk0=bytearray(512); struct.pack_into('<IIII',blk0,0,0x31534650,7,64,1)

def put_ent(i,file_id,flags,start,blocks,size,load,entry,name):
    ent=16+i*64; struct.pack_into('<IIIIIII',blk0,ent,file_id,flags,start,blocks,size,load,entry); nb=name.encode()+b'\0'; blk0[ent+32:ent+32+len(nb)]=nb
r_start=1; put_ent(0,0x3d01,1,r_start,r_blocks,len(raster),RASTER_LOAD,RASTER_LOAD,'RASTER3D.BIN')
s_start=r_start+r_blocks; put_ent(1,0x5a01,1,s_start,s_blocks,len(system),SYSTEM_LOAD,SYSTEM_LOAD,'SYSTEM.BIN')
b_start=s_start+s_blocks; put_ent(2,0x6901,1,b_start,b_blocks,len(browser),BROWSER_LOAD,BROWSER_LOAD,'BROWSER.BIN')
t_start=b_start+b_blocks; put_ent(3,0x7101,1,t_start,t_blocks,len(terminal),TERMINAL_LOAD,TERMINAL_LOAD,'TERMINAL.BIN')
e_start=t_start+t_blocks; put_ent(4,0x7201,1,e_start,e_blocks,len(editor),EDITOR_LOAD,EDITOR_LOAD,'EDITOR.BIN')
h_start=e_start+e_blocks; put_ent(5,0x7701,0,h_start,h_blocks,len(html_asset),0,0,'WEB/WASM3D.HTML')
w_start=h_start+h_blocks; put_ent(6,0x7702,0,w_start,w_blocks,len(wasm_asset),0,0,'WEB/WASM3D.WASM')
disk=bytes(blk0)+r_pad+s_pad+b_pad+t_pad+e_pad+h_pad+w_pad

# x86 extension: PFS1, TCP stream primitives, UDP socket primitive for guest DNS, mouse, and key translation.
def rel32(src_next,target): return struct.pack('<i',target-src_next)
ext=bytearray(); ext_addr=BASE+0x855
jump_fix=[]
def emit_cmp_je(sysno,label):
    ext.extend(b'\x83\xf9'+bytes([sysno])); at=len(ext); ext.extend(b'\x0f\x84'+b'\0'*4); jump_fix.append((at,label))
for n,l in [(5,'sys5'),(6,'sys6'),(7,'sys7'),(8,'sys8'),(9,'sys9'),(10,'sys10'),(11,'sys11'),(12,'sys12')]: emit_cmp_je(n,l)
ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
labels={}
def lab(n): labels[n]=ext_addr+len(ext)

# SYS5 block read: R0 block, R1 guest dst, R2 count
lab('sys5')
ext += b'\x41\x8b\x07\xc1\xe0\x09'
ext += b'\x48\xba'+b'\0'*8; disk_imm_off=len(ext)-8
ext += b'\x48\x01\xc2'
ext += b'\x41\x8b\x4f\x04\x49\xb8'+struct.pack('<Q',GUEST_BASE)+b'\x49\x01\xc8'
ext += b'\x45\x8b\x4f\x08\x41\xc1\xe1\x09\x48\x89\xd6\x4c\x89\xc7\x44\x89\xc9\xf3\xa4'
ext += b'\x41\xc7\x07\x00\x00\x00\x00'
ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)

# SYS6 TCP_OPEN: R0 IPv4 canonical 0x7f000001, R1 port host-order -> R0 fd or negative
lab('sys6')
ext += b'\xb8\x29\x00\x00\x00\xbf\x02\x00\x00\x00\xbe\x01\x00\x00\x00\x31\xd2\x0f\x05'
ext += b'\x85\xc0'; js_sock=len(ext); ext += b'\x0f\x88'+b'\0'*4
ext += b'\x41\x89\xc0'  # r8d=fd
ext += b'\x48\xbb'+struct.pack('<Q',SOCKADDR)
ext += b'\x66\xc7\x03\x02\x00'  # AF_INET
ext += b'\x41\x8b\x47\x04\x66\xc1\xc0\x08\x66\x89\x43\x02'
ext += b'\x41\x8b\x07\x0f\xc8\x89\x43\x04'
ext += b'\x48\xc7\x43\x08\x00\x00\x00\x00'
ext += b'\xb8\x2a\x00\x00\x00\x44\x89\xc7\x48\x89\xde\xba\x10\x00\x00\x00\x0f\x05'
ext += b'\x85\xc0'; js_conn=len(ext); ext += b'\x0f\x88'+b'\0'*4
ext += b'\x45\x89\x07'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('sock_fail')
ext += b'\x41\x89\x07'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('conn_fail')
ext += b'\xb8\x03\x00\x00\x00\x44\x89\xc7\x0f\x05\x41\xc7\x07\xff\xff\xff\xff'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
# fix js
for at,target in [(js_sock,labels['sock_fail']),(js_conn,labels['conn_fail'])]:
    field=at+2; ext[field:field+4]=struct.pack('<i',target-(ext_addr+field+4))

# SYS10 UDP_OPEN: same IPv4/port ABI as TCP_OPEN, but SOCK_DGRAM.
# Guest constructs/parses DNS packets; host only opens/connects the UDP socket.
lab('sys10')
ext += b'\xb8\x29\x00\x00\x00\xbf\x02\x00\x00\x00\xbe\x02\x00\x00\x00\x31\xd2\x0f\x05'
ext += b'\x85\xc0'; js10_sock=len(ext); ext += b'\x0f\x88'+b'\0'*4
ext += b'\x41\x89\xc0'
ext += b'\x48\xbb'+struct.pack('<Q',SOCKADDR)
ext += b'\x66\xc7\x03\x02\x00'
ext += b'\x41\x8b\x47\x04\x66\xc1\xc0\x08\x66\x89\x43\x02'
ext += b'\x41\x8b\x07\x0f\xc8\x89\x43\x04'
ext += b'\x48\xc7\x43\x08\x00\x00\x00\x00'
ext += b'\xb8\x2a\x00\x00\x00\x44\x89\xc7\x48\x89\xde\xba\x10\x00\x00\x00\x0f\x05'
ext += b'\x85\xc0'; js10_conn=len(ext); ext += b'\x0f\x88'+b'\0'*4
ext += b'\x45\x89\x07'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('udp_sock_fail')
ext += b'\x41\x89\x07'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('udp_conn_fail')
ext += b'\xb8\x03\x00\x00\x00\x44\x89\xc7\x0f\x05\x41\xc7\x07\xff\xff\xff\xff'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
for at,target in [(js10_sock,labels['udp_sock_fail']),(js10_conn,labels['udp_conn_fail'])]:
    field=at+2; ext[field:field+4]=struct.pack('<i',target-(ext_addr+field+4))

# SYS7 TCP_SEND / UDP_SEND on an already-connected socket: R0 fd,R1 guest ptr,R2 len -> R0 bytes/error
lab('sys7')
ext += b'\x41\x8b\x3f\x41\x8b\x77\x04\x48\xb8'+struct.pack('<Q',GUEST_BASE)+b'\x48\x01\xc6\x41\x8b\x57\x08\xb8\x01\x00\x00\x00\x0f\x05\x41\x89\x07'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
# SYS8 TCP_RECV
lab('sys8')
ext += b'\x41\x8b\x3f\x41\x8b\x77\x04\x48\xb8'+struct.pack('<Q',GUEST_BASE)+b'\x48\x01\xc6\x41\x8b\x57\x08\x31\xc0\x0f\x05\x41\x89\x07'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
# SYS9 TCP_CLOSE
lab('sys9')
ext += b'\x41\x8b\x3f\xb8\x03\x00\x00\x00\x0f\x05\x41\x89\x07'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)

# SYS11 durable BLOCK_READ: R0=sector, R1=guest dst, R2=sector count.
# Backing-file format is intentionally opaque to the host; Tiny32 owns PFS2.
lab('sys11')
# rbx=byte offset; r8=guest pointer; r9=byte count
ext += b'\x41\x8b\x1f\x48\xc1\xe3\x09'
ext += b'\x45\x8b\x47\x04\x49\x81\xc0'+struct.pack('<I',GUEST_BASE)
ext += b'\x45\x8b\x4f\x08\x41\xc1\xe1\x09'
# openat(AT_FDCWD,path,O_RDWR|O_CREAT,0644)
ext += b'\xb8\x01\x01\x00\x00\xbf\x9c\xff\xff\xff\x48\xbe'+b'\0'*8; pfs2_path_read_off=len(ext)-8
ext += b'\xba\x42\x00\x00\x00\x41\xba\xa4\x01\x00\x00\x0f\x05\x85\xc0'; sys11_open_js=len(ext); ext += b'\x0f\x88'+b'\0'*4
ext += b'\x41\x89\xc4'
# lseek(fd,offset,SEEK_SET)
ext += b'\xb8\x08\x00\x00\x00\x44\x89\xe7\x48\x89\xde\x31\xd2\x0f\x05\x85\xc0'; sys11_seek_js=len(ext); ext += b'\x0f\x88'+b'\0'*4
# read(fd,guest_ptr,count)
ext += b'\x31\xc0\x44\x89\xe7\x4c\x89\xc6\x44\x89\xca\x0f\x05\x41\x89\xc2'
# close; return read result in guest R0
ext += b'\xb8\x03\x00\x00\x00\x44\x89\xe7\x0f\x05\x45\x89\x17'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('sys11_open_fail'); ext += b'\x41\x89\x07'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('sys11_seek_fail'); ext += b'\xb8\x03\x00\x00\x00\x44\x89\xe7\x0f\x05\x41\xc7\x07\xff\xff\xff\xff'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
for at,target in [(sys11_open_js,labels['sys11_open_fail']),(sys11_seek_js,labels['sys11_seek_fail'])]:
    field=at+2; ext[field:field+4]=struct.pack('<i',target-(ext_addr+field+4))

# SYS12 durable BLOCK_WRITE: same sector ABI. It write-fulls, fsyncs, then closes.
lab('sys12')
ext += b'\x41\x8b\x1f\x48\xc1\xe3\x09'
ext += b'\x45\x8b\x47\x04\x49\x81\xc0'+struct.pack('<I',GUEST_BASE)
ext += b'\x45\x8b\x4f\x08\x41\xc1\xe1\x09'
ext += b'\xb8\x01\x01\x00\x00\xbf\x9c\xff\xff\xff\x48\xbe'+b'\0'*8; pfs2_path_write_off=len(ext)-8
ext += b'\xba\x42\x00\x00\x00\x41\xba\xa4\x01\x00\x00\x0f\x05\x85\xc0'; sys12_open_js=len(ext); ext += b'\x0f\x88'+b'\0'*4
ext += b'\x41\x89\xc4'
ext += b'\xb8\x08\x00\x00\x00\x44\x89\xe7\x48\x89\xde\x31\xd2\x0f\x05\x85\xc0'; sys12_seek_js=len(ext); ext += b'\x0f\x88'+b'\0'*4
# write loop inline, preserving guest PC/base registers
lab('sys12_write_loop'); ext += b'\xb8\x01\x00\x00\x00\x44\x89\xe7\x4c\x89\xc6\x44\x89\xca\x0f\x05\x48\x85\xc0'; sys12_write_js=len(ext); ext += b'\x0f\x8e'+b'\0'*4
ext += b'\x49\x01\xc0\x41\x29\xc1'; sys12_more=len(ext); ext += b'\x0f\x85'+b'\0'*4
# fsync + close
ext += b'\xb8\x4a\x00\x00\x00\x44\x89\xe7\x0f\x05\x85\xc0'; sys12_fsync_js=len(ext); ext += b'\x0f\x88'+b'\0'*4
ext += b'\xb8\x03\x00\x00\x00\x44\x89\xe7\x0f\x05\x41\xc7\x07\x00\x00\x00\x00'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('sys12_open_fail'); ext += b'\x41\x89\x07'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('sys12_fail_close'); ext += b'\xb8\x03\x00\x00\x00\x44\x89\xe7\x0f\x05\x41\xc7\x07\xff\xff\xff\xff'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
for at,target in [(sys12_open_js,labels['sys12_open_fail']),(sys12_seek_js,labels['sys12_fail_close']),(sys12_write_js,labels['sys12_fail_close']),(sys12_fsync_js,labels['sys12_fail_close'])]:
    field=at+2; ext[field:field+4]=struct.pack('<i',target-(ext_addr+field+4))
field=sys12_more+2; ext[field:field+4]=struct.pack('<i',labels['sys12_write_loop']-(ext_addr+field+4))

# Exact-byte write-full helper: RDI=fd, RSI=buf, RDX=len. Large X11
# PutImage payloads can be short-written, so loop until the whole request is sent.
lab('write_full')
write_full_addr=ext_addr+len(ext)
ext += b'\xb8\x01\x00\x00\x00\x0f\x05\x48\x85\xc0\x7e\x08\x48\x01\xc6\x48\x29\xc2\x75\xec\xc3'

# VM/20 native 640x360 present path. Core X11 requests are limited to 16-bit
# request lengths, so one contiguous guest framebuffer is transported as four
# 640x90 ZPixmap strips. No scaling or drawing occurs here: SYS3 only ships VRAM.
lab('sys3_640')
ext += b'\x48\xbb'+struct.pack('<Q',HOST_STATE)+b'\x44\x8b\x23'  # r12d=x11 fd
for _y,_off in [(0,0),(90,230400),(180,460800),(270,691200)]:
    # update PutImage destination-y in the already server-patched 24-byte header
    ext += b'\x48\xbb'+struct.pack('<Q',BASE+0x83d+18)+b'\x66\xc7\x03'+struct.pack('<H',_y)
    # header write-full
    ext += b'\x44\x89\xe7\x48\xbe'+struct.pack('<Q',BASE+0x83d)+b'\xba\x18\x00\x00\x00'
    ext += b'\xe8'+rel32(ext_addr+len(ext)+5,write_full_addr)
    # 640x90 pixel strip write-full
    ext += b'\x44\x89\xe7\x48\xbe'+struct.pack('<Q',GUEST_BASE+VRAM_GUEST+_off)+b'\xba\x00\x84\x03\x00'
    ext += b'\xe8'+rel32(ext_addr+len(ext)+5,write_full_addr)
ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)

# fix syscall dispatch JEs
for at,label in jump_fix:
    field=at+2; ext[field:field+4]=struct.pack('<i',labels[label]-(ext_addr+field+4))

# mouse handler target, entered from existing SYS4 routine after non-KeyPress event.
mouse_addr=ext_addr+len(ext)
ext += b'\x83\xf9\x06'; j_motion=len(ext); ext += b'\x0f\x84'+b'\0'*4
ext += b'\x83\xf9\x04'; j_press=len(ext); ext += b'\x0f\x84'+b'\0'*4
ext += b'\x83\xf9\x05'; j_release=len(ext); ext += b'\x0f\x84'+b'\0'*4
ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x074a)
def emit_mouse_case(code):
    start=ext_addr+len(ext); ext.extend(b'\x0f\xb7\x53\x1a\xc1\xe2\x10\x0f\xb7\x4b\x18\x09\xca\xb8'+struct.pack('<I',code)+b'\xc3'); return start
motion_case=emit_mouse_case(10); press_case=emit_mouse_case(11); release_case=emit_mouse_case(12)
for at,target in [(j_motion,motion_case),(j_press,press_case),(j_release,release_case)]:
    field=at+2; ext[field:field+4]=struct.pack('<i',target-(ext_addr+field+4))

# KeyPress translator: returns existing special codes for Enter/A/D/Esc/Q, ASCII for other common keys.
key_addr=ext_addr+len(ext)
ext += b'\x0f\xb6\x4b\x01'  # ecx=keycode
ext += b'\x48\xba'+b'\0'*8; keytab_imm_off=len(ext)-8
ext += b'\x0f\xb6\x04\x0a\x31\xd2\xc3' # eax=table[rcx], edx=0, ret
key_table_addr=ext_addr+len(ext)
keytab=bytearray(256)
# specials
for kc,val in [(36,1),(38,2),(40,3),(9,4),(24,5),(22,13),(65,32)]: keytab[kc]=val
# digits 1..0
for kc,ch in zip(range(10,20),'1234567890'): keytab[kc]=ord(ch)
# letters, but specials above remain special codes
for kc,ch in zip(range(24,34),'qwertyuiop'):
    if keytab[kc]==0: keytab[kc]=ord(ch)
for kc,ch in zip(range(38,47),'asdfghjkl'):
    if keytab[kc]==0: keytab[kc]=ord(ch)
for kc,ch in zip(range(52,59),'zxcvbnm'): keytab[kc]=ord(ch)
# punctuation needed by HTTP address bar (US X11 keycodes)
for kc,ch in [(20,'-'),(47,':'),(60,'.'),(61,'/')]: keytab[kc]=ord(ch)
ext += keytab
ext[keytab_imm_off:keytab_imm_off+8]=struct.pack('<Q',key_table_addr)
pfs2_path_addr=ext_addr+len(ext); ext += b'.pars_vm20_pfs2.img\0'
ext[pfs2_path_read_off:pfs2_path_read_off+8]=struct.pack('<Q',pfs2_path_addr)
ext[pfs2_path_write_off:pfs2_path_write_off+8]=struct.pack('<Q',pfs2_path_addr)

# VM/20 hardware timer gate. Every normal instruction return passes through this gate.
# When the quantum expires and guest IRQs are enabled, hardware snapshots R0-R31 + PC
# into TRAP_BASE and vectors to the guest-programmed IRQ handler.
lab('timer_gate'); timer_gate_addr=ext_addr+len(ext)
# host instruction counter at HOST_STATE+0x40
ext += b'\x48\xbb'+struct.pack('<Q',HOST_STATE)+b'\xff\x43\x40\x81\x7b\x40'+struct.pack('<I',20000)
timer_jl=len(ext); ext += b'\x0f\x8c'+b'\0'*4
ext += b'\xc7\x43\x40\x00\x00\x00\x00'
# guest IRQ enable/in-service checks
ext += b'\x48\xbb'+struct.pack('<Q',GUEST_BASE+IRQ_BASE)+b'\x83\x7b\x04\x00'; timer_je1=len(ext); ext += b'\x0f\x84'+b'\0'*4
ext += b'\x83\x7b\x08\x00'; timer_jne=len(ext); ext += b'\x0f\x85'+b'\0'*4
# in_service=1, lastpc=R13D; trap PC=R13D
ext += b'\xc7\x43\x08\x01\x00\x00\x00\x44\x89\x6b\x14'
ext += b'\x48\xb8'+struct.pack('<Q',GUEST_BASE+TRAP_BASE+128)+b'\x44\x89\x28'
# copy 32-register bank to hardware trap frame
ext += b'\x48\xbe'+struct.pack('<Q',REG_BASE)+b'\x48\xbf'+struct.pack('<Q',GUEST_BASE+TRAP_BASE)+b'\xb9\x10\x00\x00\x00\xf3\x48\xa5'
# load guest IRQ vector into PC
ext += b'\x44\x8b\x6b\x0c'
lab('timer_fetch'); timer_fetch_addr=ext_addr+len(ext)
# Original Tiny32 fetch/decode prologue, plus privileged IRET opcode intercept.
ext += b'\x43\x8b\x04\x2e\x41\x83\xc5\x04\x41\x89\xc4\x0f\xb6\xc8\x80\xf9\x26'
iret_je=len(ext); ext += b'\x0f\x84'+b'\0'*4
# Tiny32/20 bitwise ISA expansion used by guest SHA-256/AES: XOR, AND-reg, SHR, ROR, BSWAP.
crypto_op_fix=[]
for _op,_lab in [(0x0a,'op_xor'),(0x0b,'op_andr'),(0x0c,'op_shr'),(0x0d,'op_ror'),(0x0e,'op_bswap'),(0x0f,'op_ult')]:
    ext += b'\x80\xf9'+bytes([_op]); _at=len(ext); ext += b'\x0f\x84'+b'\0'*4; crypto_op_fix.append((_at,_lab))
ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0bd)
# branch timer checks to normal fetch
for at in (timer_jl,timer_je1,timer_jne):
    field=at+2; ext[field:field+4]=struct.pack('<i',timer_fetch_addr-(ext_addr+field+4))

lab('iret_handler'); iret_handler_addr=ext_addr+len(ext)
# restore full register bank and resume trap PC selected by guest kernel
ext += b'\x48\xbe'+struct.pack('<Q',GUEST_BASE+TRAP_BASE)+b'\x48\xbf'+struct.pack('<Q',REG_BASE)+b'\xb9\x10\x00\x00\x00\xf3\x48\xa5'
ext += b'\x48\xb8'+struct.pack('<Q',GUEST_BASE+TRAP_BASE+128)+b'\x44\x8b\x28'
ext += b'\x48\xbb'+struct.pack('<Q',GUEST_BASE+IRQ_BASE)+b'\xc7\x43\x08\x00\x00\x00\x00'
ext += b'\xe9'+rel32(ext_addr+len(ext)+5,timer_gate_addr)
field=iret_je+2; ext[field:field+4]=struct.pack('<i',iret_handler_addr-(ext_addr+field+4))


# Tiny32/20 bitwise opcode handlers. All return through the normal timer gate via patched 0x4000af.
def _emit_rr_prefix():
    # EAX=dest register index, ECX=source/shift byte masked to 0..31.
    ext.extend(b'\x44\x89\xe0\xc1\xe8\x08\x83\xe0\x1f\x44\x89\xe1\xc1\xe9\x10\x83\xe1\x1f')
lab('op_xor'); _emit_rr_prefix(); ext += b'\x41\x8b\x14\x8f\x41\x31\x14\x87'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('op_andr'); _emit_rr_prefix(); ext += b'\x41\x8b\x14\x8f\x41\x21\x14\x87'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('op_shr'); _emit_rr_prefix(); ext += b'\x41\x8b\x14\x87\xd3\xea\x41\x89\x14\x87'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('op_ror'); _emit_rr_prefix(); ext += b'\x41\x8b\x14\x87\xd3\xca\x41\x89\x14\x87'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
lab('op_bswap'); ext += b'\x44\x89\xe0\xc1\xe8\x08\x83\xe0\x1f\x41\x8b\x14\x87\x0f\xca\x41\x89\x14\x87'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
# ULT: destination becomes 1 iff unsigned(dest) < unsigned(source). Generic integer CPU primitive.
lab('op_ult'); _emit_rr_prefix(); ext += b'\x41\x8b\x14\x8f\x45\x8b\x04\x87\x41\x39\xd0\x0f\x92\xc2\x0f\xb6\xd2\x41\x89\x14\x87'; ext += b'\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)
for _at,_label in crypto_op_fix:
    _field=_at+2; ext[_field:_field+4]=struct.pack('<i',labels[_label]-(ext_addr+_field+4))

# Layout host + ext + kernel + disk.
guest_file_off=0x855+len(ext); disk_file_off=guest_file_off+len(kernel); disk_addr=BASE+disk_file_off
ext[disk_imm_off:disk_imm_off+8]=struct.pack('<Q',disk_addr)
host=bytearray(HOST_CORE)
# Native X11 window and strip header. The server still patches drawable/GC IDs.
_cw=0x7f1-0x78
assert struct.unpack_from('<HH',host,_cw+16)==(320,180)
struct.pack_into('<HH',host,_cw+16,640,360)
_ph=0x83d-0x78
assert struct.unpack_from('<HH',host,_ph+12)==(320,180)
struct.pack_into('<HH',host,_ph+12,640,90)
# guest source + copy length
host[2:10]=struct.pack('<Q',BASE+guest_file_off)
pat=b'\xb9\x60\x1d\x00\x00'; pos=host.find(pat); assert pos>=0; host[pos+1:pos+5]=struct.pack('<I',len(kernel))
# SYS default jump -> ext
jidx=0x3b6-0x78; host[jidx+1:jidx+5]=rel32(BASE+0x3bb,ext_addr)
# Tiny32 fetch loop -> VM/20 hardware timer/IRQ gate.
fidx=0x0af-0x78; assert host[fidx:fidx+8]==bytes.fromhex('438b042e4183c504'); host[fidx:fidx+8]=b'\xe9'+rel32(BASE+0x0b4,timer_gate_addr)+b'\x90\x90\x90'
# SYS3 direct branch -> native 640x360 four-strip presenter
s3idx=0x3a7-0x78; assert host[s3idx:s3idx+2]==b'\x0f\x84'; host[s3idx+2:s3idx+6]=rel32(BASE+0x3ad,labels['sys3_640'])
# input non-key event JNE @ 0x400701 -> mouse handler
midx=0x701-0x78; assert host[midx:midx+2]==b'\x0f\x85'; host[midx+2:midx+6]=rel32(BASE+0x707,mouse_addr)
# replace original fixed KeyPress mapping body with a jump to explicit key table translator
kidx=0x707-0x78; host[kidx:kidx+6]=b'\xe9'+rel32(BASE+0x70c,key_addr)+b'\x90'
# X11 CreateWindow event mask: Exposure|KeyPress|ButtonPress|ButtonRelease|PointerMotion = 0x804d
mask_idx=0x815-0x78; assert host[mask_idx:mask_idx+4]==struct.pack('<I',0x8001); host[mask_idx:mask_idx+4]=struct.pack('<I',0x804d)

file_body=bytes(host)+bytes(ext)+kernel+disk
filesz=ENTRY_OFF+len(file_body)
if filesz >= 0x18000: raise SystemExit(f'file too large for VM/20 file layout: {filesz}')
memsz=0xE40000
elf=bytearray(0x78); elf[:16]=b'\x7fELF'+bytes([2,1,1,0])+bytes(8)
struct.pack_into('<HHIQQQIHHHHHH',elf,16,2,62,1,BASE+ENTRY_OFF,64,0,0,64,56,1,0,0,0)
struct.pack_into('<IIQQQQQQ',elf,64,1,7,0,BASE,BASE,filesz,memsz,0x1000)
elf += file_body

# outputs
(OUT/'PARS_VM20_CANDIDATE.elf').write_bytes(elf); os_mode=0o755
import os; os.chmod(OUT/'PARS_VM20_CANDIDATE.elf',os_mode)
(OUT/'PARS_VM20_KERNEL_GUEST.bin').write_bytes(kernel)
(OUT/'PARS_VM20_RASTER3D_GUEST.bin').write_bytes(raster)
(OUT/'PARS_VM20_SYSTEM_GUEST.bin').write_bytes(system)
(OUT/'PARS_VM20_BROWSER_GUEST.bin').write_bytes(browser)
(OUT/'PARS_VM20_TERMINAL_GUEST.bin').write_bytes(terminal)
(OUT/'PARS_VM20_EDITOR_GUEST.bin').write_bytes(editor)
(OUT/'PARS_VM20_VIRTUAL_DISK.img').write_bytes(disk)
(OUT/'PARS_VM20_WASM3D.HTML').write_bytes(html_asset)
(OUT/'PARS_VM20_WASM3D.WASM').write_bytes(wasm_asset)
(OUT/'PARS_VM20_CANDIDATE.hex').write_text(elf.hex()+'\n')

def listing(builder,title):
    lines=[title]
    for pc,raw,note in builder.notes: lines.append(f'{pc:04x}  {raw.hex(" ")}  {note}')
    lines.append('\nLabels:')
    for n,v in sorted(builder.labels.items(),key=lambda x:x[1]): lines.append(f'{v:04x}  {n}')
    return '\n'.join(lines)+'\n'
(OUT/'PARS_VM20_KERNEL_LISTING.txt').write_text(listing(k,'Tiny32/20 kernel listing'))
(OUT/'PARS_VM20_RASTER_LISTING.txt').write_text(listing(r,'Tiny32/20 RASTER3D.BIN listing'))
(OUT/'PARS_VM20_SYSTEM_LISTING.txt').write_text(listing(s,'Tiny32/20 SYSTEM.BIN listing'))
(OUT/'PARS_VM20_BROWSER_LISTING.txt').write_text(listing(b,'Tiny32/20 BROWSER.BIN listing'))
(OUT/'PARS_VM20_TERMINAL_LISTING.txt').write_text(listing(t,'Tiny32/20 TERMINAL.BIN listing'))
(OUT/'PARS_VM20_EDITOR_LISTING.txt').write_text(listing(e,'Tiny32/20 EDITOR.BIN listing'))
print('kernel',len(kernel),'raster',len(raster),'system',len(system),'browser',len(browser),'terminal',len(terminal),'editor',len(editor),'disk',len(disk),'ext',len(ext),'elf',len(elf))
print('sha',hashlib.sha256(elf).hexdigest())
print('blocks r/s/b/t/e/html/wasm',r_blocks,s_blocks,b_blocks,t_blocks,e_blocks,h_blocks,w_blocks,'starts',r_start,s_start,b_start,t_start,e_start,h_start,w_start,'file<0x18000',len(elf)<0x18000)
print('labels', {x:k.labels[x] for x in ['boot','desktop','loader','schedule','main_loop']})
