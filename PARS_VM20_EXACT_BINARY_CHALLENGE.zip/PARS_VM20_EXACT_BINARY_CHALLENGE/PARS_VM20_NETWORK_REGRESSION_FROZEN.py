from pathlib import Path
import subprocess,time,os,struct,json
from Xlib import display,X
from Xlib.ext import xtest
W=Path('/mnt/data/PARS_VM20_WORK'); ELF=W/'PARS_VM20_EXACT_BYTE_STREAM.elf'; BASE=0x420000; STATE=0x5040; PROC=0x5300
S_BOPEN=68;S_BLEN=72;S_BSTATUS=80;S_BIP=96;S_BPORT=92;S_BRESP=84
os.environ['DISPLAY']=':99';os.environ['XAUTHORITY']='/tmp/empty.Xauthority';Path('/tmp/empty.Xauthority').touch()
peer=subprocess.Popen(['python3',str(W/'PARS_VM20_LOCAL_DNS_HTTP_PROOF_PEER.py')],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE);time.sleep(.3)
p=subprocess.Popen([str(ELF)],cwd=str(W),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=os.environ.copy());time.sleep(.8);D=display.Display(':99')
def mem(a,n):
 with open(f'/proc/{p.pid}/mem','rb',0) as f:f.seek(BASE+a);return f.read(n)
def u(a):return struct.unpack('<I',mem(a,4))[0]
def wait(fn,t=15):
 e=time.time()+t
 while time.time()<e and p.poll() is None:
  if fn(): return True
  time.sleep(.01)
 return False
def click(x,y):xtest.fake_input(D,X.MotionNotify,x=x,y=y);D.sync();time.sleep(.04);xtest.fake_input(D,X.ButtonPress,1);xtest.fake_input(D,X.ButtonRelease,1);D.sync();time.sleep(.05)
def key(k):xtest.fake_input(D,X.KeyPress,k);xtest.fake_input(D,X.KeyRelease,k);D.sync()
rows={}
for kc,ch in zip(range(24,34),'qwertyuiop'):rows[ch]=kc
for kc,ch in zip(range(38,47),'asdfghjkl'):rows[ch]=kc
for kc,ch in zip(range(52,59),'zxcvbnm'):rows[ch]=kc
for kc,ch in zip(range(10,20),'1234567890'):rows[ch]=kc
rows.update({':':47,'.':60,'/':61,'-':20,' ':65})
try:
 click(85,98); assert wait(lambda:u(STATE+S_BOPEN)==1 and u(PROC+52)==1)
 click(120,82); assert wait(lambda:u(STATE+S_BLEN)==0)
 n=0
 for ch in 'demo.test:18080/': key(rows[ch]);n+=1;assert wait(lambda n=n:u(STATE+S_BLEN)==n,3)
 key(36);assert wait(lambda:u(STATE+S_BSTATUS)==3,20),u(STATE+S_BSTATUS);time.sleep(.2)
 log=(W/'net_peer.log').read_text();assert 'DNS demo.test' in log and 'GET / HTTP/1.0' in log and 'Host: demo.test:18080' in log and 'User-Agent: Tiny32/20' in log,log
 out={'status':u(STATE+S_BSTATUS),'ip_u32':u(STATE+S_BIP),'port':u(STATE+S_BPORT),'response_bytes':u(STATE+S_BRESP),'browser_pid3_run':u(PROC+52),'peer_log':log}
 (W/'PARS_VM20_NETWORK_REGRESSION.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
finally:
 if p.poll() is None:p.kill();p.wait()
 D.close();peer.kill();peer.wait()
