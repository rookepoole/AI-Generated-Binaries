PARS-VM/20 — pinned X.509 / RSA TLS 1.2 HTTPS proof

AUTHORITATIVE ELF
  PARS_VM20_EXACT_BYTE_STREAM.elf
  56,394 bytes
  SHA-256 a5ffd98dc0941a9bebedc2b09ca3650ead465a1b3eb1dcdbfc05afada4125271

QUICK VIEW
  PARS_VM20_SHOWCASE_1080P_H264.mp4
  PARS_VM20_RUNTIME_AUDIT_SHEET.png
  PARS_VM20_SHOWCASE_AUDIT_SHEET.png
  PARS_VM20_PROOF_RECEIPT.md

REPRODUCIBLE LOCAL CERTIFICATE-HTTPS PROOF
  This proof target uses a test-only self-signed tls20.test certificate and a local DNS/TLS peer.
  Linux/WSL dependencies include Python 3, python-xlib, Pillow, cryptography, and Xvfb.
  Run: ./RUN_VM20_LOCAL_CERT_HTTPS_PROOF.sh

IMPORTANT SECURITY NOTE
  tls20_cert.pem / tls20_key.pem are TEST-ONLY proof credentials and are intentionally included so the deterministic TLS peer can be reproduced. Do not trust or reuse this key for anything real.
  VM/20 uses pinned TLS 1.2 RSA/AES-CBC/SHA256 as a protocol milestone. It is not a production TLS implementation or a WebPKI browser.
