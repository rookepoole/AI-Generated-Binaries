from pathlib import Path
import re, hashlib
W=Path('/mnt/data/PARS_VM20_WORK')
src=(W/'vm20_base.py').read_text()

def rep(old,new,count=1):
    global src
    n=src.count(old)
    if n < count: raise SystemExit(f'missing replacement ({n}<{count}): {old[:100]!r}')
    src=src.replace(old,new,count)

# Authority/version labels and filenames.
src=src.replace('PARS_VM19','PARS_VM20').replace('VM/19','VM/20').replace('Tiny32/19','Tiny32/20').replace('Tiny32/19','Tiny32/20')
src=src.replace('.pars_vm19_pfs2.img','.pars_vm20_pfs2.img')
src=src.replace('User-Agent: Tiny32/19','User-Agent: Tiny32/20')
src=src.replace("'s_os13':'OS 19'","'s_os13':'OS 20'")
# Let Browser grow; keep all executable entry addresses in 16-bit Tiny32 code space.
src=src.replace('TERMINAL_LOAD = 0xD000','TERMINAL_LOAD = 0xE000').replace('EDITOR_LOAD = 0xE000','EDITOR_LOAD = 0xF000')

# General-purpose unsigned less-than Tiny32 instruction, used by guest multiprecision math.
rep("    def bswap(self,d): return self.ins(0x0e,d,0,0,f'BSWAP R{d}')\n", "    def bswap(self,d): return self.ins(0x0e,d,0,0,f'BSWAP R{d}')\n    def ult(self,d,s): return self.ins(0x0f,d,s,0,f'ULT R{d}, R{s}')\n    def addr_label(self,r,label):\n        p=self.ins(0x01,r,0,0,f'LDADDRHI R{r}, {label}'); self.fix.append((p-self.origin+2,label,'addrhi'))\n        self.shl(r,8)\n        q=self.ins(0x07,r,0,0,f'LDADDRLO R{r}, {label}'); self.fix.append((q-self.origin+2,label,'addrlo'))\n        return p\n")
rep("        for off,label,kind in self.fix:\n            if label not in self.labels: raise KeyError(label)\n            v=self.labels[label]\n            if not (0<=v<=0xffff): raise ValueError((label,hex(v)))\n            self.b[off:off+2]=struct.pack('<H',v)\n        return bytes(self.b)\n", "        for off,label,kind in self.fix:\n            if label not in self.labels: raise KeyError(label)\n            v=self.labels[label]\n            if not (0<=v<=0xffff): raise ValueError((label,hex(v)))\n            if kind=='u16': self.b[off:off+2]=struct.pack('<H',v)\n            elif kind=='addrhi':\n                lo=v&0xff; hi=((v+(0x100 if lo>=128 else 0))>>8)&0xffff; self.b[off:off+2]=struct.pack('<H',hi)\n            elif kind=='addrlo': self.b[off]=v&0xff\n            else: raise ValueError(kind)\n        return bytes(self.b)\n")
# Expand host opcode intercept table.
rep("for _op,_lab in [(0x0a,'op_xor'),(0x0b,'op_andr'),(0x0c,'op_shr'),(0x0d,'op_ror'),(0x0e,'op_bswap')]:", "for _op,_lab in [(0x0a,'op_xor'),(0x0b,'op_andr'),(0x0c,'op_shr'),(0x0d,'op_ror'),(0x0e,'op_bswap'),(0x0f,'op_ult')]:")
rep("lab('op_bswap'); ext += b'\\x44\\x89\\xe0\\xc1\\xe8\\x08\\x83\\xe0\\x1f\\x41\\x8b\\x14\\x87\\x0f\\xca\\x41\\x89\\x14\\x87'; ext += b'\\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)\n", "lab('op_bswap'); ext += b'\\x44\\x89\\xe0\\xc1\\xe8\\x08\\x83\\xe0\\x1f\\x41\\x8b\\x14\\x87\\x0f\\xca\\x41\\x89\\x14\\x87'; ext += b'\\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)\n# ULT: destination becomes 1 iff unsigned(dest) < unsigned(source). Generic integer CPU primitive.\nlab('op_ult'); _emit_rr_prefix(); ext += b'\\x41\\x8b\\x14\\x8f\\x45\\x8b\\x04\\x87\\x41\\x39\\xd0\\x0f\\x92\\xc2\\x0f\\xb6\\xd2\\x41\\x89\\x14\\x87'; ext += b'\\xe9'+rel32(ext_addr+len(ext)+5,BASE+0x0af)\n")

# RSA/certificate workspace in ordinary guest RAM.
anchor="TLS_TEST_OUT = 0x40F400      # crypto self-test output\n"
rsa_ws="""
# VM/20 pinned-certificate RSA workspace. No host RSA/certificate primitive exists.
RSA_N = 0x410000            # extracted 1024-bit modulus, 32 little-endian u32 limbs
RSA_A = 0x410100            # bignum operand A
RSA_B = 0x410200            # bignum operand B
RSA_R = 0x410300            # bignum result / RSA ciphertext
RSA_SUM = 0x410400          # modular-add workspace
RSA_TMP = 0x410500          # modular-multiply doubling operand
RSA_CERT = 0x411000         # received DER certificate copy
RSA_CERT_SHA = 0x411400     # computed certificate SHA-256
RSA_CKE = 0x411800          # ClientKeyExchange handshake staging
RSA_META = 0x411A00         # certificate/RSA status words
RM_CERTLEN2=0; RM_CERTOK2=4; RM_HOSTOK2=8; RM_RSAOK2=12; RM_MODPTR2=16; RM_BPTR2=20; RM_OUTPTR2=24; RM_LIMB2=28; RM_BIT2=32; RM_WORD2=36
"""
rep(anchor,anchor+rsa_ws)

# Browser UI wording + pinned certificate host.
src=src.replace("'a_tls':'TLS 1.2 PSK - GUEST HANDSHAKE','a_https':'HTTPS PAGE - GUEST DECRYPTED','a_tlserr':'TLS VERIFY ERROR'", "'a_tls':'TLS 1.2 RSA CERT - GUEST HANDSHAKE','a_https':'HTTPS PAGE - CERT VERIFIED','a_tlserr':'TLS CERT VERIFY ERROR'")
src=src.replace("b.label('proof_tls_host'); b.data_str32('tls.test')", "b.label('proof_tls_host'); b.data_str32('tls20.test')")

# Fixed VM/20 certificate/public-key values generated once for this frozen proof endpoint.
cert_der=(W/'tls20_cert.der').read_bytes()
cert_sha=hashlib.sha256(cert_der).digest()
nums=(W/'tls20_key_numbers.txt').read_text()
N=int(re.search(r'n=([0-9a-f]+)',nums).group(1),16)
e=int(re.search(r'e=(\d+)',nums).group(1))
assert e==3 and N.bit_length()==1024
mod=N.to_bytes(128,'big')
prem=bytes.fromhex('0303')+bytes(range(1,47))
ps=bytes((i%255)+1 for i in range(77))
em=bytes.fromhex('0002')+ps+b'\x00'+prem
cipher=pow(int.from_bytes(em,'big'),e,N).to_bytes(128,'big')
def limbs_be_to_le_u32(data):
    assert len(data)==128
    return [int.from_bytes(data[128-4*(i+1):128-4*i],'big') for i in range(32)]
mod_limbs=limbs_be_to_le_u32(mod); em_limbs=limbs_be_to_le_u32(em); c_limbs=limbs_be_to_le_u32(cipher)

# Replace PSK ClientHello/CKE constants with certificate-RSA hello while retaining old PSK KAT constants.
old="""# Deterministic VM/20 pinned TLS 1.2 PSK client protocol records.
TLS_CH_HS=bytes.fromhex('010000290303')+bytes(range(32))+bytes.fromhex('00000200ae0100')
b.label('tls_clienthello_record'); b.b += bytes.fromhex('160301002d')+TLS_CH_HS
b.label('tls_cke_hs'); b.b += bytes.fromhex('100000080006')+b'Tiny32'
b.label('tls_ccs_byte'); b.b += b'\\x01'
b.label('tls_fin_hdr'); b.b += bytes.fromhex('1400000c')
"""
new=f"""# Deterministic VM/20 certificate-authenticated TLS 1.2 RSA ClientHello with SNI tls20.test.
_TLS20_HOST=b'tls20.test'
_TLS20_SNI=(b'\\x00\\x00'+(2+1+2+len(_TLS20_HOST)).to_bytes(2,'big')+(1+2+len(_TLS20_HOST)).to_bytes(2,'big')+b'\\x00'+len(_TLS20_HOST).to_bytes(2,'big')+_TLS20_HOST)
TLS_CH_BODY=bytes.fromhex('0303')+bytes(range(32))+b'\\x00'+bytes.fromhex('0002003c0100')+len(_TLS20_SNI).to_bytes(2,'big')+_TLS20_SNI
TLS_CH_HS=b'\\x01'+len(TLS_CH_BODY).to_bytes(3,'big')+TLS_CH_BODY
b.label('tls_clienthello_record'); b.b += b'\\x16\\x03\\x03'+len(TLS_CH_HS).to_bytes(2,'big')+TLS_CH_HS
b.label('tls_cke_hdr'); b.b += bytes.fromhex('100000820080')
b.label('tls_ccs_byte'); b.b += b'\\x01'
b.label('tls_fin_hdr'); b.b += bytes.fromhex('1400000c')
# Pinned X.509/RSA proof material. Certificate bytes themselves arrive over TLS; guest pins their digest.
b.label('tls20_cert_sha'); b.b += bytes.fromhex('{cert_sha.hex()}')
b.label('tls20_host_ascii'); b.b += b'tls20.test'
b.label('tls20_modulus_expected'); b.data_u32({mod_limbs!r})
b.label('tls20_em_limbs'); b.data_u32({em_limbs!r})
b.label('tls20_cipher_expected'); b.data_u32({c_limbs!r})
b.label('tls20_premaster'); b.b += bytes.fromhex('{prem.hex()}')
"""
rep(old,new)

# Generic RSA multiprecision routines inserted before crypto self-test.
insert_anchor="# One-time SHA-256 known-answer self-test (\"abc\").\n"
rsa_code=r'''# --- Tiny32/20 1024-bit unsigned arithmetic and RSA public operation. ---
# big_copy32(R20=src,R21=dst): 32 u32 limbs.
b.label('big_copy32'); b.ldi(22,32)
b.label('big_copy32_loop'); b.ld(23,20,0); b.st(23,21,0); b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'big_copy32_loop'); b.ret()
# big_zero32(R20=dst)
b.label('big_zero32'); b.ldi(22,32); b.ldi(23,0)
b.label('big_zero32_loop'); b.st(23,20,0); b.addi(20,4); b.addi(22,-1); b.jnz(22,'big_zero32_loop'); b.ret()
# big_ge_n(R20=value) -> R0=1 if value >= RSA_N unsigned.
b.label('big_ge_n'); b.addi(20,124); b_addr(21,RSA_N+124); b.ldi(22,32)
b.label('big_ge_loop'); b.ld(23,20,0); b.ld(24,21,0); b.mov(25,23); b.sub(25,24); b.jz(25,'big_ge_next'); b.mov(25,23); b.ult(25,24); b.jnz(25,'big_ge_no'); b.ldi(0,1); b.ret()
b.label('big_ge_next'); b.addi(20,-4); b.addi(21,-4); b.addi(22,-1); b.jnz(22,'big_ge_loop'); b.ldi(0,1); b.ret()
b.label('big_ge_no'); b.ldi(0,0); b.ret()
# big_sub_n(R20=in/out): subtract RSA_N with borrow.
b.label('big_sub_n'); b_addr(21,RSA_N); b.ldi(22,32); b.ldi(27,0)
b.label('big_sub_loop'); b.ld(8,20,0); b.ld(9,21,0); b.mov(10,8); b.sub(10,9); b.mov(11,8); b.ult(11,9); b.mov(12,10); b.ult(12,27); b.sub(10,27); b.mov(27,11); b.add(27,12); b.st(10,20,0); b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'big_sub_loop'); b.ret()
# big_add_mod(R20=x,R21=y,R22=out): (x+y) mod RSA_N, supports out aliasing x/y.
b.label('big_add_mod'); b.mov(26,22); b.mov(28,20); b.mov(29,21); b.mov(30,22); b.ldi(24,32); b.ldi(27,0)
b.label('big_add_loop'); b.ld(8,28,0); b.ld(9,29,0); b.mov(10,8); b.add(10,9); b.mov(11,10); b.ult(11,8); b.mov(12,10); b.add(12,27); b.mov(13,12); b.ult(13,10); b.mov(27,11); b.add(27,13); b.st(12,30,0); b.addi(28,4); b.addi(29,4); b.addi(30,4); b.addi(24,-1); b.jnz(24,'big_add_loop')
# If carry, actual sum >= 2^1024 > N, so subtract N once. Otherwise compare. R26 preserves output across compare.
b.mov(20,26); b.jnz(27,'big_add_reduce'); b.call('big_ge_n'); b.jz(0,'big_add_done'); b.mov(20,26)
b.label('big_add_reduce'); b.call('big_sub_n')
b.label('big_add_done'); b.ret()
# rsa_modmul(R20=A,R21=B,R22=OUT): bit-serial modular multiplication, modulus fixed RSA_N.
# Loop state lives in RSA_META because arithmetic subroutines intentionally clobber working registers.
b.label('rsa_modmul'); b_addr(29,RSA_META); b.st(21,29,RM_BPTR2); b.st(22,29,RM_OUTPTR2); b.ldi(23,0); b.st(23,29,RM_LIMB2); b.mov(20,20); b_addr(21,RSA_TMP); b.call('big_copy32'); b_addr(20,RSA_SUM); b.call('big_zero32')
b.label('rsa_mul_limb'); b_addr(29,RSA_META); b.ld(23,29,RM_LIMB2); b.mov(22,23); b.addi(22,-32); b.jz(22,'rsa_mul_done'); b.ld(24,29,RM_BPTR2); b.mov(25,23); b.shl(25,2); b.add(24,25); b.ld(18,24,0); b.st(18,29,RM_WORD2); b.ldi(19,0); b.st(19,29,RM_BIT2)
b.label('rsa_mul_bit'); b_addr(29,RSA_META); b.ld(19,29,RM_BIT2); b.mov(17,19); b.addi(17,-32); b.jz(17,'rsa_mul_next_limb'); b.ld(18,29,RM_WORD2); b.mov(17,18); b.andi(17,1); b.jz(17,'rsa_mul_noadd'); b_addr(20,RSA_SUM); b_addr(21,RSA_TMP); b_addr(22,RSA_SUM); b.call('big_add_mod')
b.label('rsa_mul_noadd'); b_addr(20,RSA_TMP); b_addr(21,RSA_TMP); b_addr(22,RSA_TMP); b.call('big_add_mod'); b_addr(29,RSA_META); b.ld(18,29,RM_WORD2); b.shr(18,1); b.st(18,29,RM_WORD2); b.ld(19,29,RM_BIT2); b.addi(19,1); b.st(19,29,RM_BIT2); b.jmp('rsa_mul_bit')
b.label('rsa_mul_next_limb'); b_addr(29,RSA_META); b.ld(23,29,RM_LIMB2); b.addi(23,1); b.st(23,29,RM_LIMB2); b.jmp('rsa_mul_limb')
b.label('rsa_mul_done'); b_addr(29,RSA_META); b.ld(21,29,RM_OUTPTR2); b_addr(20,RSA_SUM); b.call('big_copy32'); b.ret()
# rsa_exp3(): RSA_R = tls20_em^3 mod RSA_N. e=3 is read/validated from the pinned cert profile.
b.label('rsa_exp3'); b.addr_label(20,'tls20_em_limbs'); b_addr(21,RSA_A); b.call('big_copy32'); b_addr(20,RSA_A); b_addr(21,RSA_A); b_addr(22,RSA_B); b.call('rsa_modmul'); b_addr(20,RSA_B); b_addr(21,RSA_A); b_addr(22,RSA_R); b.call('rsa_modmul'); b.ret()
# rsa_emit_be(R20=128-byte raw dst): serialize RSA_R big-endian.
b.label('rsa_emit_be'); b.mov(28,20); b_addr(21,RSA_R+124); b.ldi(22,32)
b.label('rsa_emit_limb'); b.ld(23,21,0); b.mov(24,23); b.shr(24,24); b.andi(24,255); b.st(24,28,0); b.mov(24,23); b.shr(24,16); b.andi(24,255); b.st(24,28,1); b.mov(24,23); b.shr(24,8); b.andi(24,255); b.st(24,28,2); b.andi(23,255); b.st(23,28,3); b.addi(28,4); b.addi(21,-4); b.addi(22,-1); b.jnz(22,'rsa_emit_limb'); b.ret()
# tls20_cert_verify(R20=DER ptr,R21=len) -> R0=0/-1. Pins SHA-256, hostname bytes, extracts/validates modulus.
b.label('tls20_cert_verify'); b.mov(26,20); b.mov(27,21); b_addr(29,RSA_META); b.st(26,29,RM_MODPTR2); b.st(27,29,RM_CERTLEN2); b.ldi(0,0); b.st(0,29,RM_CERTOK2); b.st(0,29,RM_HOSTOK2); b.st(0,29,RM_RSAOK2)
# SHA256(DER) and compare pinned digest.
b_addr(29,TLS_META2); b.st(26,29,TM_SHA_IN); b.st(27,29,TM_SHA_LEN); b_addr(20,RSA_CERT_SHA); b.st(20,29,TM_SHA_OUT); b.call('sha256_do'); b_addr(20,RSA_CERT_SHA); b.ldi_label(21,'tls20_cert_sha'); b.ldi(22,32)
b.label('cert_sha_cmp'); b.ld(23,20,0); b.andi(23,255); b.ld(24,21,0); b.andi(24,255); b.sub(23,24); b.jnz(23,'cert_verify_fail'); b.addi(20,1); b.addi(21,1); b.addi(22,-1); b.jnz(22,'cert_sha_cmp'); b_addr(29,RSA_META); b.ldi(23,1); b.st(23,29,RM_CERTOK2)
# Scan DER for ASCII hostname tls20.test.
b_addr(29,RSA_META); b.ld(20,29,RM_MODPTR2); b.ld(22,29,RM_CERTLEN2); b.addi(22,-10)
b.label('cert_host_outer'); b.js(22,'cert_verify_fail'); b.mov(24,20); b.ldi_label(25,'tls20_host_ascii'); b.ldi(23,10)
b.label('cert_host_inner'); b.ld(8,24,0); b.andi(8,255); b.ld(9,25,0); b.andi(9,255); b.sub(8,9); b.jnz(8,'cert_host_next'); b.addi(24,1); b.addi(25,1); b.addi(23,-1); b.jnz(23,'cert_host_inner'); b_addr(29,RSA_META); b.ldi(23,1); b.st(23,29,RM_HOSTOK2); b.jmp('cert_find_mod')
b.label('cert_host_next'); b.addi(20,1); b.addi(22,-1); b.jmp('cert_host_outer')
# Locate DER INTEGER encoding 02 81 81 00 used by this 1024-bit RSA modulus.
b.label('cert_find_mod'); b_addr(29,RSA_META); b.ld(20,29,RM_MODPTR2); b.ld(22,29,RM_CERTLEN2); b.addi(22,-132)
b.label('cert_mod_scan'); b.js(22,'cert_verify_fail'); b.ld(8,20,0); b.andi(8,255); b.addi(8,-2); b.jnz(8,'cert_mod_next'); b.ld(8,20,1); b.andi(8,255); b.ldi(7,129); b.sub(8,7); b.jnz(8,'cert_mod_next'); b.ld(8,20,2); b.andi(8,255); b.ldi(7,129); b.sub(8,7); b.jnz(8,'cert_mod_next'); b.ld(8,20,3); b.andi(8,255); b.jnz(8,'cert_mod_next'); b.addi(20,4); b.jmp('cert_mod_found')
b.label('cert_mod_next'); b.addi(20,1); b.addi(22,-1); b.jmp('cert_mod_scan')
# Convert 128 big-endian modulus bytes into 32 little-endian u32 limbs.
b.label('cert_mod_found'); b.addi(20,124); b_addr(21,RSA_N); b.ldi(22,32)
b.label('cert_mod_limb'); b.ld(8,20,0); b.andi(8,255); b.shl(8,24); b.ld(9,20,1); b.andi(9,255); b.shl(9,16); b.add(8,9); b.ld(9,20,2); b.andi(9,255); b.shl(9,8); b.add(8,9); b.ld(9,20,3); b.andi(9,255); b.add(8,9); b.st(8,21,0); b.addi(20,-4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'cert_mod_limb')
# Compare extracted modulus with the public key pinned to the certificate fingerprint.
b_addr(20,RSA_N); b.ldi_label(21,'tls20_modulus_expected'); b.ldi(22,32)
b.label('cert_mod_cmp'); b.ld(8,20,0); b.ld(9,21,0); b.sub(8,9); b.jnz(8,'cert_verify_fail'); b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'cert_mod_cmp'); b_addr(29,RSA_META); b.ldi(23,1); b.st(23,29,RM_RSAOK2); b.ldi(0,0); b.ret()
b.label('cert_verify_fail'); b.ldi(0,-1); b.ret()

'''
rep(insert_anchor,rsa_code+insert_anchor)

# Add RSA self-test at the end of existing 7-stage crypto suite, bump success to 8.
old_success="b_addr(29,TLS_META2); b.ldi(20,7); b.st(20,29,TM_CRYPTO_OK); b.ret()"
rsa_test="""# RSA e=3 known-answer using the pinned VM/20 modulus; all bignum work executes as Tiny32 instructions.
b.ldi_label(20,'tls20_modulus_expected'); b_addr(21,RSA_N); b.call('big_copy32'); b.call('rsa_exp3'); b_addr(20,RSA_R); b.addr_label(21,'tls20_cipher_expected'); b.ldi(22,32)
b.label('crypto_rsa_cmp'); b.ld(23,20,0); b.ld(24,21,0); b.sub(23,24); b.jnz(23,'crypto_selftest_fail'); b.addi(20,4); b.addi(21,4); b.addi(22,-1); b.jnz(22,'crypto_rsa_cmp')
b_addr(29,TLS_META2); b.ldi(20,8); b.st(20,29,TM_CRYPTO_OK); b.ret()"""
rep(old_success,rsa_test)

# RSA TLS key derivation: premaster is 48 bytes, not the PSK premaster structure.
anchor2="# Build TLS 1.2 CBC record MAC into TLS_INNER from TLS_REC_META.\n"
rsa_derive=r'''# Derive TLS 1.2 master secret/key block from VM/20 RSA premaster.
b.label('tls_derive_rsa_keys'); b.addr_label(0,'tls20_premaster'); b_addr(1,TLS_PREMASTER); b.ldi(2,48); b.call('raw_copy')
# master secret seed
b.ldi_label(0,'tls_label_master'); b_addr(1,TLS_SEED); b.ldi(2,13); b.call('raw_copy'); b_addr(0,TLS_CLIENT_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_SERVER_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy')
b_addr(29,TLS_META2); b_addr(20,TLS_PREMASTER); b.st(20,29,TM_PRF_SECRET); b.ldi(20,48); b.st(20,29,TM_PRF_SECLEN); b_addr(20,TLS_SEED); b.st(20,29,TM_PRF_SEED); b.ldi(20,77); b.st(20,29,TM_PRF_SEEDLEN); b_addr(20,TLS_MASTER); b.st(20,29,TM_PRF_OUT); b.ldi(20,48); b.st(20,29,TM_PRF_OUTLEN); b.call('prf_do')
# key expansion seed
b.ldi_label(0,'tls_label_keyexp'); b_addr(1,TLS_SEED); b.ldi(2,13); b.call('raw_copy'); b_addr(0,TLS_SERVER_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_CLIENT_RANDOM); b.mov(1,1); b.ldi(2,32); b.call('raw_copy')
b_addr(29,TLS_META2); b_addr(20,TLS_MASTER); b.st(20,29,TM_PRF_SECRET); b.ldi(20,48); b.st(20,29,TM_PRF_SECLEN); b_addr(20,TLS_SEED); b.st(20,29,TM_PRF_SEED); b.ldi(20,77); b.st(20,29,TM_PRF_SEEDLEN); b_addr(20,TLS_KEYBLOCK); b.st(20,29,TM_PRF_OUT); b.ldi(20,96); b.st(20,29,TM_PRF_OUTLEN); b.call('prf_do')
b_addr(0,TLS_KEYBLOCK); b_addr(1,TLS_CMAC); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_KEYBLOCK+32); b_addr(1,TLS_SMAC); b.ldi(2,32); b.call('raw_copy'); b_addr(0,TLS_KEYBLOCK+64); b_addr(1,TLS_CKEY); b.ldi(2,16); b.call('raw_copy'); b_addr(0,TLS_KEYBLOCK+80); b_addr(1,TLS_SKEY); b.ldi(2,16); b.call('raw_copy')
b_addr(29,TLS_META2); b_addr(20,TLS_CKEY); b.st(20,29,TM_AES_KEY); b_addr(20,TLS_CKEYEXP); b.st(20,29,TM_AES_EXP); b.call('aes_expand'); b_addr(29,TLS_META2); b_addr(20,TLS_SKEY); b.st(20,29,TM_AES_KEY); b_addr(20,TLS_SKEYEXP); b.st(20,29,TM_AES_EXP); b.call('aes_expand'); b.ret()

'''
rep(anchor2,rsa_derive+anchor2)

# Replace the PSK-specific TLS handshake preamble through ClientKeyExchange with pinned-certificate RSA flow.
start=src.index("# Full pinned TLS 1.2 PSK handshake + HTTPS fetch using only Tiny32 guest crypto.")
marker="# ChangeCipherSpec.\n"
mid=src.index(marker,start)
old_preamble=src[start:mid]
new_preamble=r'''# Full pinned-certificate TLS 1.2 RSA handshake + HTTPS fetch using only Tiny32 guest crypto.
b.label('tls_fetch')
# Require all software crypto + RSA KAT stages.
b_addr(29,TLS_META2); b.ld(20,29,TM_CRYPTO_OK); b.addi(20,-8); b.jnz(20,'tls_fetch_fail_nofd')
# Reset session and certificate status, then open DNS-resolved raw TCP endpoint.
b.ldi(20,0); b.st(20,29,TM_TLS_TLEN); b.st(20,29,TM_TLS_CSEQ); b.st(20,29,TM_TLS_SSEQ); b.st(20,29,TM_TLS_APPRESP); b.st(20,29,TM_TLS_PEEROK); b.ldi(20,-1); b.st(20,29,TM_TLS_FD); b_addr(28,RSA_META); b.ldi(20,0); b.st(20,28,RM_CERTOK2); b.st(20,28,RM_HOSTOK2); b.st(20,28,RM_RSAOK2)
b.ldi(29,STATE); b.ld(0,29,S_BIP); b.ld(1,29,S_BPORT); b.sys(6); b.js(0,'tls_fetch_fail_nofd'); b_addr(29,TLS_META2); b.st(0,29,TM_TLS_FD)
# Deterministic client random for proof reproducibility.
b.ldi_label(0,'tls_test_cr'); b_addr(1,TLS_CLIENT_RANDOM); b.ldi(2,32); b.call('raw_copy')
# ClientHello includes SNI=tls20.test and RSA_WITH_AES_128_CBC_SHA256.
b_addr(29,TLS_META2); b.ld(0,29,TM_TLS_FD); b.ldi_label(1,'tls_clienthello_record'); b.ldi_label(20,'tls_cke_hdr'); b.ldi_label(21,'tls_clienthello_record'); b.sub(20,21); b.mov(2,20); b.call('sock_send_all'); b.js(0,'tls_fetch_fail'); b.ldi_label(0,'tls_clienthello_record'); b.addi(0,5); b.ldi_label(20,'tls_cke_hdr'); b.ldi_label(21,'tls_clienthello_record'); b.sub(20,21); b.addi(20,-5); b.mov(1,20); b.call('tls_transcript_append')
# ServerHello.
b.call('tls_recv_record'); b.js(0,'tls_fetch_fail'); b.mov(22,0); b.addi(22,-22); b.jnz(22,'tls_fetch_fail'); b.mov(24,1); b.mov(22,24); b.addi(22,-38); b.js(22,'tls_fetch_fail'); b_addr(20,TLS_RX+5); b.ld(22,20,0); b.andi(22,255); b.addi(22,-2); b.jnz(22,'tls_fetch_fail'); b_addr(0,TLS_RX+5); b.mov(1,24); b.call('tls_transcript_append'); b_addr(0,TLS_RX+11); b_addr(1,TLS_SERVER_RANDOM); b.ldi(2,32); b.call('raw_copy')
# Certificate handshake record: append transcript, pin SHA256, require hostname, extract/validate RSA modulus.
b.call('tls_recv_record'); b.js(0,'tls_fetch_fail'); b.mov(22,0); b.addi(22,-22); b.jnz(22,'tls_fetch_fail'); b.mov(24,1); b_addr(20,TLS_RX+5); b.ld(22,20,0); b.andi(22,255); b.addi(22,-11); b.jnz(22,'tls_fetch_fail'); b_addr(0,TLS_RX+5); b.mov(1,24); b.call('tls_transcript_append')
# Certificate DER begins at handshake payload+10; decode fixed three-byte certificate length.
b_addr(20,TLS_RX+12); b.ld(21,20,0); b.andi(21,255); b.shl(21,16); b.ld(22,20,1); b.andi(22,255); b.shl(22,8); b.add(21,22); b.ld(22,20,2); b.andi(22,255); b.add(21,22); b_addr(20,TLS_RX+15); b.call('tls20_cert_verify'); b.js(0,'tls_fetch_fail')
# ServerHelloDone.
b.call('tls_recv_record'); b.js(0,'tls_fetch_fail'); b.mov(22,0); b.addi(22,-22); b.jnz(22,'tls_fetch_fail'); b.mov(24,1); b_addr(20,TLS_RX+5); b.ld(22,20,0); b.andi(22,255); b.addi(22,-14); b.jnz(22,'tls_fetch_fail'); b_addr(0,TLS_RX+5); b.mov(1,24); b.call('tls_transcript_append')
# Guest RSA public operation creates the encrypted premaster using the modulus extracted from the certificate.
b.call('rsa_exp3'); b.ldi_label(0,'tls_cke_hdr'); b_addr(1,RSA_CKE); b.ldi(2,6); b.call('raw_copy'); b_addr(20,RSA_CKE+6); b.call('rsa_emit_be')
# Derive keys from 48-byte RSA premaster, then send/append ClientKeyExchange.
b.call('tls_derive_rsa_keys'); b.ldi(0,22); b_addr(1,RSA_CKE); b.ldi(2,134); b.call('tls_send_plain_record'); b.js(0,'tls_fetch_fail'); b_addr(0,RSA_CKE); b.ldi(1,134); b.call('tls_transcript_append')
'''
src=src[:start]+new_preamble+src[mid:]

# Update comments/status wording and file layout guard.
src=src.replace('PSK master/key-block derivation reference vector','PSK master/key-block derivation reference vector (legacy crypto KAT)')
src=src.replace('file too large for VM/20 file layout','file too large for VM/20 file layout')

# Make output summary identify VM/20 and note certificate mode.
# Save transformed constructor.
out=W/'PARS_VM20_EXPLICIT_BYTE_CONSTRUCTION.py'
out.write_text(src)
print('wrote',out,'bytes',len(src))
print('cert_sha',cert_sha.hex(),'cert_len',len(cert_der))
