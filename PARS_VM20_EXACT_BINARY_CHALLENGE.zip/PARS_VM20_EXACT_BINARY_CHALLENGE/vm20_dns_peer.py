#!/usr/bin/env python3
import socket,struct,time
from pathlib import Path
W=Path(__file__).resolve().parent; log=(W/'vm20_dns.log').open('a',buffering=1)
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('127.0.0.1',15353));log.write(f'START {time.time()}\n')
while True:
 data,addr=s.recvfrom(2048)
 if len(data)<12:continue
 i=12;labels=[]
 try:
  while i<len(data):
   n=data[i];i+=1
   if n==0:break
   labels.append(data[i:i+n].decode('ascii','replace'));i+=n
  q='.'.join(labels);question=data[12:i+4]
  hdr=data[:2]+b'\x81\x80'+b'\x00\x01\x00\x01\x00\x00\x00\x00'
  ans=b'\xc0\x0c\x00\x01\x00\x01'+struct.pack('!I',30)+b'\x00\x04\x7f\x00\x00\x01'
  s.sendto(hdr+question+ans,addr);log.write(f'QUERY {q} {data.hex()} -> 127.0.0.1\n')
 except Exception as e:log.write(f'ERR {e!r}\n')
