#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
cleanup(){ kill ${TLS_PID:-} ${DNS_PID:-} ${XVFB_PID:-} 2>/dev/null || true; }
trap cleanup EXIT
if ! pgrep -f 'Xvfb :99' >/dev/null; then Xvfb :99 -screen 0 640x360x24 -ac >/tmp/vm20_xvfb.log 2>&1 & XVFB_PID=$!; sleep .5; fi
: > vm20_dns.log
: > vm20_tls_peer.log
python3 vm20_dns_peer.py & DNS_PID=$!
python3 vm20_tls_rsa_peer.py & TLS_PID=$!
sleep .4
DISPLAY=:99 python3 test_https20_nav_FROZEN.py
