from pathlib import Path
import subprocess,time,os,struct,hashlib
os.environ['DISPLAY']=':99';os.environ['XAUTHORITY']='/tmp/empty.Xauthority';Path('/tmp/empty.Xauthority').touch()
from Xlib import display,X
from Xlib.ext import xtest
from PIL import Image
W=Path('/mnt/data/PARS_VM20_WORK');E=W/'PARS_VM20_EXACT_BYTE_STREAM.elf';DISK=W/'.pars_vm20_pfs2.img';DISK.unlink(missing_ok=True)
G=0x420000;S=0x5040;P=0x5300;SH=0x50C0;PFS2=0x500000;FILE=0x500800;HTML=0x404400;WASM=0x404800;META=0x404C00
P2_EXISTS=0;P2_FILELEN=4;P2_VERSION=8;P2_TERMLEN=12;P2_TERMSTATUS=16;P2_EDITLEN=20;P2_DIRTY=24;P2_DISKSTATUS=28
D=display.Display(':99')
rows={}
for kc,ch in zip(range(24,34),'qwertyuiop'):rows[ch]=kc
for kc,ch in zip(range(38,47),'asdfghjkl'):rows[ch]=kc
for kc,ch in zip(range(52,59),'zxcvbnm'):rows[ch]=kc
for kc,ch in zip(range(10,20),'1234567890'):rows[ch]=kc
rows.update({':':47,'.':60,'/':61,'-':20,' ':65})
def launch():p=subprocess.Popen([str(E)],cwd=W,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,env=os.environ.copy());time.sleep(.8);return p
def mem(p,a,n):
 with open(f'/proc/{p.pid}/mem','rb',0) as f:f.seek(G+a);return f.read(n)
def u(p,a):return struct.unpack('<I',mem(p,a,4))[0]
def chars(p,a,n):
 r=mem(p,a,n*4);return ''.join(chr(struct.unpack_from('<I',r,i*4)[0]&255) for i in range(n))
def wait(p,fn,t=12,msg='wait'):
 e=time.time()+t
 while time.time()<e:
  if p.poll()!=None:raise RuntimeError(('dead',p.returncode,msg))
  if fn():return
  time.sleep(.005)
 raise RuntimeError(('timeout',msg))
def click(x,y):xtest.fake_input(D,X.MotionNotify,x=x,y=y);D.sync();time.sleep(.05);xtest.fake_input(D,X.ButtonPress,1);xtest.fake_input(D,X.ButtonRelease,1);D.sync();time.sleep(.05)
def key(k):xtest.fake_input(D,X.KeyPress,k);xtest.fake_input(D,X.KeyRelease,k);D.sync()
def term_cmd(p,s,status=None):
 wait(p,lambda:u(p,PFS2+P2_TERMLEN)==0,msg='term empty'); n=0
 for ch in s.lower(): key(rows[ch]);n+=1;wait(p,lambda n=n:u(p,PFS2+P2_TERMLEN)==n,3,'term char')
 key(36);wait(p,lambda:u(p,PFS2+P2_TERMLEN)==0,3,'term enter');
 if status is not None: wait(p,lambda:u(p,PFS2+P2_TERMSTATUS)==status,3,'term status')
def editor_type(p,s):
 base=u(p,PFS2+P2_EDITLEN); n=base
 for ch in s.lower():
  key(rows[ch]);n+=1;wait(p,lambda n=n:u(p,PFS2+P2_EDITLEN)==n,3,'edit char')
def cap(name):
 im=D.screen().root.get_image(0,0,640,360,X.ZPixmap,0xffffffff);d=im.data.encode('latin1') if isinstance(im.data,str) else im.data;Image.frombytes('RGB',(640,360),d,'raw','BGRX').save(W/name)
# boot A
p=launch()
try:
 print('bootA pfs',u(p,PFS2),u(p,PFS2+P2_VERSION))
 click(30,12);wait(p,lambda:u(p,SH)==1,msg='menu');click(88,265);wait(p,lambda:u(p,P)==1 and u(p,P+56)==1,msg='term')
 term_cmd(p,'new',1);term_cmd(p,'edit',None);wait(p,lambda:u(p,P+8)==1 and u(p,P+60)==1 and u(p,S+12)==5,msg='editor')
 body='PROCESS SAVE';editor_type(p,body);key(36);wait(p,lambda:u(p,PFS2+P2_VERSION)==1 and u(p,PFS2+P2_DIRTY)==0,6,'save')
 fl=u(p,PFS2+P2_FILELEN); txt=chars(p,FILE,fl); print('saved',fl,repr(txt),'disk',DISK.stat().st_size,hashlib.sha256(DISK.read_bytes()).hexdigest())
 assert body in txt and DISK.stat().st_size==4096
 cap('vm20_persist_saved.png')
 # exit editor; power off global
 key(9);wait(p,lambda:u(p,P+60)==0 and u(p,S+12)==0,5,'editor exit'); key(24);
 e=time.time()+5
 while time.time()<e and p.poll() is None: time.sleep(.02)
 assert p.poll()==0
finally:
 if p.poll() is None:p.kill();p.wait()
# boot B
p=launch()
try:
 print('bootB pfs',u(p,PFS2),u(p,PFS2+P2_VERSION),u(p,PFS2+P2_DISKSTATUS))
 assert u(p,PFS2)==1 and u(p,PFS2+P2_VERSION)==1 and chars(p,FILE,fl)==txt
 cap('vm20_persist_restored.png')
 # browser via nav
 click(85,98);wait(p,lambda:u(p,S+64)==1 and u(p,P+52)==1,15,'browser')
 # click addr and robustly type via S_BLEN=72
 click(150,82);wait(p,lambda:u(p,S+72)==0,3,'addr clear')
 n=0
 for ch in 'file:///home/hello.html': key(rows[ch]);n+=1;wait(p,lambda n=n:u(p,S+72)==n,3,'browser char')
 key(36);wait(p,lambda:u(p,S+80)==8,12,'user page');cap('vm20_persist_browser.png')
 # local wasm
 click(150,82);wait(p,lambda:u(p,S+72)==0,3,'clear2');n=0
 for ch in 'file:///web/wasm3d.html': key(rows[ch]);n+=1;wait(p,lambda n=n:u(p,S+72)==n,3,'w char')
 key(36);wait(p,lambda:u(p,S+80)==6,18,'wasm ready');m1=struct.unpack('<8I',mem(p,META,32));deadline=time.time()+10;m2=m1
 while time.time()<deadline and m2[4:6]==m1[4:6]:time.sleep(.1);m2=struct.unpack('<8I',mem(p,META,32))
 print('wasm',m1,m2);assert m2[4:6]!=m1[4:6];cap('vm20_persist_wasm.png')
finally:
 if p.poll() is None:p.kill();p.wait()
D.close();print('PASS')
