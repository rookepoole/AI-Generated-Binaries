from pathlib import Path
import subprocess,time,os,struct,json,hashlib
os.environ['DISPLAY']=':99';os.environ['XAUTHORITY']='/tmp/empty.Xauthority';Path('/tmp/empty.Xauthority').touch()
from Xlib import display,X
from Xlib.ext import xtest
from PIL import Image
W=Path('/mnt/data/PARS_VM20_WORK');ELF=W/'PARS_VM20_EXACT_BYTE_STREAM.elf';G=0x420000;S=0x5040;P=0x5300;TM=0x40F000;RM=0x411A00;ADDR=0x400000;LINK=0x404000
D=display.Display(':99');p=subprocess.Popen([str(ELF)],cwd=W,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,env=os.environ.copy())
def mem(a,n):
 with open(f'/proc/{p.pid}/mem','rb',0) as f:f.seek(G+a);return f.read(n)
def u(a):return struct.unpack('<I',mem(a,4))[0]
def gs(a,n=300):
 out=[]
 for i in range(n):
  c=u(a+i*4)&255
  if c==0:break
  out.append(chr(c))
 return ''.join(out)
def wait(fn,t=45,msg='wait'):
 e=time.time()+t
 while time.time()<e:
  if p.poll() is not None:raise RuntimeError(('exit',p.returncode,msg,p.stderr.read().decode(errors='ignore')))
  if fn():return
  time.sleep(.01)
 raise RuntimeError(('timeout',msg,u(S+80),u(S+76),u(S+108),gs(ADDR)))
def click(x,y):xtest.fake_input(D,X.MotionNotify,x=x,y=y);D.sync();time.sleep(.04);xtest.fake_input(D,X.ButtonPress,1);xtest.fake_input(D,X.ButtonRelease,1);D.sync();time.sleep(.04)
rows={}
for kc,ch in zip(range(24,34),'qwertyuiop'):rows[ch]=kc
for kc,ch in zip(range(38,47),'asdfghjkl'):rows[ch]=kc
for kc,ch in zip(range(52,59),'zxcvbnm'):rows[ch]=kc
for kc,ch in zip(range(10,20),'1234567890'):rows[ch]=kc
rows.update({':':47,'.':60,'/':61,'-':20,' ':65})
def key(k):xtest.fake_input(D,X.KeyPress,k);xtest.fake_input(D,X.KeyRelease,k);D.sync()
def type_addr(s):
 for i,ch in enumerate(s,1):key(rows[ch]);wait(lambda i=i:u(S+72)==i,3,f'char{i}')
def cap(name):
 time.sleep(.4);im=D.screen().root.get_image(0,0,640,360,X.ZPixmap,0xffffffff);d=im.data.encode('latin1') if isinstance(im.data,str) else im.data;Image.frombytes('RGB',(640,360),d,'raw','BGRX').save(W/name)
try:
 time.sleep(.7);click(85,98);wait(lambda:u(S+64)==1 and u(P+52)==1,10,'browser');wait(lambda:u(TM+64)==8,30,'crypto')
 url='https://tls20.test:18444/vm20.html';type_addr(url);key(36);wait(lambda:u(S+80)==10 and u(S+76)==0 and u(S+108)>0,60,'home');wait(lambda:gs(ADDR).endswith('/vm20.html'),2,'homeaddr');
 home={'addr':gs(ADDR),'link':gs(LINK),'resp':u(S+84),'linklen':u(S+108),'cert':u(RM+4),'host':u(RM+8),'rsa':u(RM+12),'peer':u(TM+120)};cap('vm20_https_home.png')
 click(558,318);wait(lambda:u(S+80)==10 and u(S+76)==0 and gs(ADDR).endswith('/about.html'),60,'about');wait(lambda:u(S+108)>0,2,'aboutlink');about={'addr':gs(ADDR),'link':gs(LINK),'resp':u(S+84),'peer':u(TM+120)};cap('vm20_https_about.png')
 click(55,318);wait(lambda:u(S+80)==10 and u(S+76)==0 and gs(ADDR).endswith('/vm20.html'),60,'back');back={'addr':gs(ADDR),'link':gs(LINK),'resp':u(S+84),'peer':u(TM+120)};cap('vm20_https_back.png')
 out={'sha':hashlib.sha256(ELF.read_bytes()).hexdigest(),'crypto':u(TM+64),'home':home,'about':about,'back':back,'pid':p.pid}
 (W/'PARS_VM20_TLS_NAV_PROOF.json').write_text(json.dumps(out,indent=2))
 print(json.dumps(out,indent=2))
finally:
 if p.poll() is None:p.kill();p.wait()
 D.close()
