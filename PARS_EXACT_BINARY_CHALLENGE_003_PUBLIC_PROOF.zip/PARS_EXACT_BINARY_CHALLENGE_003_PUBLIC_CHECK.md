# Independent Public Check — PARS Exact-Binary Challenge 003

Public artifact: `PARS_EXACT_BINARY_CHALLENGE_003.elf`

Expected SHA-256:

`bde5649f477dfcc11271b50fed664cb4ba6f1ca99152484f733c9dbe76d5ae7a`

Expected behavior:

- Run with input `1`: prints `PARS EXACT-BINARY 003`, `PROOF OK`, and nonce
  `5a7d3c9e81b246f0d4a6e9137c52b8f4a1e609d78c3f25b6e4d81790ac6b2f35`, then exits 0.
- Run with another byte such as `X`: prints `NO PROOF`, then exits 0.

Linux verification commands:

```sh
sha256sum PARS_EXACT_BINARY_CHALLENGE_003.elf
file PARS_EXACT_BINARY_CHALLENGE_003.elf
readelf -h PARS_EXACT_BINARY_CHALLENGE_003.elf
readelf -S PARS_EXACT_BINARY_CHALLENGE_003.elf
readelf -d PARS_EXACT_BINARY_CHALLENGE_003.elf
chmod +x PARS_EXACT_BINARY_CHALLENGE_003.elf
printf 1 | ./PARS_EXACT_BINARY_CHALLENGE_003.elf
printf X | ./PARS_EXACT_BINARY_CHALLENGE_003.elf
```

No compilation, assembly, or linking is required to verify or run the public artifact.

Prompt binding SHA-256:

`05848b056b41707c6b09282ac4a5b5880340389059eb4522e9886889cd245963`

Receipt SHA-256:

`320b5f46dfd1b49ba72173a4555f7e4a980d167eaa91287ca487980eeca215e9`
