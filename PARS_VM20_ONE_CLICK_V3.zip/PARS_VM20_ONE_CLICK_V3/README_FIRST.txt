PARS VM/20 — ONE CLICK LAUNCHER v3
==================================

RUN IT
------
1. Extract this ZIP on Windows.
2. Double-click RUN_PARS_VM20.bat.
3. Wait a few seconds.
4. PARS PROCESS OS should open in a TigerVNC window.

Do not run any Xvfb, socat, x11vnc, VNC, mount, or WSL commands yourself.
The launcher handles the full chain and cleans it up when the viewer closes.

WHY V3 EXISTS
-------------
WSLg mounts /tmp/.X11-unix read-only. The original exact-byte VM/20 ELF expects
/tmp/.X11-unix/X99 directly, which makes it brittle on WSLg.

The runtime changes only the native X11 connection transport. Instead of
opening the X99 filesystem socket, it connects to 127.0.0.1:6109. The launcher
binds that port only to localhost and bridges it to Xvfb's Linux abstract X109
socket. x11vnc uses the same local bridge, and TigerVNC supplies the visible
interactive window through normal WSLg.

The Tiny32 VM, guest kernel, PFS1 virtual disk, programs, rendering, input,
networking, and PFS2 persistence are unchanged.

V3 FIX
------
WSLg exports WAYLAND_DISPLAY/XDG_SESSION_TYPE into Ubuntu. x11vnc 0.9.17
interprets those variables as a request to capture the Wayland compositor and exits,
even when -display explicitly names the private Xvfb server. v3 removes the Wayland
variables only from the x11vnc process, forcing it to connect to the intended private
X11 display. The rest of the WSLg session is unchanged.

FIRST RUN
---------
The launcher checks for these Ubuntu packages:
  xvfb
  x11vnc
  tigervnc-viewer
  socat

If any are absent it installs them automatically. Ubuntu may ask for your
Linux sudo password once. On this machine they have already been installed.

PERSISTENCE
-----------
VM/20 runs from:
  ~/.local/share/pars-vm20/

Its writable disk remains:
  ~/.local/share/pars-vm20/.pars_vm20_pfs2.img

DIAGNOSTICS
-----------
The launcher prints every startup stage instead of leaving a blank console.
It also creates:
  VM20_LAUNCH_LOG.txt
next to RUN_PARS_VM20.bat.

If launch fails, send that one log file instead of re-running manual commands.

PROVENANCE
----------
PARS_VM20_EXACT_BYTE_STREAM_ORIGINAL.elf is the untouched frozen artifact.
PARS_VM20_LOCALHOST_RUNTIME.elf is the WSL-friendly runtime copy.
