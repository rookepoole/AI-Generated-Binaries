@echo off
setlocal
color 0F
title PARS VM/20 - One Click Launcher v3
cls
echo ============================================================
echo                  PARS VM/20 - ONE CLICK
echo ============================================================
echo.
echo Starting VM/20.  No manual Linux commands are required.
echo Keep this window open while PARS is running.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_PARS_VM20.ps1"
set "VM20_EXIT=%ERRORLEVEL%"
if not "%VM20_EXIT%"=="0" (
    echo.
    echo ============================================================
    echo VM/20 could not launch. Exit code: %VM20_EXIT%
    echo A diagnostic log was written beside this launcher:
    echo VM20_LAUNCH_LOG.txt
    echo ============================================================
    echo.
    pause
)
exit /b %VM20_EXIT%
