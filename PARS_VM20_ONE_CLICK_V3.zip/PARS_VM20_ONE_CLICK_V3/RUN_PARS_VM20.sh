#!/usr/bin/env bash
set -u

SOURCE_DIR="${1:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)}"
SOURCE_ELF="$SOURCE_DIR/PARS_VM20_LOCALHOST_RUNTIME.elf"
LOGFILE="$SOURCE_DIR/VM20_LAUNCH_LOG.txt"
DATA_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/pars-vm20"
RUNTIME_ELF="$DATA_DIR/PARS_VM20_LOCALHOST_RUNTIME.elf"
WSLG_DISPLAY="${DISPLAY:-:0}"

XVFB_PID=""
SOCAT_PID=""
VM_PID=""
VNC_PID=""

log() {
    printf '%s\n' "$*" | tee -a "$LOGFILE"
}

cleanup() {
    [[ -n "$VNC_PID" ]] && kill "$VNC_PID" 2>/dev/null || true
    [[ -n "$VM_PID" ]] && kill "$VM_PID" 2>/dev/null || true
    [[ -n "$SOCAT_PID" ]] && kill "$SOCAT_PID" 2>/dev/null || true
    [[ -n "$XVFB_PID" ]] && kill "$XVFB_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

: > "$LOGFILE"
log "PARS VM/20 One Click Launcher v3"
log "Date: $(date -Is 2>/dev/null || date)"
log "WSL kernel: $(uname -sr)"
log "WSLg display: $WSLG_DISPLAY"
log "WSLg Wayland env: ${WAYLAND_DISPLAY:-<unset>}"
log ""

if [[ ! -f "$SOURCE_ELF" ]]; then
    log "FAIL: runtime ELF is missing: $SOURCE_ELF"
    exit 30
fi

# The visible TigerVNC window itself is a normal WSLg GUI application.
if [[ ! -S /tmp/.X11-unix/X0 ]]; then
    log "FAIL: WSLg X0 socket is unavailable at /tmp/.X11-unix/X0"
    log "From Windows run: wsl --update"
    log "Then run: wsl --shutdown"
    exit 31
fi

missing=()
command -v Xvfb >/dev/null 2>&1 || missing+=(xvfb)
command -v x11vnc >/dev/null 2>&1 || missing+=(x11vnc)
command -v vncviewer >/dev/null 2>&1 || missing+=(tigervnc-viewer)
command -v socat >/dev/null 2>&1 || missing+=(socat)

if (( ${#missing[@]} )); then
    log "One-time setup: installing required Linux packages: ${missing[*]}"
    log "Ubuntu may ask for your Linux password once."
    if ! sudo apt-get update; then
        log "FAIL: apt update failed."
        exit 32
    fi
    if ! sudo apt-get install -y "${missing[@]}"; then
        log "FAIL: package installation failed."
        exit 33
    fi
fi

mkdir -p "$DATA_DIR" || { log "FAIL: cannot create $DATA_DIR"; exit 34; }
if ! cmp -s "$SOURCE_ELF" "$RUNTIME_ELF" 2>/dev/null; then
    cp -f "$SOURCE_ELF" "$RUNTIME_ELF" || { log "FAIL: cannot copy runtime ELF."; exit 35; }
fi
chmod 755 "$RUNTIME_ELF" || { log "FAIL: cannot mark runtime executable."; exit 36; }

# Remove only the stale display lock. WSLg owns /tmp/.X11-unix and mounts it
# read-only; this launcher deliberately never tries to write there.
rm -f /tmp/.X109-lock 2>/dev/null || true

log "[1/5] Starting private 640x360 X display..."
Xvfb :109 -screen 0 640x360x24 -ac -noreset -nolisten tcp >>"$LOGFILE" 2>&1 &
XVFB_PID=$!

# Under WSLg the normal X109 filesystem socket cannot be created, but Linux
# Xvfb still creates its abstract Unix-domain socket. Wait for that exact socket.
ready=0
for _ in $(seq 1 50); do
    if grep -Fq '@/tmp/.X11-unix/X109' /proc/net/unix 2>/dev/null; then ready=1; break; fi
    if ! kill -0 "$XVFB_PID" 2>/dev/null; then break; fi
    sleep 0.1
done
if [[ $ready -ne 1 ]]; then
    log "FAIL: Xvfb did not create its abstract X109 socket."
    log "--- Xvfb tail ---"
    tail -30 "$LOGFILE" 2>/dev/null | tee -a "$LOGFILE" >/dev/null
    exit 37
fi

log "[2/5] Creating localhost X11 bridge..."
# Bind only to loopback. This bridges TCP 127.0.0.1:6109 to Xvfb's abstract
# socket and completely avoids WSLg's read-only /tmp/.X11-unix mount.
socat TCP-LISTEN:6109,bind=127.0.0.1,reuseaddr,fork ABSTRACT-CONNECT:/tmp/.X11-unix/X109 >>"$LOGFILE" 2>&1 &
SOCAT_PID=$!
sleep 0.35
if ! kill -0 "$SOCAT_PID" 2>/dev/null; then
    log "FAIL: localhost X11 bridge exited."
    exit 38
fi

log "[3/5] Booting PARS VM/20..."
cd "$DATA_DIR" || exit 39
"$RUNTIME_ELF" >>"$LOGFILE" 2>&1 &
VM_PID=$!
sleep 1.5
if ! kill -0 "$VM_PID" 2>/dev/null; then
    wait "$VM_PID" 2>/dev/null
    code=$?
    log "FAIL: VM/20 exited during boot with code $code."
    exit 40
fi
log "      VM/20 process is alive (PID $VM_PID)."

log "[4/5] Starting local display viewer bridge (forcing X11 mode)..."
env -u WAYLAND_DISPLAY -u WAYLAND_SOCKET -u XDG_SESSION_TYPE -u XDG_SESSION_DESKTOP \
  x11vnc -display 127.0.0.1:109 -nopw -localhost -forever -shared -rfbport 5919 >>"$LOGFILE" 2>&1 &
VNC_PID=$!
sleep 1
if ! kill -0 "$VNC_PID" 2>/dev/null; then
    log "FAIL: x11vnc exited before the viewer could connect."
    exit 41
fi

log "[5/5] Opening PARS PROCESS OS..."
log ""
log "The PARS desktop should now appear in a TigerVNC window."
log "Close that window when you want to stop VM/20."
log "Persistent VM storage: $DATA_DIR/.pars_vm20_pfs2.img"
log ""

if [[ "${VM20_HEADLESS_TEST:-0}" == "1" ]]; then
    log "HEADLESS TEST PASS: VM and VNC server are alive."
    exit 0
fi

DISPLAY="$WSLG_DISPLAY" vncviewer 127.0.0.1:5919
viewer_code=$?
log "Viewer closed (exit $viewer_code). Shutting VM/20 down."
exit "$viewer_code"
