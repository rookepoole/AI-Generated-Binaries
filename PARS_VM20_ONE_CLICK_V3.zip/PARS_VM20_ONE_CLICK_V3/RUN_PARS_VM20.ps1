$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'PARS VM/20 - One Click Launcher v3'

function Fail([string]$Message, [int]$Code) {
    Write-Host ''
    Write-Host "ERROR: $Message" -ForegroundColor Red
    Write-Host ''
    exit $Code
}

try {
    $root = Split-Path -Parent $MyInvocation.MyCommand.Path
    Write-Host '[1/2] Locating WSL...' -ForegroundColor Cyan

    if (-not (Get-Command wsl.exe -ErrorAction SilentlyContinue)) {
        Fail 'WSL is not installed or wsl.exe is unavailable.' 20
    }

    $translatedLines = & wsl.exe --exec wslpath -u -a $root 2>&1
    if ($LASTEXITCODE -ne 0) {
        Fail ("Could not translate the extracted folder into WSL. `n" + ($translatedLines -join "`n")) 21
    }
    $wslRoot = (($translatedLines | Select-Object -Last 1).ToString()).Trim()
    if ([string]::IsNullOrWhiteSpace($wslRoot)) {
        Fail 'WSL returned an empty package path.' 22
    }

    Write-Host '[2/2] Starting the PARS desktop...' -ForegroundColor Cyan
    Write-Host ''
    & wsl.exe --exec bash "$wslRoot/RUN_PARS_VM20.sh" "$wslRoot"
    $code = $LASTEXITCODE
    exit $code
}
catch {
    Fail ("Launcher exception: " + $_.Exception.Message) 23
}
