#!/usr/bin/env python3
from pathlib import Path
import hashlib, socket, struct

root = Path(__file__).resolve().parent
src = root / 'PARS_VM20_EXACT_BYTE_STREAM_ORIGINAL.elf'
out = root / 'PARS_VM20_LOCALHOST_RUNTIME.elf'
b = bytearray(src.read_bytes())

# socket(AF_UNIX, SOCK_STREAM, 0) -> socket(AF_INET, SOCK_STREAM, 0)
assert b[0x40d] == 0xbf and b[0x40e:0x412] == struct.pack('<I', 1)
b[0x40e:0x412] = struct.pack('<I', 2)

# connect sockaddr length 24 -> sockaddr_in length 16
assert b[0x446] == 0xba and b[0x447:0x44b] == struct.pack('<I', 24)
b[0x447:0x44b] = struct.pack('<I', 16)

# sockaddr_un('/tmp/.X11-unix/X99') -> sockaddr_in(127.0.0.1:6109)
old = bytes(b[0x777:0x777+24])
assert old[:2] == b'\x01\x00' and b'/tmp/.X11-unix/X99' in old
sa = (struct.pack('<H', socket.AF_INET) + struct.pack('!H', 6109) +
      socket.inet_aton('127.0.0.1') + b'\x00' * 8)
b[0x777:0x777+16] = sa

out.write_bytes(b)
out.chmod(0o755)
print('original sha256:', hashlib.sha256(src.read_bytes()).hexdigest())
print('runtime  sha256:', hashlib.sha256(b).hexdigest())
print('bytes changed:', sum(a != c for a, c in zip(src.read_bytes(), b)))
